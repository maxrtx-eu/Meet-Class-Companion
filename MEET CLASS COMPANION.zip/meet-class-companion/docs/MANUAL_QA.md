# Manual QA (things unit tests cannot reach)

Run once per Chrome release and after any change to `meetDetector.js`. Use two accounts if you can (professor + student).

## Event types: how to make each one happen
| Event | How | Expect in "My log" |
|---|---|---|
| CONSENT_GRANTED, JOINED_CLASS | Accept the consent form, join the call | both, same time |
| FOCUS_LOST + RETURNED | Switch to another tab for 30s, come back | one line away, one "Returned, away 30s" |
| (nothing) | Switch tab for 3s | nothing (grace period) |
| WINDOW_UNFOCUSED outside Chrome | Alt-Tab to another app for 30s | "Chrome lost focus" |
| WINDOW_UNFOCUSED other window | Second Chrome window on another monitor, click it | "Moved to another Chrome window (Meet tab still visible)" |
| WINDOW_UNFOCUSED locked | Lock the screen for 30s | "Screen locked" |
| FOCUS_LOST with pip | Turn on Meet picture-in-picture, switch tab | "(Meet in picture-in-picture)" |
| NOTE_ACTIVITY | Type in the Notes tab, stop for 30s | "Taking notes for ..." |
| SCREENSHOT_CAPTURED | Capture slide, keep | line appears only after "Keep" |
| IDLE_PROMPT_SHOWN / RESPONDED (fast) | Do nothing for 60s, click within 5s | shown + "answered in 2.1s" |
| ... (slow) | Click after 30s | "answered in 30s" |
| IDLE_CONFIRMED + late RESPONDED + RETURNED | Ignore for 2 minutes, then click | confirmed idle, late answer, idle duration |
| LEFT_CLASS | Click Leave call | "Left the class" |
| LEFT_CLASS (inferred) | Kill Chrome from Task Manager mid-class, reopen 5 min later | "Left the class (inferred ...)" at last heartbeat time |
| MONITORING_STOPPED | Disable then re-enable the extension mid-class with Meet still open | "Monitoring stopped (gap detected afterwards)" |
| CONSENT_DECLINED | Decline in the dialog, join; or stop sharing mid-class | the single "No tracking record..." line |

## Must never happen
- Prompt appears while you are on another tab / app, or while typing notes.
- Prompt appears twice within the cooldown.
- Anything is logged or uploaded before you press Accept, or after you press Stop.
- A declined student has any row except the one marker line (check Firestore too).
- The consent text and the actual behaviour disagree (change `Options` values and re-read the dialog).

## Screenshot failures (should each show a friendly message and save/log nothing)
Minimized window; Meet not the active tab; capture twice in under a second; cancel in the crop dialog; try on a non-Meet tab.

## Server checks
Offline: turn Wi-Fi off, take notes and switch tabs, turn it on: events appear in Firestore, in order.
Revoke: Stop sharing mid-class: member becomes `DECLINED`, last event is `CONSENT_DECLINED`, session `closed`, no events after it.
Change class: linking a different code asks for consent again and the text names the new professor.
Edit details: changing the student number applies from the next class (the current session keeps the old id).
