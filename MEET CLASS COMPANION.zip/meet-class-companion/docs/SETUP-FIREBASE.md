# Setting up Firebase (about 20 minutes)

This is what turns "student exports a file" into "professor gets the report automatically".
The extension works without it (notes + hand-in file). Do this once, as the professor or the course admin.

**Free plan (Spark) is enough for everything except the emailed report.** The email needs a scheduled Cloud Function,
which Google only runs on the pay-as-you-go (Blaze) plan. The dashboard shows the same report live on the free plan.

## 1. Create the project
1. https://console.firebase.google.com > **Add project**.
2. **Project settings > Your apps > Web (</>)**: register an app. Copy the config (`apiKey`, `authDomain`, `projectId`).
3. Paste `apiKey` + `projectId` into **`src/sync/firebaseConfig.js`** (extension) and all three into
   **`dashboard/public/firebase-config.js`** (dashboard).
   The apiKey identifies your project; it is not a secret. The rules below are what protect the data.

## 2. Sign-in methods
**Authentication > Sign-in method**: enable **Anonymous** (students' extensions) and **Google** (professors).
Authentication > Settings > Authorized domains: make sure `<project>.web.app` is listed.

## 3. Database, rules and hosting: `firebase init` walkthrough
You do not strictly need `firebase init`: this folder already contains `firebase.json`, `firestore.rules` and the dashboard.
If you run it anyway, answer exactly like this (the **No** answers protect files that are already correct):

1. `npm i -g firebase-tools`, then `firebase login`.
2. In the project folder (the one containing `manifest.json`): `firebase init`. "Are you ready to proceed?" **Yes**.
3. "Which features?" Press **Space** to tick **Firestore** and **Hosting** only, then Enter.
   Do **not** tick Functions, Extensions, Storage, Emulators or App Hosting: Extensions and Functions need the paid Blaze plan and are what makes a deploy fail on the free plan.
4. "Please select an option": **Use an existing project**, then pick your project.
5. Firestore questions:
   - "What file should be used for Firestore Rules?" press **Enter** (`firestore.rules`).
   - "File firestore.rules already exists. Overwrite?" **No**.
   - "What file should be used for Firestore indexes?" press **Enter**; if it asks to overwrite: **No**.
   - If it asks to create the database or pick a location, it already exists: accept the default or skip.
6. Hosting questions:
   - "Do you want to use a web framework?" **No**.
   - "What do you want to use as your public directory?" type **`dashboard/public`** (not `public`).
   - "Configure as a single-page app (rewrite all urls to /index.html)?" **No**.
   - "Set up automatic builds and deploys with GitHub?" **No**.
   - "File dashboard/public/index.html already exists. Overwrite?" **No** (Yes would replace the dashboard with a placeholder page).
7. When it finishes, open `firebase.json`. It must contain only `firestore` and `hosting`:
   ```json
   {
     "firestore": { "rules": "firestore.rules", "indexes": "firestore.indexes.json" },
     "hosting": { "public": "dashboard/public", "ignore": ["firebase.json", "**/.*", "**/node_modules/**"] }
   }
   ```
   Delete any `extensions` or `functions` block that `init` added.
8. Check that `dashboard/public/app.js` and `dashboard/public/lib/` still exist. If `init` replaced `index.html`, copy it back from the original zip.

## 3b. Deploy (free plan)
```
node tools/sync-libs.mjs
firebase deploy --only firestore:rules,hosting
```
Always use `--only`: a bare `firebase deploy` also tries Extensions/Functions and stops with "must be on the Blaze plan".
The dashboard is then at `https://<project-id>.web.app`.

## 4. Automatic deletion (retention)
Every uploaded document carries an `expireAt` date (class retention, default 120 days).
**Firestore > Time-to-live > Create policy**, twice: collection group `sessions` field `expireAt`, and collection group `events` field `expireAt`.
Google deletes expired documents within about a day or two. The consent form promises this, so do not skip it.

## 5. Use the dashboard
Open `https://<project>.web.app` (deployed in 3b), sign in with Google, **Create class**. You get an 8-character **class code**: give it to students.

## 6. Optional: the emailed report after each meeting
1. Upgrade the project to Blaze (set a small budget alert; a class costs cents).
2. **Extensions > Install "Trigger Email from Firestore"** and enter your SMTP details (it sends whatever lands in the `mail` collection).
3. ```
   cd functions && npm install && cd ..
   echo "DASHBOARD_URL=https://<project>.web.app" > functions/.env
   ```
   Then add this to `firebase.json` (next to `hosting`) and deploy: `"functions": [{ "source": "functions", "codebase": "default" }]` and `firebase deploy --only functions`.
4. In the dashboard, tick **Email me a report after each meeting**. Five minutes after the last student closes (or goes silent for 10 minutes) you get one email per meeting.

## 7. Load the extension and test it end to end
1. `chrome://extensions` > Developer mode > Load unpacked > this folder (reload it after editing `firebaseConfig.js`).
2. Join a Meet call. In the consent dialog enter the class code, **Link class**: the text now names you and the class. Accept.
3. Within about 10 seconds the **Firestore console** shows `classes/<id>/members/<uid>` and `sessions/<id>/events/...`.
4. Dashboard > your class > **Refresh** > open the meeting. Switch tabs for 30 seconds and refresh again to see it appear.

## Before real students: test the rules
The rules were written carefully but **have not been run against the Firebase emulator**. Run `firebase emulators:start` and
check at least these (they are the promises the consent form makes):
- a student cannot read any session or event, including their own events of another student;
- a student cannot update or delete an event, or edit a closed session;
- a student with `consentStatus: 'DECLINED'` cannot create events (except `CONSENT_DECLINED`);
- a student cannot write to a class they have not linked, or to someone else's session;
- a signed-in professor can read only their own classes; an anonymous user cannot create a class or a join code;
- `joinCodes` can be read one at a time but never listed.
