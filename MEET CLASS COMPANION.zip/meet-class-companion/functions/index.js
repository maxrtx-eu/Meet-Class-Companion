// OPTIONAL. Emails the professor a report once a meeting is over. Needs the Blaze (pay-as-you-go) plan and the
// "Trigger Email from Firestore" extension (it sends whatever is written to the `mail` collection).
// Without this function everything still works: the dashboard shows the report live.
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { groupMeetings, meetingIsOver, buildEmail } from './report.js';
import { summarizeSession } from './lib/shared/timeline.js';
import { verifyChain } from './lib/shared/hash.js';
import { pickEvent } from './lib/shared/eventShape.js';

initializeApp();
const db = getFirestore();
const DASHBOARD_URL = process.env.DASHBOARD_URL ?? '';   // e.g. https://your-project.web.app

export const meetingReports = onSchedule({ schedule: 'every 5 minutes', timeZone: 'UTC' }, async () => {
  const now = Date.now();
  const since = new Date(now - 3 * 86_400_000).toISOString().slice(0, 10);
  const classes = await db.collection('classes').where('emailReports', '==', true).get();

  for (const c of classes.docs) {
    const cls = c.data();
    const sessSnap = await c.ref.collection('sessions').where('date', '>=', since).get();
    const sessions = sessSnap.docs.map((d) => ({ sessionId: d.id, ref: d.ref, ...d.data() }));

    for (const g of groupMeetings(sessions).values()) {
      if (!meetingIsOver(g, now)) continue;
      const reportRef = c.ref.collection('reports').doc(g.key);
      try { await reportRef.create({ createdAt: now, sessionCount: g.sessions.length }); } catch { continue; }   // already reported

      const rows = [];
      for (const s of g.sessions) {
        const events = (await s.ref.collection('events').orderBy('seq').get()).docs.map((d) => pickEvent(d.data()));
        const session = { sessionId: s.sessionId, studentId: s.studentId, displayName: s.displayName, meetCode: s.meetCode, date: s.date, startTs: s.startTs ?? null, endTs: s.endTs ?? null, status: s.status, declinedMarker: !!s.declinedMarker };
        rows.push({ summary: summarizeSession(session, events, { now }).summary, chainOk: (await verifyChain(events)).ok, uid: s.uid });
      }
      const seen = new Set(rows.map((r) => r.uid));
      const members = (await c.ref.collection('members').get()).docs.map((d) => ({ uid: d.id, ...d.data() }));
      const missing = members.filter((m) => !seen.has(m.uid)).map((m) => m.displayName || m.studentId);
      const mail = buildEmail({ className: cls.className, meetCode: g.meetCode, date: g.date, rows, missing, dashboardUrl: DASHBOARD_URL });
      await db.collection('mail').add({ to: [cls.professorEmail], message: { subject: mail.subject, text: mail.text, html: mail.html } });
    }
  }
});
