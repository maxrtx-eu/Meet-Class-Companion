import test from 'node:test';
import assert from 'node:assert/strict';
import { groupMeetings, meetingIsOver, buildEmail } from './report.js';

const sess = (over) => ({ sessionId: 's', meetCode: 'abc-defg-hij', date: '2026-10-06', status: 'open', lastSeen: 1_000_000, ...over });

test('sessions are grouped per meeting and day', () => {
  const g = groupMeetings([sess({}), sess({ sessionId: 't' }), sess({ date: '2026-10-07' }), sess({ meetCode: 'zzz-zzzz-zzz' })]);
  assert.equal(g.size, 3);
  assert.equal(g.get('abc-defg-hij_2026-10-06').sessions.length, 2);
});

test('a meeting is over when every session is closed or has been silent for 10 minutes', () => {
  const now = 1_000_000 + 11 * 60_000;
  assert.equal(meetingIsOver({ sessions: [sess({ status: 'closed' }), sess({ lastSeen: 1_000_000 })] }, now), true);
  assert.equal(meetingIsOver({ sessions: [sess({ status: 'closed' }), sess({ lastSeen: now - 60_000 })] }, now), false);
  assert.equal(meetingIsOver({ sessions: [] }, now), false);
});

test('the email escapes student-controlled text and lists declined and missing students', () => {
  const summary = (name, status = 'completed') => ({ studentId: '1', displayName: name, status, percent: { engaged: 90, noteTaking: 10, confirmedIdle: 2, away: 8, unmonitored: 0 }, prompts: { avgResponseSec: 3.2 } });
  const mail = buildEmail({
    className: 'CS 101', meetCode: 'abc-defg-hij', date: '2026-10-06', dashboardUrl: 'https://x.web.app',
    rows: [{ summary: summary('<script>alert(1)</script>'), chainOk: true }, { summary: { ...summary('Bo', 'declined') }, chainOk: true }, { summary: summary('Cy'), chainOk: false }],
    missing: ['Di & Co'],
  });
  assert.doesNotMatch(mail.html, /<script>/);
  assert.match(mail.html, /&lt;script&gt;/);
  assert.match(mail.html, /Declined tracking:<\/b> Bo/);
  assert.match(mail.html, /Di &amp; Co/);
  assert.match(mail.html, /BROKEN/);
  assert.match(mail.subject, /CS 101, 2026-10-06/);
});
