// Pure helpers for the scheduled "report after the meeting" function (unit-tested without Firebase).
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function groupMeetings(sessions) {
  const map = new Map();
  for (const s of sessions) {
    const key = `${s.meetCode}_${s.date}`;
    if (!map.has(key)) map.set(key, { key, meetCode: s.meetCode, date: s.date, sessions: [] });
    map.get(key).sessions.push(s);
  }
  return map;
}

/** A meeting is over when every student session is closed, or has been silent for `quietMs` (browser closed, offline). */
export function meetingIsOver(group, now, quietMs = 10 * 60_000) {
  return group.sessions.length > 0 && group.sessions.every((s) => s.status === 'closed' || (s.lastSeen ?? s.startTs ?? 0) < now - quietMs);
}

/** @param rows [{summary, chainOk}]  @param missing member names with no record for this meeting */
export function buildEmail({ className, meetCode, date, rows, missing = [], dashboardUrl = '' }) {
  const tracked = rows.filter((r) => r.summary.status !== 'declined');
  const declined = rows.filter((r) => r.summary.status === 'declined');
  const pct = (n) => (n == null ? '' : `${n}%`);
  const tr = tracked.map((r) => {
    const s = r.summary;
    return `<tr><td>${esc(s.displayName || s.studentId)}<br><small>${esc(s.studentId)}</small></td><td align="right">${pct(s.percent.engaged)}</td><td align="right">${pct(s.percent.noteTaking)}</td><td align="right">${pct(s.percent.confirmedIdle)}</td><td align="right">${pct(s.percent.away)}</td><td align="right">${pct(s.percent.unmonitored)}</td><td align="right">${s.prompts.avgResponseSec == null ? 'none' : `${s.prompts.avgResponseSec}s`}</td><td>${r.chainOk ? 'intact' : '<b style="color:#b3261e">BROKEN</b>'}</td></tr>`;
  }).join('');
  const subject = `Attendance report: ${className}, ${date} (${meetCode})`;
  const html = `<div style="font-family:Segoe UI,Arial,sans-serif;max-width:760px">
<h2 style="margin:0 0 4px">${esc(className)}</h2><p style="margin:0 0 12px;color:#555">Meeting ${esc(meetCode)}, ${esc(date)}. ${tracked.length} student(s) tracked, ${declined.length} declined.</p>
<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:14px" border="1" bordercolor="#d5ddd9">
<tr style="background:#e9eeec"><th align="left">Student</th><th>Engaged</th><th>Notes</th><th>Idle</th><th>Away</th><th>Not monitored</th><th>Avg answer</th><th align="left">Log</th></tr>${tr}</table>
${declined.length ? `<p><b>Declined tracking:</b> ${declined.map((r) => esc(r.summary.displayName || r.summary.studentId)).join(', ')}</p>` : ''}
${missing.length ? `<p><b>Linked the class but no record for this meeting:</b> ${missing.map(esc).join(', ')} (absent, on a phone, or not using the extension: this report cannot tell which).</p>` : ''}
${dashboardUrl ? `<p><a href="${esc(dashboardUrl)}">Open the full report and per-student details</a></p>` : ''}
<p style="color:#666;font-size:12px">Generated automatically after the meeting. Students who were offline may sync later; the dashboard always shows the latest data. Treat these numbers as evidence to discuss with a student, not a verdict.</p></div>`;
  const text = [`${className}, ${date} (${meetCode})`, ...tracked.map((r) => `${r.summary.displayName || r.summary.studentId}: engaged ${pct(r.summary.percent.engaged)}, idle ${pct(r.summary.percent.confirmedIdle)}, away ${pct(r.summary.percent.away)}, log ${r.chainOk ? 'intact' : 'BROKEN'}`),
    declined.length ? `Declined tracking: ${declined.map((r) => r.summary.displayName || r.summary.studentId).join(', ')}` : '', dashboardUrl].filter(Boolean).join('\n');
  return { subject, html, text };
}
