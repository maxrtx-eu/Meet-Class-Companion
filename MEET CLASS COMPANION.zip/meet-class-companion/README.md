# Meet Class Companion

A Chrome extension (Manifest V3) for Google Meet classes with two sides:

- **For students:** a private notes workspace inside Meet (notes, slide screenshots with crop review, Markdown / PDF export).
- **For professors:** an opt-in attention log (tab and window focus, the "Are you still there?" check, note-taking time, leaving class), turned into a report that arrives **automatically after the meeting**.

Note-taking shows up in the log as "taking notes", not as an unexplained gap. Students can see exactly what is logged, live, and can stop at any time.

## How the report reaches the professor

1. The professor signs in to the **dashboard** (Firebase Hosting, Google sign-in), creates a class and gets an 8-character **class code**.
2. Each student enters the code **once** in the extension. The consent form then names the professor and class, and says the log is uploaded. Nothing is uploaded before the student presses Accept.
3. While the student is in class, events are saved locally first and uploaded in the background (works offline, retries, never loses data).
4. When the meeting ends, the dashboard already shows the report, and (optional Cloud Function) the professor gets an **email** with the class table. If a professor wants more detail, the student exports a **detailed file** and the professor opens it in the offline viewer (`report/professor-report-viewer.html`, double-click, nothing is uploaded).

Without Firebase configured the extension still works: notes, and a hand-in file the student sends manually. Meet does not tell extensions who the host is, which is why a class code (not the Meet link) connects a student to a professor.

## Install

1. **Students / testing:** `chrome://extensions` > Developer mode > **Load unpacked** > this folder. Chrome 120+. Open a Meet call; the consent dialog appears in the waiting room. (Browsers without the side panel API open the same panel as a small window.)
2. **Professor / admin, once:** follow **docs/SETUP-FIREBASE.md** (about 20 minutes). Until you fill in `src/sync/firebaseConfig.js` the extension uploads nothing.
3. Settings (right-click the toolbar icon > Options): prompt after N seconds idle, time to answer, quiet time after an answer, adaptive mode, tab-switch grace period, chime. The consent text always shows the live values.
4. Corner badge in every meeting: **Attention log on / off / not set**. Click it to edit name and student number, link a class, open notes, or turn the log off or on.

## The consent form (verbatim)

**Without a class code** (nothing is uploaded; the student hands in a file):

### Your choice: share an attention log for this class?

Class Companion gives you a private notes workspace inside Google Meet (notes and screenshots of the slides). Separately, and only if you say yes, it keeps an attention log for your professor.

**What is logged if you say yes**

- When you switch to another browser tab or window, when Chrome loses focus or your screen locks, and when you come back.
- When you leave the class, or the tab or browser closes.
- Whether you answered the "Are you still there?" popup, and how fast.
- When you are taking notes: the time and how long, never what you wrote.
- The name and student number you enter below.

**What is never logged or shared**

- What you type (no keystrokes), your notes and your screenshots.
- Which other sites or apps you use. The extension cannot see them.
- Your camera, microphone or screen.

**Who sees it**

- Your professor, in a report you export and hand in yourself. Nothing is uploaded. You can watch the exact log build up, live, in the side panel.

**The "Are you still there?" popup**

- If you have not touched the keyboard or mouse in the class tab for about 1 minute, a large box asks "Are you still there?". Click "Yes, I'm here" and you are recorded as present, along with how quickly you clicked.
- If you do not click within about 1 minute, you are recorded as idle until you click or leave.
- After any answer it will not appear again for at least 5 minutes. It never appears while you are in another tab or window, or while you are typing in your notes.

**What you get**

- Private notes and slide screenshots that only you can see, whichever way you choose.
- Your own session report.
- If you say yes, time spent taking notes shows up as "taking notes" instead of an unexplained gap.

**If you say no**

- Nothing is tracked. The only record is one line per class: "No tracking record. Student declined tracking."
- Notes and screenshots still work.
- You can change your mind any time in the side panel. Stopping mid-class stops logging immediately and adds the same line.

A small "Attention log on" badge stays visible the whole time logging is active.

**With a class code** (example: class "CS 101, Section A", Dr. Reyes, 120 days):

### Your choice: share an attention log for this class?

Class Companion gives you a private notes workspace inside Google Meet (notes and screenshots of the slides). Separately, and only if you say yes, it keeps an attention log for your professor.

**What is logged if you say yes**

- When you switch to another browser tab or window, when Chrome loses focus or your screen locks, and when you come back.
- When you leave the class, or the tab or browser closes.
- Whether you answered the "Are you still there?" popup, and how fast.
- When you are taking notes: the time and how long, never what you wrote.
- The name and student number you enter below, and the class you linked. They are uploaded with the log.

**What is never logged or shared**

- What you type (no keystrokes), your notes and your screenshots.
- Which other sites or apps you use. The extension cannot see them.
- Your camera, microphone or screen.

**Who sees it**

- Dr. Reyes, for the class "CS 101, Section A". The log is uploaded to a secure Google Firebase database while you are in class, and your professor gets a report automatically after the meeting. Nobody else can read it.
- It is deleted automatically after 120 days.
- You can watch the exact log build up, live, in the side panel. If your professor wants more detail, you export a file yourself.

**The "Are you still there?" popup**

- If you have not touched the keyboard or mouse in the class tab for about 1 minute, a large box asks "Are you still there?". Click "Yes, I'm here" and you are recorded as present, along with how quickly you clicked.
- If you do not click within about 1 minute, you are recorded as idle until you click or leave.
- After any answer it will not appear again for at least 5 minutes. It never appears while you are in another tab or window, or while you are typing in your notes.

**What you get**

- Private notes and slide screenshots that only you can see, whichever way you choose.
- Your own session report.
- If you say yes, time spent taking notes shows up as "taking notes" instead of an unexplained gap.

**If you say no**

- Nothing is tracked. The only record, sent to your professor, is one line per class: "No tracking record. Student declined tracking." It shows the date and your name, nothing else.
- Notes and screenshots still work.
- You can change your mind any time in the side panel or the corner badge. Stopping mid-class stops logging immediately and adds the same line.

A small "Attention log on" badge stays visible the whole time logging is active.

## What was verified

- **68 automated tests pass** (`npm test`, Node 20+, no installs): the idle prompt (fast / slow / never / late answer, adaptive, cooldown, laptop sleep), consent gate and decline marker, revocation mid-session, hash chain, focus episodes (grace period, tab, other app, second monitor, picture-in-picture, screen lock), notes bursts, closed-browser and re-enabled-extension inference, the timeline and summary maths, CSV safety, the sync engine against a fake Firestore (chunking, lost replies, backoff, revocation ordering), the email report, and that no professor-bound code touches notes storage, and that what the extension uploads matches `firestore.rules` field for field.
- **Seen working in real Chrome (by the tester, earlier builds):** loading the extension and the consent dialog. **Not yet re-confirmed after the latest changes:** the side-panel fallback window, notes, screenshot capture, the corner badge's profile editor and class linking.
- **Not run against real services (do this before real students):** the Firebase upload against a live project, `firestore.rules` in the emulator, the dashboard, the Cloud Function, and Meet detection after Google changes its page. See **docs/SETUP-FIREBASE.md** (rule checklist) and **docs/MANUAL_QA.md**.

## Honest limitations (tell students and professors)

**What it can and cannot see**
- It sees that Chrome lost focus, never **which** app took it, and never the content of other tabs (it has no permission to read them).
- It records **that** a student typed in their notes, never what. It cannot tell note-taking from pretending to take notes.
- Picture-in-picture, a second monitor and a locked screen are reported in their own rows. They are ambiguous, so the professor decides what they mean.

**What it cannot stop**
- A student can disable or uninstall the extension, use a phone, the Meet app, another browser, or a second device. None of these can be prevented. Disabling is recorded afterwards as an **inferred** "monitoring stopped" gap, never as a reason.
- Input checks can be defeated (a mouse mover plus an automated click). The prompt needs a click, which raises the bar but does not make it proof.
- Identity is **self-declared** (a name and student number, plus an anonymous Firebase account). Anyone with the class code can link and pick any name. The upgrade is school Google sign-in with a domain check; not built.
- Event times come from the student's computer clock. Uploaded events cannot be edited or deleted afterwards (the rules forbid it), but a determined student could fabricate a log **before** it is uploaded. The hash chain makes later edits visible; it does not prove authenticity.

**Fairness and privacy**
- A missing report proves nothing: absent, offline, phone and not-using-the-extension look the same. The dashboard says so.
- "Idle" starts only after a prompt goes unanswered, so quietly listening is never counted as idle.
- Students can decline, and the notes tool works either way. Consent is per class and per version of the text; changing either asks again.
- Data is stored in your Firebase project (Google Cloud), readable only by the professor who owns the class, and deleted automatically after the retention period. Students cannot delete uploaded data from the extension; the professor can, from the Firebase console.
- Logging students usually needs your institution's approval (privacy office / ethics board). This is not legal advice.
- Students should follow the course's rules about screenshots of lectures.

**Maintenance**
- Meet's page structure is not a public API. If the badge stops appearing in calls, update `src/content/meetDetector.js` (all Meet-specific selectors live there).

## Map of the code

```
manifest.json            permissions: storage, alarms, sidePanel, idle, scripting; hosts: meet.google.com + 3 Firebase endpoints
src/background/          service worker: consent gate, the only event writer (logger), sessions, focus, notes, push state
src/content/             in-Meet code: page detection, input timestamps, idle clock, corner badge, consent + prompt UI
src/shared/              pure logic used everywhere: idle state machine, timeline + summary, hash chain, consent text, report views
src/storage/             attendance-log database (separate from the private notes database)
src/sync/                Firebase REST client + local-first upload engine (no SDK inside the extension)
src/sidepanel/           Notes, My log, Privacy; screenshot capture and crop; Markdown and PDF export
src/export/              CSV, hand-in file, download helper (professor-bound code; never imports notes storage)
dashboard/public/        professor web app (Firebase Hosting)     functions/   optional email report
report/                  offline viewer for hand-in files (built by tools/build-report.mjs)
firestore.rules          the server-side promises: consent check, create-only events, owner-only reads
```

After editing anything in `src/shared` or `src/export`: `node tools/sync-libs.mjs && node tools/build-report.mjs`.

## Not built (outline)

- Live in-class dashboard (the data model already supports it: sessions update their `lastSeen` every few seconds; add `onSnapshot` listeners).
- Courtesy notification when Chrome has lost focus for a while (optional in the brief; skipped).
- School-account sign-in, class-code rotation, student-side deletion of uploaded data, a Playwright end-to-end suite.
