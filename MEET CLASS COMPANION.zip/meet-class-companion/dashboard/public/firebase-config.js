// Same project as the extension. Firebase console > Project settings > Your apps > Web app > SDK setup.
export const firebaseConfig = {
  apiKey: 'AIzaSyCt8cEKXHEqgb_XkWO56cbP54eipSRXzm4',
  authDomain: 'class-companion-ce085.firebaseapp.com',
  projectId: 'class-companion-ce085',
};
