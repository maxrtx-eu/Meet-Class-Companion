// Professor dashboard: sign in with Google, create a class (get a class code), open a meeting report.
// Everything is computed in the browser from what the students' extensions uploaded, with the same code as the extension.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore, collection, doc, getDoc, getDocs, query, where, orderBy, writeBatch, updateDoc } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { firebaseConfig } from './firebase-config.js';
import { h } from './lib/shared/dom.js';
import { pickEvent } from './lib/shared/eventShape.js';
import { verifyChain } from './lib/shared/hash.js';
import { summarizeSession } from './lib/shared/timeline.js';
import { studentsTable, studentDetail, reportFooter } from './lib/shared/reportView.js';
import { eventsCsv, summaryCsv } from './lib/export/csv.js';
import { buildHandIn, handInFilename } from './lib/export/handIn.js';
import { download, safeName } from './lib/export/download.js';

const root = document.getElementById('app');
if (!firebaseConfig.apiKey) { root.replaceChildren(h('p', { class: 'box bad' }, 'Fill in dashboard/public/firebase-config.js first (see docs/SETUP-FIREBASE.md).')); throw new Error('not configured'); }

const fb = initializeApp(firebaseConfig);
const auth = getAuth(fb);
const db = getFirestore(fb);

const S = { user: null, classes: [], cls: null, sessions: [], members: [], meetingKey: null, results: [], selected: 0, busy: '', error: '' };
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';    // no 0/O/1/I/L: easy to read out loud
const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => ALPHABET[b % ALPHABET.length]).join('');

const fail = (e) => { S.error = e?.message ?? String(e); S.busy = ''; render(); };

onAuthStateChanged(auth, async (u) => { S.user = u; if (u) await loadClasses(); render(); });

async function loadClasses() {
  const snap = await getDocs(query(collection(db, 'classes'), where('ownerUid', '==', S.user.uid)));
  S.classes = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

async function openClass(id) {
  S.busy = 'Loading class...'; S.error = ''; render();
  try {
    S.cls = S.classes.find((c) => c.id === id);
    const [ss, ms] = await Promise.all([getDocs(collection(db, 'classes', id, 'sessions')), getDocs(collection(db, 'classes', id, 'members'))]);
    S.sessions = ss.docs.map((d) => ({ sessionId: d.id, ...d.data() }));
    S.members = ms.docs.map((d) => ({ uid: d.id, ...d.data() }));
    S.meetingKey = null; S.results = [];
  } catch (e) { return fail(e); }
  S.busy = ''; render();
}

function meetings() {
  const map = new Map();
  for (const s of S.sessions) {
    const key = `${s.meetCode}|${s.date}`;
    if (!map.has(key)) map.set(key, { key, meetCode: s.meetCode, date: s.date, sessions: [] });
    map.get(key).sessions.push(s);
  }
  return [...map.values()].sort((a, b) => b.date.localeCompare(a.date) || a.meetCode.localeCompare(b.meetCode));
}

async function openMeeting(key) {
  S.busy = 'Checking every student\'s log...'; S.error = ''; S.meetingKey = key; render();
  try {
    const group = meetings().find((m) => m.key === key);
    S.results = await Promise.all(group.sessions.map(async (s) => {
      const snap = await getDocs(query(collection(db, 'classes', S.cls.id, 'sessions', s.sessionId, 'events'), orderBy('seq')));
      const events = snap.docs.map((d) => pickEvent(d.data()));
      const session = { sessionId: s.sessionId, studentId: s.studentId, displayName: s.displayName, meetCode: s.meetCode, date: s.date, startTs: s.startTs ?? null, endTs: s.endTs ?? null, status: s.status, declinedMarker: !!s.declinedMarker };
      const chain = await verifyChain(events);
      return { session, events, chain, uid: s.uid, ...summarizeSession(session, events, { now: Date.now() }) };
    }));
    S.results.sort((a, b) => (a.summary.displayName || a.summary.studentId || '').localeCompare(b.summary.displayName || b.summary.studentId || ''));
    S.selected = 0;
  } catch (e) { return fail(e); }
  S.busy = ''; render();
}

async function createClass(form) {
  const d = Object.fromEntries(new FormData(form));
  S.busy = 'Creating class...'; S.error = ''; render();
  try {
    let code = newCode();
    while ((await getDoc(doc(db, 'joinCodes', code))).exists()) code = newCode();
    const classRef = doc(collection(db, 'classes'));
    const retentionDays = Math.min(365, Math.max(7, Number(d.retentionDays) || 120));
    const batch = writeBatch(db);
    batch.set(classRef, { ownerUid: S.user.uid, className: d.className.trim(), professorName: d.professorName.trim(), professorEmail: d.professorEmail.trim(), retentionDays, emailReports: d.emailReports === 'on', joinCode: code, createdAt: Date.now() });
    batch.set(doc(db, 'joinCodes', code), { classId: classRef.id, className: d.className.trim(), professorName: d.professorName.trim(), retentionDays, ownerUid: S.user.uid });
    await batch.commit();
    await loadClasses();
    await openClass(classRef.id);
  } catch (e) { fail(e); }
}

async function setEmailReports(on) {
  try { await updateDoc(doc(db, 'classes', S.cls.id), { emailReports: on }); S.cls.emailReports = on; } catch (e) { fail(e); }
}

// ---------- views ----------
function render() {
  const kids = [h('header', { class: 'topbar' }, h('div', {}, h('h1', {}, 'Class Companion'), h('p', {}, 'Professor dashboard')),
    S.user ? h('div', {}, h('span', {}, S.user.email + ' '), h('button', { type: 'button', onclick: () => signOut(auth) }, 'Sign out')) : null)];
  if (S.error) kids.push(h('p', { class: 'box bad', role: 'alert' }, S.error));
  if (S.busy) kids.push(h('p', { class: 'box', role: 'status' }, S.busy));
  if (!S.user) kids.push(h('p', {}, 'Sign in to create a class and see reports.'), h('button', { class: 'solid', type: 'button', onclick: () => signInWithPopup(auth, new GoogleAuthProvider()).catch(fail) }, 'Sign in with Google'));
  else if (!S.cls) kids.push(...classListView());
  else kids.push(...classView());
  app_set(kids);
}
const app_set = (kids) => root.replaceChildren(...kids);

function classListView() {
  const form = h('form', { class: 'card', onsubmit: (e) => { e.preventDefault(); createClass(e.target); } },
    h('h2', {}, 'Create a class'),
    h('label', {}, 'Class name', h('input', { type: 'text', name: 'className', required: true, maxlength: '80', placeholder: 'CS 101, Section A' })),
    h('label', {}, 'Your name (shown to students in the consent form)', h('input', { type: 'text', name: 'professorName', required: true, maxlength: '80', value: S.user.displayName ?? '' })),
    h('label', {}, 'Email for the automatic report', h('input', { type: 'email', name: 'professorEmail', required: true, value: S.user.email ?? '' })),
    h('label', {}, 'Keep data for (days)', h('input', { type: 'number', name: 'retentionDays', min: '7', max: '365', value: '120' })),
    h('label', {}, h('span', {}, h('input', { type: 'checkbox', name: 'emailReports', checked: true }), ' Email me a report after each meeting')),
    h('button', { class: 'solid', type: 'submit' }, 'Create class and get the class code'));
  return [h('h2', {}, 'Your classes'),
    S.classes.length ? h('div', { class: 'cards' }, S.classes.map((c) => h('button', { class: 'card-link', type: 'button', onclick: () => openClass(c.id) }, h('strong', {}, c.className), h('small', {}, `Class code ${c.joinCode}`)))) : h('p', { class: 'muted' }, 'No classes yet.'),
    form];
}

function classView() {
  const c = S.cls;
  const list = meetings();
  const kids = [
    h('button', { type: 'button', onclick: () => { S.cls = null; S.meetingKey = null; render(); } }, 'All classes'),
    h('h2', {}, c.className),
    h('p', {}, 'Give students this code. They enter it once in the extension; the consent form then names you and this class.'),
    h('p', {}, h('span', { class: 'codebox' }, c.joinCode)),
    h('p', {}, h('label', {}, h('input', { type: 'checkbox', checked: !!c.emailReports, onchange: (e) => setEmailReports(e.target.checked) }), ` Email ${c.professorEmail} a report after each meeting (needs the optional Cloud Function)`)),
    h('p', { class: 'muted' }, `${S.members.length} student(s) linked. Data is deleted after ${c.retentionDays} days.`),
    h('div', { class: 'row' }, h('button', { type: 'button', onclick: () => openClass(c.id) }, 'Refresh')),
    h('h3', {}, 'Meetings'),
  ];
  if (!list.length) kids.push(h('p', { class: 'muted' }, 'No meetings yet. Reports appear here as students join a class.'));
  else kids.push(h('table', { class: 'grid' }, h('thead', {}, h('tr', {}, ['Date', 'Meet code', 'Students', 'Declined', 'In progress', ''].map((t) => h('th', {}, t)))),
    h('tbody', {}, list.map((m) => h('tr', { class: 'clickable' + (m.key === S.meetingKey ? ' sel' : ''), tabindex: '0', onclick: () => openMeeting(m.key), onkeydown: (e) => { if (e.key === 'Enter') openMeeting(m.key); } },
      h('td', {}, m.date), h('td', {}, m.meetCode), h('td', { class: 'num' }, String(m.sessions.filter((s) => !s.declinedMarker).length)), h('td', { class: 'num' }, String(m.sessions.filter((s) => s.declinedMarker).length)),
      h('td', { class: 'num' }, String(m.sessions.filter((s) => s.status === 'open').length)), h('td', {}, 'Open report'))))));
  if (S.meetingKey && S.results.length) kids.push(...reportView());
  kids.push(reportFooter());
  return kids;
}

function reportView() {
  const [meetCode, date] = S.meetingKey.split('|');
  const present = new Set(S.results.map((r) => r.uid));
  const missing = S.members.filter((m) => !present.has(m.uid));
  const sel = S.results[Math.min(S.selected, S.results.length - 1)];
  const dl = (name, text, type) => () => download(name, text, type);
  const base = (r) => handInFilename(r.session, safeName).replace(/^attendance_/, '').replace(/\.json$/, '');
  return [
    h('h3', {}, `Report: ${meetCode}, ${date}`),
    studentsTable(S.results, S.selected, (i) => { S.selected = i; render(); }),
    h('div', { class: 'row' }, h('button', { type: 'button', onclick: dl(`summary_${safeName(meetCode)}_${date}.csv`, summaryCsv(S.results.map((r) => ({ ...r.summary, integrityOk: r.chain.ok }))), 'text/csv') }, 'Download summary CSV (all students)')),
    missing.length ? h('p', { class: 'box' }, h('strong', {}, 'Linked this class but no record for this meeting: '), missing.map((m) => `${m.displayName || m.studentId}${m.consentStatus === 'DECLINED' ? ' (declined)' : ''}`).join(', '), '. They may be absent, on a phone, or not using the extension; the dashboard cannot tell which.') : null,
    studentDetail(sel, [
      h('button', { type: 'button', onclick: dl(`events_${base(sel)}.csv`, eventsCsv(sel.session, sel.events), 'text/csv') }, 'Events CSV'),
      h('button', { type: 'button', onclick: dl(handInFilename(sel.session, safeName), buildHandIn({ session: sel.session, events: sel.events }), 'application/json') }, 'Detailed file (.json)'),
    ]),
  ];
}

render();
