// Turns an append-only event log into "where was the student, minute by minute" and a per-session summary.
// Pure functions: used by the student's own report, the CSV export and the professor's offline viewer.
//
// Principle: every moment belongs to exactly ONE state, so the percentages add up to 100.
// Ambiguous time gets its own labelled bucket (picture-in-picture, second monitor, locked screen) instead of
// being silently excused or silently counted as away. The professor decides what those mean.
import { EventType } from './schema.js';

export const State = Object.freeze({
  PRESENT: 'PRESENT',
  NOTE_TAKING: 'NOTE_TAKING',
  IDLE_CONFIRMED: 'IDLE_CONFIRMED',
  AWAY_TAB: 'AWAY_TAB',
  AWAY_WINDOW: 'AWAY_WINDOW',
  AWAY_PIP: 'AWAY_PIP',
  AWAY_OTHER_WINDOW_VISIBLE: 'AWAY_OTHER_WINDOW_VISIBLE',
  AWAY_SCREEN_LOCKED: 'AWAY_SCREEN_LOCKED',
  UNMONITORED: 'UNMONITORED',
});

// Higher wins where intervals overlap.
const PRIORITY = {
  UNMONITORED: 6,
  AWAY_TAB: 5, AWAY_WINDOW: 5, AWAY_PIP: 5, AWAY_OTHER_WINDOW_VISIBLE: 5, AWAY_SCREEN_LOCKED: 5,
  IDLE_CONFIRMED: 3, NOTE_TAKING: 2, PRESENT: 1,
};
export const isAway = (state) => state.startsWith('AWAY_');

const byTime = (a, b) => (a.ts ?? 0) - (b.ts ?? 0) || a.seq - b.seq;   // events can be back-dated, so order by time

function awayState(e) {
  const m = e.meta ?? {};
  if (e.eventType === EventType.FOCUS_LOST) return m.pip ? State.AWAY_PIP : State.AWAY_TAB;
  if (m.cause === 'screen_locked') return State.AWAY_SCREEN_LOCKED;
  if (m.focusTarget === 'other_chrome_window' && m.meetVisible) return State.AWAY_OTHER_WINDOW_VISIBLE;
  return State.AWAY_WINDOW;
}

export function sessionBounds(session, events, now) {
  const sorted = [...events].sort(byTime);
  const bySeq = [...events].sort((a, b) => a.seq - b.seq);
  const last = bySeq.at(-1);
  const joined = sorted.find((e) => e.eventType === EventType.JOINED_CLASS);
  const left = [...sorted].reverse().find((e) => e.eventType === EventType.LEFT_CLASS);
  const revoked = sorted.find((e) => e.eventType === EventType.CONSENT_DECLINED && e.meta?.reason === 'revoked');
  const start = joined?.ts ?? session.startTs ?? sorted.find((e) => e.ts != null)?.ts ?? now;

  let end;
  let endedBy;
  let trailingGapMs = 0;
  if (left) { end = left.ts; endedBy = left.meta?.inferred ? 'left_inferred' : 'left'; }
  else if (revoked) { end = revoked.ts; endedBy = 'revoked'; }
  else if (last?.eventType === EventType.MONITORING_STOPPED && session.status !== 'open') {
    end = last.ts; endedBy = 'monitoring_stopped'; trailingGapMs = last.durationMs ?? 0;
  } else if (session.endTs) { end = session.endTs; endedBy = 'closed'; }
  else { end = Math.max(now, start); endedBy = 'in_progress'; }
  return { start, end: Math.max(start, end), endedBy, trailingGapMs, sorted };
}

function buildIntervals(sorted, start, end) {
  const iv = [];
  const add = (s, e, state) => { if (e > s) iv.push({ s, e, state }); };

  for (const e of sorted) {
    if (e.eventType === EventType.NOTE_ACTIVITY && e.durationMs) add(e.ts, e.ts + e.durationMs, State.NOTE_TAKING);
    if (e.eventType === EventType.MONITORING_STOPPED && e.durationMs) add(e.ts, e.ts + e.durationMs, State.UNMONITORED);
  }

  // Away episodes: each FOCUS_LOST / WINDOW_UNFOCUSED starts a segment (closing the previous one), RETURNED ends the episode.
  let open = null;
  for (const e of sorted) {
    if (e.eventType === EventType.FOCUS_LOST || e.eventType === EventType.WINDOW_UNFOCUSED) {
      if (open) add(open.s, e.ts, open.state);
      open = { s: e.ts, state: awayState(e) };
    } else if (e.eventType === EventType.RETURNED && (e.meta?.from === EventType.FOCUS_LOST || e.meta?.from === EventType.WINDOW_UNFOCUSED)) {
      if (open) { add(open.s, e.ts, open.state); open = null; }
    }
  }
  if (open) add(open.s, end, open.state);

  let idleStart = null;
  for (const e of sorted) {
    if (e.eventType === EventType.IDLE_CONFIRMED) idleStart = e.ts;
    else if (e.eventType === EventType.RETURNED && e.meta?.from === 'IDLE_CONFIRMED' && idleStart != null) { add(idleStart, e.ts, State.IDLE_CONFIRMED); idleStart = null; }
  }
  if (idleStart != null) add(idleStart, end, State.IDLE_CONFIRMED);

  return iv.map((x) => ({ ...x, s: Math.max(start, x.s), e: Math.min(end, x.e) })).filter((x) => x.e > x.s);
}

function sweep(start, end, intervals) {
  const points = new Set([start, end]);
  for (const x of intervals) { points.add(x.s); points.add(x.e); }
  const xs = [...points].sort((a, b) => a - b);
  const segments = [];
  for (let i = 0; i < xs.length - 1; i++) {
    const a = xs[i];
    const b = xs[i + 1];
    let best = State.PRESENT;
    for (const x of intervals) if (x.s <= a && x.e >= b && PRIORITY[x.state] > PRIORITY[best]) best = x.state;
    const prev = segments.at(-1);
    if (prev && prev.state === best && prev.end === a) prev.end = b;
    else segments.push({ state: best, start: a, end: b });
  }
  return segments;
}

function median(sorted) {
  if (!sorted.length) return null;
  const m = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[m] : (sorted[m - 1] + sorted[m]) / 2;
}
const round1 = (x) => Math.round(x * 10) / 10;

/** "Are you still there?" statistics. Confirmed idle time is reported separately from how fast people answered. */
export function promptStats(events) {
  const shown = new Set();
  const confirmed = new Set();
  const onTime = [];
  const late = new Set();
  for (const e of events) {
    const id = e.meta?.promptId ?? `seq${e.seq}`;
    if (e.eventType === EventType.IDLE_PROMPT_SHOWN) shown.add(id);
    else if (e.eventType === EventType.IDLE_CONFIRMED) confirmed.add(id);
    else if (e.eventType === EventType.IDLE_PROMPT_RESPONDED) {
      if (e.meta?.late) late.add(id); else onTime.push({ id, sec: e.meta?.responseSec ?? 0, speed: e.meta?.speed });
    }
  }
  const answeredIds = new Set(onTime.map((r) => r.id));
  const secs = onTime.map((r) => r.sec).sort((a, b) => a - b);
  return {
    shown: shown.size,
    answered: onTime.length,
    answeredLate: late.size,
    neverAnswered: [...confirmed].filter((id) => !late.has(id)).length,
    cancelled: [...shown].filter((id) => !answeredIds.has(id) && !confirmed.has(id)).length,   // student left the tab first
    avgResponseSec: secs.length ? round1(secs.reduce((a, b) => a + b, 0) / secs.length) : null,
    medianResponseSec: secs.length ? round1(median(secs)) : null,
    fast: onTime.filter((r) => r.speed === 'fast').length,
    medium: onTime.filter((r) => r.speed === 'medium').length,
    slow: onTime.filter((r) => r.speed === 'slow').length,
  };
}

const longestRun = (segments, pred) => {
  let best = 0;
  let run = 0;
  for (const s of segments) { if (pred(s.state)) { run += s.end - s.start; best = Math.max(best, run); } else run = 0; }
  return best;
};

/**
 * @returns {{summary, segments, bounds}}  summary.status: declined | revoked | completed | monitoring_stopped | in_progress
 */
export function summarizeSession(session, events, { now = Date.now() } = {}) {
  const ident = { sessionId: session.sessionId, studentId: session.studentId, displayName: session.displayName ?? '', meetCode: session.meetCode, date: session.date };

  if (session.declinedMarker && !events.some((e) => e.eventType === EventType.JOINED_CLASS)) {
    const marker = events.find((e) => e.eventType === EventType.CONSENT_DECLINED);
    return { summary: { ...ident, status: 'declined', text: marker?.meta?.text ?? 'No tracking record. Student declined tracking.' }, segments: [], bounds: null };
  }

  const bounds = sessionBounds(session, events, now);
  const { start, end } = bounds;
  const segments = sweep(start, end, buildIntervals(bounds.sorted, start, end));
  const ms = Object.fromEntries(Object.values(State).map((k) => [k, 0]));
  for (const s of segments) ms[s.state] += s.end - s.start;

  const totalMs = end - start;
  const awayMs = Object.values(State).filter(isAway).reduce((a, k) => a + ms[k], 0);
  const pct = (x) => (totalMs > 0 ? round1((x / totalMs) * 100) : 0);
  const grant = events.find((e) => e.eventType === EventType.CONSENT_GRANTED);
  const status = bounds.endedBy === 'revoked' ? 'revoked' : bounds.endedBy === 'monitoring_stopped' ? 'monitoring_stopped' : bounds.endedBy === 'in_progress' ? 'in_progress' : 'completed';

  return {
    summary: {
      ...ident, status, endedBy: bounds.endedBy,
      startTs: start, endTs: end, totalMs, monitoredMs: totalMs - ms.UNMONITORED, trailingGapMs: bounds.trailingGapMs,
      ms, awayMs,
      percent: {
        present: pct(ms.PRESENT), noteTaking: pct(ms.NOTE_TAKING), engaged: pct(ms.PRESENT + ms.NOTE_TAKING),
        confirmedIdle: pct(ms.IDLE_CONFIRMED), away: pct(awayMs), unmonitored: pct(ms.UNMONITORED),
      },
      prompts: promptStats(events),
      longestAwayMs: longestRun(segments, isAway),
      longestIdleMs: longestRun(segments, (s) => s === State.IDLE_CONFIRMED),
      consent: grant ? { version: grant.meta?.version ?? null, grantedTs: grant.meta?.grantedTs ?? null } : null,
    },
    segments,
    bounds: { start, end, endedBy: bounds.endedBy },
  };
}
