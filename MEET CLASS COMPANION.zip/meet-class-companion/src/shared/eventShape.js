// The exact fields that go into an event's hash. Anything else stored next to them (uid, expireAt...) is transport
// metadata and must be stripped before the hash chain is verified.
export const EVENT_FIELDS = ['eventId', 'seq', 'sessionId', 'studentId', 'meetCode', 'eventType', 'ts', 'durationMs', 'meta', 'prevHash', 'hash'];

export function pickEvent(doc) {
  const e = {};
  for (const k of EVENT_FIELDS) e[k] = doc[k] === undefined ? null : doc[k];
  e.meta = e.meta ?? {};
  return e;
}
