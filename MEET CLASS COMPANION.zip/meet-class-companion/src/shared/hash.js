// Tamper-evident event chain. Each event stores prevHash and hash = SHA-256(canonical(event without hash)).
// This detects edits to an exported log; it does NOT stop a student who controls their own browser.
import { GENESIS_HASH } from './schema.js';

export function canonical(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  return '{' + Object.keys(v).filter((k) => v[k] !== undefined).sort()
    .map((k) => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
}

export async function sha256Hex(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hashEvent(evt) {
  const { hash, ...rest } = evt;
  return sha256Hex(canonical(rest));
}

export async function verifyChain(events) {
  const sorted = [...events].sort((a, b) => a.seq - b.seq);
  let prev = GENESIS_HASH;
  for (let i = 0; i < sorted.length; i++) {
    const e = sorted[i];
    if (e.seq !== i + 1) return { ok: false, brokenAt: e.seq, reason: 'sequence gap' };
    if (e.prevHash !== prev) return { ok: false, brokenAt: e.seq, reason: 'prevHash mismatch' };
    if ((await hashEvent(e)) !== e.hash) return { ok: false, brokenAt: e.seq, reason: 'hash mismatch' };
    prev = e.hash;
  }
  return { ok: true };
}
