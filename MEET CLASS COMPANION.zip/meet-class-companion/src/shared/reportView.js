// Report rendering shared by the professor's offline viewer and the web dashboard.
// A "result" is { session, events, chain, summary, segments, bounds, name? }.
import { h } from './dom.js';
import { timelineBar, summaryTable, promptLine } from './timelineView.js';
import { describeEvent, localDate, localTime, fmtDuration } from './schema.js';

const fmtPct = (n) => (n == null ? '' : `${n}%`);

export function integrityBadge(chain) {
  return h('span', { class: chain.ok ? 'good' : 'bad' }, chain.ok ? 'Intact' : `BROKEN at event ${chain.brokenAt}`);
}

export function studentsTable(results, selected, onSelect) {
  const rows = results.map((r, i) => {
    const s = r.summary;
    const pick = () => onSelect(i);
    const who = h('td', {}, s.displayName || '(no name)', h('small', {}, s.studentId));
    const cls = h('td', {}, s.meetCode, h('small', {}, s.date));
    const attrs = { class: 'clickable' + (i === selected ? ' sel' : ''), tabindex: '0', onclick: pick, onkeydown: (e) => { if (e.key === 'Enter') pick(); } };
    if (s.status === 'declined') return h('tr', attrs, who, cls, h('td', { colspan: '6' }, h('em', {}, 'Declined tracking')), h('td', {}, integrityBadge(r.chain)));
    return h('tr', attrs, who, cls,
      h('td', { class: 'num' }, fmtPct(s.percent.engaged)), h('td', { class: 'num' }, fmtPct(s.percent.noteTaking)),
      h('td', { class: 'num' }, fmtPct(s.percent.confirmedIdle)), h('td', { class: 'num' }, fmtPct(s.percent.away)),
      h('td', { class: 'num' }, fmtPct(s.percent.unmonitored)),
      h('td', { class: 'num' }, s.prompts.avgResponseSec == null ? 'none' : `${s.prompts.avgResponseSec}s`),
      h('td', {}, integrityBadge(r.chain)));
  });
  return h('table', { class: 'grid' },
    h('thead', {}, h('tr', {}, ['Student', 'Class', 'Engaged', 'of which notes', 'Confirmed idle', 'Away', 'Not monitored', 'Avg prompt answer', 'Log integrity'].map((t) => h('th', {}, t)))),
    h('tbody', {}, rows));
}

export function studentDetail(r, actions = []) {
  const s = r.summary;
  const head = h('h2', {}, `${s.displayName || '(no name)'} (${s.studentId}), ${s.meetCode}, ${s.date}`);
  if (s.status === 'declined') {
    return h('section', { class: 'detail' }, head, h('p', { class: 'box' }, s.text), h('p', { class: r.chain.ok ? 'good' : 'bad' }, `Log integrity: ${r.chain.ok ? 'intact' : 'broken'}`), h('div', { class: 'row' }, actions));
  }
  const fmtT = (ts) => `${localDate(ts)} ${localTime(ts)}`;
  const note = {
    revoked: 'The student turned the log off during class; the record ends there.',
    monitoring_stopped: 'The extension stopped running; the record ends at the last time it was seen.',
    in_progress: 'The class was still in progress when this was generated.',
  }[s.status];
  return h('section', { class: 'detail' }, head,
    h('p', {}, `${fmtT(s.startTs)} to ${fmtT(s.endTs)} (${fmtDuration(s.totalMs)}). ${note ?? ''}`),
    h('p', { class: r.chain.ok ? 'good' : 'bad' }, r.chain.ok ? 'Log integrity: intact.' : `Log integrity: BROKEN at event ${r.chain.brokenAt} (${r.chain.reason}). Do not rely on this log.`),
    timelineBar(r.segments, r.bounds.start, r.bounds.end), summaryTable(s),
    h('p', {}, promptLine(s.prompts)),
    h('p', {}, `Longest time away: ${fmtDuration(s.longestAwayMs) || 'none'}. Longest confirmed idle: ${fmtDuration(s.longestIdleMs) || 'none'}.`),
    h('div', { class: 'row' }, actions),
    h('h3', {}, 'Every event'),
    h('table', { class: 'grid events' }, h('thead', {}, h('tr', {}, h('th', {}, 'Time'), h('th', {}, 'Event'), h('th', {}, 'Detail'))),
      h('tbody', {}, [...r.events].sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0) || a.seq - b.seq).map((e) => h('tr', {}, h('td', {}, e.ts ? localTime(e.ts) : s.date), h('td', {}, e.eventType), h('td', {}, describeEvent(e)))))));
}

export function reportFooter() {
  return h('footer', {},
    h('h2', {}, 'How to read this'),
    h('p', {}, '"Intact" means no event was edited, removed or reordered after the extension wrote it. It does not prove a student did not switch the extension off, use a second device, or join from a phone: those leave no trace. Treat the numbers as evidence to discuss with a student, not a verdict.'),
    h('p', {}, '"Engaged" is time on the class tab (including time taking notes). "Confirmed idle" is time after an unanswered "Are you still there?" prompt. Picture-in-picture, a second monitor and a locked screen have their own rows and are never silently counted for or against the student.'));
}
