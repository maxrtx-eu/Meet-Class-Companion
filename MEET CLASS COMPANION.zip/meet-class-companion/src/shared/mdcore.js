// Pure Markdown helpers (no DOM) so they are unit-testable and shared by the preview, the export and the print page.
// Supported: # ## ### headings, - / * bullets, 1. lists, **bold**, *italic*, `code`, and ![alt](shot:ID) screenshots.
const INLINE = /!\[([^\]]*)\]\(([^)\s]+)\)|\*\*(.+?)\*\*|(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])|`([^`]+)`/g;

export function tokenizeInline(text) {
  const out = [];
  let last = 0;
  for (const m of text.matchAll(INLINE)) {
    if (m.index > last) out.push({ t: 'text', v: text.slice(last, m.index) });
    if (m[2] !== undefined) out.push({ t: 'img', alt: m[1], src: m[2] });
    else if (m[3] !== undefined) out.push({ t: 'b', v: m[3] });
    else if (m[4] !== undefined) out.push({ t: 'i', v: m[4] });
    else out.push({ t: 'code', v: m[5] });
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push({ t: 'text', v: text.slice(last) });
  return out;
}

export function parseBlocks(text) {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const blocks = [];
  let para = [];
  const flush = () => { if (para.length) { blocks.push({ type: 'p', lines: para }); para = []; } };
  const H = /^(#{1,3})\s+(.*)$/;
  const UL = /^\s*[-*]\s+(.*)$/;
  const OL = /^\s*\d+\.\s+(.*)$/;
  for (let i = 0; i < lines.length;) {
    const line = lines[i];
    const heading = H.exec(line);
    if (heading) { flush(); blocks.push({ type: 'h', level: heading[1].length, text: heading[2] }); i++; }
    else if (UL.test(line)) {
      flush();
      const items = [];
      while (i < lines.length && UL.test(lines[i])) items.push(UL.exec(lines[i++])[1]);
      blocks.push({ type: 'ul', items });
    } else if (OL.test(line)) {
      flush();
      const items = [];
      while (i < lines.length && OL.test(lines[i])) items.push(OL.exec(lines[i++])[1]);
      blocks.push({ type: 'ol', items });
    } else if (line.trim() === '') { flush(); i++; }
    else { para.push(line); i++; }
  }
  flush();
  return blocks;
}

const SHOT_REF = /(!\[[^\]]*\]\()shot:([A-Za-z0-9_-]+)(\))/g;

export function shotIds(text) {
  return [...text.matchAll(SHOT_REF)].map((m) => m[2]);
}

/** Replace shot:ID references with data URIs so the .md file is self-contained. Missing images become a note. */
export function embedImages(text, dataUrls) {
  return text.replace(SHOT_REF, (all, open, id, close) => (dataUrls.has(id) ? `${open}${dataUrls.get(id)}${close}` : '*(screenshot no longer available)*'));
}
