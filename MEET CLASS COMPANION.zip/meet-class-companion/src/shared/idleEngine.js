// Pure idle-confirmation state machine ("Are you still there?").
// No DOM, no chrome.*, no timers: the caller feeds inputs + the current time and applies the returned effects.
// That is what makes fast / slow / never-respond testable with a fake clock.
//
//   SUSPENDED --env ok--> ARMED --no input for threshold--> PROMPTED --click--> COOLDOWN --elapsed--> ARMED
//                                                              |
//                                                    window expires (IDLE_CONFIRMED)
//                                                              v
//                                                            IDLE --late click--> COOLDOWN
//   any phase --env not ok (tab hidden, Chrome unfocused, notes active, left call)--> SUSPENDED
//
// Only the button counts as a response. Mouse movement alone does not, so response time stays meaningful.
import { EventType } from './schema.js';

export const Phase = Object.freeze({ SUSPENDED: 'SUSPENDED', ARMED: 'ARMED', PROMPTED: 'PROMPTED', IDLE: 'IDLE', COOLDOWN: 'COOLDOWN' });
export const SLOW_RESPONSE_MS = 20_000;   // >= this is a "slow" response; < fastResponseSec is "fast"
const SLEEP_GAP_MS = 10_000;              // a tick gap this large means the machine slept: do not count it as idle

export function createIdleState(now) {
  return {
    phase: Phase.SUSPENDED, eligible: false,
    lastInputTs: now, lastTickTs: now,
    promptId: null, promptShownTs: null, idleStartTs: null,
    cooldownUntil: 0, fastStreak: 0, promptCount: 0,
  };
}

/** Current suspicion threshold. In adaptive mode it grows with consecutive fast responses. */
export function currentThresholdMs(s, cfg) {
  const base = cfg.idleSuspicionSec * 1000;
  if (!cfg.adaptive) return base;
  return Math.min(base * Math.pow(cfg.adaptiveFactor, s.fastStreak), base * cfg.adaptiveMaxMultiple);
}

const round1 = (x) => Math.round(x * 10) / 10;
const logFx = (ts, eventType, meta = {}, durationMs = null) => ({ type: 'LOG', eventType, ts, durationMs, meta });

function clearPrompt(s) { s.promptId = null; s.promptShownTs = null; s.idleStartTs = null; }

function suspend(s, now, fx, cause) {
  if (s.phase === Phase.IDLE) {
    // The idle episode ends because the student left: close it so the duration is recorded.
    fx.push(logFx(now, EventType.RETURNED, { from: 'IDLE_CONFIRMED', promptId: s.promptId, cause }, now - s.idleStartTs));
    fx.push({ type: 'HIDE_PROMPT' });
    s.fastStreak = 0;
  } else if (s.phase === Phase.PROMPTED) {
    // Prompt cancelled (e.g. tab hidden). Away time is attributed by the focus events instead: no double counting.
    fx.push({ type: 'HIDE_PROMPT' });
  }
  s.phase = Phase.SUSPENDED;
  clearPrompt(s);
}

function tick(s, now, cfg, fx) {
  const gap = now - s.lastTickTs;
  s.lastTickTs = now;
  if (gap > SLEEP_GAP_MS && (s.phase === Phase.ARMED || s.phase === Phase.COOLDOWN)) s.lastInputTs = now;

  if (s.phase === Phase.COOLDOWN && now >= s.cooldownUntil) s.phase = Phase.ARMED;

  const windowMs = cfg.responseWindowSec * 1000;
  if (s.phase === Phase.ARMED && now - s.lastInputTs >= currentThresholdMs(s, cfg)) {
    s.phase = Phase.PROMPTED;
    s.promptCount += 1;
    s.promptId = `p${s.promptCount}-${now.toString(36)}`;
    s.promptShownTs = now;
    fx.push({ type: 'SHOW_PROMPT', promptId: s.promptId, shownTs: now, windowMs });
    fx.push(logFx(now, EventType.IDLE_PROMPT_SHOWN, {
      promptId: s.promptId,
      thresholdSec: round1(currentThresholdMs(s, cfg) / 1000),
      inactivitySec: round1((now - s.lastInputTs) / 1000),
    }));
  } else if (s.phase === Phase.PROMPTED && now - s.promptShownTs >= windowMs) {
    // Confirmed-idle clock starts at the END of the response window, not at the last input:
    // time spent quietly watching before the prompt is never counted as idle.
    s.phase = Phase.IDLE;
    s.idleStartTs = s.promptShownTs + windowMs;
    s.fastStreak = 0;
    fx.push(logFx(s.idleStartTs, EventType.IDLE_CONFIRMED, { promptId: s.promptId, responseWindowSec: cfg.responseWindowSec }));
  }
}

function respond(s, now, cfg, fx) {
  if (s.phase !== Phase.PROMPTED && s.phase !== Phase.IDLE) return;
  const late = s.phase === Phase.IDLE;
  const responseMs = now - s.promptShownTs;
  const speed = responseMs < cfg.fastResponseSec * 1000 ? 'fast' : responseMs < SLOW_RESPONSE_MS ? 'medium' : 'slow';
  fx.push(logFx(now, EventType.IDLE_PROMPT_RESPONDED, { promptId: s.promptId, responseSec: round1(responseMs / 1000), late, speed }));
  if (late) {
    fx.push(logFx(now, EventType.RETURNED, { from: 'IDLE_CONFIRMED', promptId: s.promptId, cause: 'late_response' }, now - s.idleStartTs));
  }
  s.fastStreak = !late && speed === 'fast' ? s.fastStreak + 1 : 0;
  fx.push({ type: 'HIDE_PROMPT' });
  s.phase = Phase.COOLDOWN;
  s.cooldownUntil = now + cfg.cooldownSec * 1000;
  s.lastInputTs = now;
  clearPrompt(s);
}

/**
 * @param prev  previous state (not mutated)
 * @param input {type:'TICK'} | {type:'INPUT'} | {type:'ENV', eligible:boolean} | {type:'RESPOND'} | {type:'RESET', cause?}
 * @returns {{state, effects}} effects: SHOW_PROMPT | HIDE_PROMPT | LOG
 */
export function stepIdle(prev, input, now, cfg) {
  const s = { ...prev };
  const fx = [];
  switch (input.type) {
    case 'ENV': {
      const eligible = !!input.eligible;
      if (eligible === s.eligible) break;
      s.eligible = eligible;
      if (!eligible) suspend(s, now, fx, 'suspended');
      else {
        s.lastInputTs = now;       // coming back counts as a fresh start
        s.lastTickTs = now;
        s.phase = now < s.cooldownUntil ? Phase.COOLDOWN : Phase.ARMED;
      }
      break;
    }
    case 'INPUT': s.lastInputTs = now; break;
    case 'TICK': tick(s, now, cfg, fx); break;
    case 'RESPOND': respond(s, now, cfg, fx); break;
    case 'RESET': suspend(s, now, fx, input.cause ?? 'call_left'); s.eligible = false; break;
    default: break;
  }
  return { state: s, effects: fx };
}
