// Event vocabulary, constants and small helpers shared by every extension context.
// Rule of thumb for this file: a field exists only if the browser can actually observe it.

export const EventType = Object.freeze({
  FOCUS_LOST: 'FOCUS_LOST',                 // another tab became active in the Meet tab's window
  WINDOW_UNFOCUSED: 'WINDOW_UNFOCUSED',     // Chrome lost focus, focus moved to another Chrome window, or screen locked
  IDLE_PROMPT_SHOWN: 'IDLE_PROMPT_SHOWN',
  IDLE_PROMPT_RESPONDED: 'IDLE_PROMPT_RESPONDED',
  IDLE_CONFIRMED: 'IDLE_CONFIRMED',
  RETURNED: 'RETURNED',                     // closes an away / idle episode; carries durationMs
  NOTE_ACTIVITY: 'NOTE_ACTIVITY',           // one burst of note-taking (start + duration, never content)
  SCREENSHOT_CAPTURED: 'SCREENSHOT_CAPTURED',
  JOINED_CLASS: 'JOINED_CLASS',             // addition to the original list: opens a session
  LEFT_CLASS: 'LEFT_CLASS',
  CONSENT_GRANTED: 'CONSENT_GRANTED',
  CONSENT_DECLINED: 'CONSENT_DECLINED',     // also the marker written on revocation
  MONITORING_STOPPED: 'MONITORING_STOPPED',
});

// Event types the content script is allowed to ask the service worker to log.
export const ENGINE_EVENT_TYPES = new Set([
  EventType.IDLE_PROMPT_SHOWN,
  EventType.IDLE_PROMPT_RESPONDED,
  EventType.IDLE_CONFIRMED,
  EventType.RETURNED,
]);

// Only these meta keys are accepted from the content script.
export const ENGINE_META_KEYS = ['promptId', 'thresholdSec', 'inactivitySec', 'responseWindowSec', 'responseSec', 'late', 'speed', 'from', 'cause'];

export const DECLINED_TEXT = 'No tracking record. Student declined tracking.';
export const GENESIS_HASH = '0'.repeat(64);
export const NOTE_HEARTBEAT_MS = 5_000;     // each note heartbeat stands for this much typing time
export const HEARTBEAT_MS = 30_000;         // service-worker watchdog period
export const ORPHAN_CLOSE_MS = 180_000;     // heartbeat older than this => the session is considered over
export const MEET_MATCH = 'https://meet.google.com/*';

const RESERVED_PATHS = new Set(['landing', 'new', 'lookup', '_meet', 'whoops', 'about', 'calling', 'tel', 'sip', 'cal', 'getalink']);

/** Returns the meeting code for a Meet URL, or null if the URL is not a meeting page. */
export function parseMeetCode(href) {
  let u;
  try { u = new URL(href); } catch { return null; }
  if (u.hostname !== 'meet.google.com') return null;
  const seg = u.pathname.split('/').filter(Boolean);
  if (seg.length !== 1) return null;
  const s = seg[0].toLowerCase();
  if (/^[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(s)) return s;                        // abc-defg-hij
  if (/^[a-z0-9][a-z0-9_-]{2,}$/.test(s) && !RESERVED_PATHS.has(s)) return s;  // Workspace meeting nickname
  return null;
}

export const newId = () => crypto.randomUUID();

const pad = (n) => String(n).padStart(2, '0');
export function localDate(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function localTime(ts) {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

export function fmtDuration(ms) {
  if (ms == null) return '';
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  return m < 60 ? `${m}m ${s % 60}s` : `${Math.floor(m / 60)}h ${m % 60}m`;
}

/** Plain-language one-liner for an event; used by the student's "My log" and the CSV. */
export function describeEvent(e) {
  const m = e.meta ?? {};
  switch (e.eventType) {
    case EventType.FOCUS_LOST:
      return 'Switched to another browser tab' + (m.pip ? ' (Meet in picture-in-picture)' : '');
    case EventType.WINDOW_UNFOCUSED:
      if (m.cause === 'screen_locked') return 'Screen locked';
      if (m.focusTarget === 'other_chrome_window') return 'Moved to another Chrome window' + (m.meetVisible ? ' (Meet tab still visible)' : '');
      return 'Chrome lost focus (another app or window)';
    case EventType.IDLE_PROMPT_SHOWN: return 'Asked "Are you still there?"';
    case EventType.IDLE_PROMPT_RESPONDED:
      return `Answered "Are you still there?" in ${m.responseSec}s` + (m.late ? ' (late, after being marked idle)' : '');
    case EventType.IDLE_CONFIRMED: return 'No answer to "Are you still there?": marked idle';
    case EventType.RETURNED: {
      const what = { FOCUS_LOST: 'back on the Meet tab', WINDOW_UNFOCUSED: 'back in the Meet window', IDLE_CONFIRMED: 'idle period ended' }[m.from] ?? 'back';
      return `Returned (${what})` + (e.durationMs != null ? `, away ${fmtDuration(e.durationMs)}` : '');
    }
    case EventType.NOTE_ACTIVITY: return `Taking notes for ${fmtDuration(e.durationMs)}`;
    case EventType.SCREENSHOT_CAPTURED: return 'Captured a slide screenshot';
    case EventType.JOINED_CLASS: return 'Joined the class';
    case EventType.LEFT_CLASS: return 'Left the class' + (m.inferred ? ' (inferred after the browser or tab closed)' : '');
    case EventType.CONSENT_GRANTED: return 'Attention log turned on';
    case EventType.CONSENT_DECLINED: return m.text ?? 'No tracking record. Student declined tracking.';
    case EventType.MONITORING_STOPPED: return 'Monitoring stopped' + (m.inferred ? ' (gap detected afterwards; cause unknown)' : '');
    default: return e.eventType;
  }
}
