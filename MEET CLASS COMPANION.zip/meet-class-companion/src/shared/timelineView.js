// Shared by the student's side panel and the professor's offline viewer.
import { h } from './dom.js';
import { State } from './timeline.js';
import { fmtDuration } from './schema.js';

export const STATE_META = {
  PRESENT: { label: 'Present (on the class tab)', color: '#0b6e63' },
  NOTE_TAKING: { label: 'Taking notes', color: '#2563eb' },
  IDLE_CONFIRMED: { label: 'Confirmed idle (did not answer the prompt)', color: '#d97706' },
  AWAY_TAB: { label: 'Away: another browser tab', color: '#b3261e' },
  AWAY_WINDOW: { label: 'Away: Chrome lost focus (other app or window)', color: '#7f1d1d' },
  AWAY_PIP: { label: 'Away from the tab, Meet in picture-in-picture', color: '#c2410c' },
  AWAY_OTHER_WINDOW_VISIBLE: { label: 'Another Chrome window, Meet tab still visible', color: '#e08a6d' },
  AWAY_SCREEN_LOCKED: { label: 'Screen locked', color: '#6b21a8' },
  UNMONITORED: { label: 'Not monitored (extension was not running)', color: '#9aa5a0' },
};

export function timelineBar(segments, start, end) {
  const total = Math.max(1, end - start);
  const bar = h('div', { class: 'tl-bar', role: 'img', 'aria-label': 'Timeline of the class from start to end. The table below gives the same information in numbers.' });
  for (const s of segments) {
    const seg = h('span', { class: 'tl-seg', title: `${STATE_META[s.state].label}: ${fmtDuration(s.end - s.start)}` });
    seg.style.width = `${((s.end - s.start) / total) * 100}%`;
    seg.style.backgroundColor = STATE_META[s.state].color;
    bar.append(seg);
  }
  return bar;
}

export function summaryTable(summary) {
  if (summary.status === 'declined') return h('p', { class: 'tl-declined' }, summary.text);
  const total = Math.max(1, summary.totalMs);
  const rows = Object.values(State).filter((k) => k === State.PRESENT || summary.ms[k] > 0).map((k) => {
    const sw = h('span', { class: 'tl-swatch' });
    sw.style.backgroundColor = STATE_META[k].color;
    return h('tr', {}, h('td', {}, sw, STATE_META[k].label), h('td', { class: 'num' }, fmtDuration(summary.ms[k])), h('td', { class: 'num' }, `${Math.round((summary.ms[k] / total) * 1000) / 10}%`));
  });
  return h('table', { class: 'tl-table' }, h('thead', {}, h('tr', {}, h('th', {}, 'State'), h('th', { class: 'num' }, 'Time'), h('th', { class: 'num' }, 'Share'))), h('tbody', {}, rows));
}

export function promptLine(p) {
  if (!p || !p.shown) return 'No "Are you still there?" prompts were shown.';
  const parts = [`${p.shown} shown`, `${p.answered} answered in time`];
  if (p.avgResponseSec != null) parts.push(`average ${p.avgResponseSec}s (fast ${p.fast}, medium ${p.medium}, slow ${p.slow})`);
  if (p.answeredLate) parts.push(`${p.answeredLate} answered late`);
  if (p.neverAnswered) parts.push(`${p.neverAnswered} never answered`);
  if (p.cancelled) parts.push(`${p.cancelled} cancelled because the student left the tab`);
  return `Prompts: ${parts.join(', ')}.`;
}
