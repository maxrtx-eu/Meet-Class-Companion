// The consent form, as data. Rendered by the in-tab dialog, the side panel and (verbatim) the README.
// Numbers are filled in from the live config so the text can never disagree with the behaviour.
// Bump CONSENT_VERSION whenever the meaning of the text changes: everyone is asked again.
export const CONSENT_VERSION = 2;

export function formatDuration(sec) {
  if (sec < 60) return `${sec} second${sec === 1 ? '' : 's'}`;
  const m = Math.floor(sec / 60);
  const r = sec % 60;
  const mm = `${m} minute${m === 1 ? '' : 's'}`;
  return r ? `${mm} ${r} seconds` : mm;
}

export function buildConsentText(config, classInfo = null) {
  const threshold = formatDuration(config.idleSuspicionSec);
  const windowText = formatDuration(config.responseWindowSec);
  const cooldown = formatDuration(config.cooldownSec);
  const popup = [
    `If you have not touched the keyboard or mouse in the class tab for about ${threshold}, a large box asks "Are you still there?". Click "Yes, I'm here" and you are recorded as present, along with how quickly you clicked.`,
    `If you do not click within about ${windowText}, you are recorded as idle until you click or leave.`,
    `After any answer it will not appear again for at least ${cooldown}. It never appears while you are in another tab or window, or while you are typing in your notes.`,
  ];
  if (config.adaptive) popup.push('If you keep answering quickly, it will appear less often.');

  // Where the log goes. The wording must match what the code does: with a class code the log is uploaded.
  const who = classInfo
    ? [
      `${classInfo.professorName || 'Your professor'}, for the class "${classInfo.className}". The log is uploaded to a secure Google Firebase database while you are in class, and your professor gets a report automatically after the meeting. Nobody else can read it.`,
      `It is deleted automatically after ${classInfo.retentionDays} days.`,
      'You can watch the exact log build up, live, in the side panel. If your professor wants more detail, you export a file yourself.',
    ]
    : ['Your professor, in a report you export and hand in yourself. Nothing is uploaded. You can watch the exact log build up, live, in the side panel.'];
  const no = classInfo
    ? [
      'Nothing is tracked. The only record, sent to your professor, is one line per class: "No tracking record. Student declined tracking." It shows the date and your name, nothing else.',
      'Notes and screenshots still work.',
      'You can change your mind any time in the side panel or the corner badge. Stopping mid-class stops logging immediately and adds the same line.',
    ]
    : [
      'Nothing is tracked. The only record is one line per class: "No tracking record. Student declined tracking."',
      'Notes and screenshots still work.',
      'You can change your mind any time in the side panel. Stopping mid-class stops logging immediately and adds the same line.',
    ];

  return {
    title: 'Your choice: share an attention log for this class?',
    intro: 'Class Companion gives you a private notes workspace inside Google Meet (notes and screenshots of the slides). Separately, and only if you say yes, it keeps an attention log for your professor.',
    sections: [
      { heading: 'What is logged if you say yes', items: [
        'When you switch to another browser tab or window, when Chrome loses focus or your screen locks, and when you come back.',
        'When you leave the class, or the tab or browser closes.',
        'Whether you answered the "Are you still there?" popup, and how fast.',
        'When you are taking notes: the time and how long, never what you wrote.',
        classInfo ? 'The name and student number you enter below, and the class you linked. They are uploaded with the log.' : 'The name and student number you enter below.',
      ] },
      { heading: 'What is never logged or shared', items: [
        'What you type (no keystrokes), your notes and your screenshots.',
        'Which other sites or apps you use. The extension cannot see them.',
        'Your camera, microphone or screen.',
      ] },
      { heading: 'Who sees it', items: who },
      { heading: 'The "Are you still there?" popup', items: popup },
      { heading: 'What you get', items: [
        'Private notes and slide screenshots that only you can see, whichever way you choose.',
        'Your own session report.',
        'If you say yes, time spent taking notes shows up as "taking notes" instead of an unexplained gap.',
      ] },
      { heading: 'If you say no', items: no },
    ],
    footer: 'A small "Attention log on" badge stays visible the whole time logging is active.',
  };
}
