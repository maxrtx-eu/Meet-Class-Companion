// User-configurable settings. v1: the student edits these on the options page.
// (Institution-controlled policy, e.g. chrome.storage.managed or a server, is a v2 concern.)

export const DEFAULT_CONFIG = Object.freeze({
  idleSuspicionSec: 60,   // no input this long (tab focused + visible) => show "Are you still there?"
  responseWindowSec: 60,  // no click this long after the prompt => IDLE_CONFIRMED
  cooldownSec: 300,       // minimum gap after a prompt episode ends before the next prompt
  adaptive: false,        // lengthen the threshold after consecutive fast responses
  fastResponseSec: 5,     // "fast" response for adaptive mode and the summary
  adaptiveFactor: 1.5,
  adaptiveMaxMultiple: 4,
  awayGraceSec: 10,       // ignore tab/window blur shorter than this
  noteQuietSec: 30,       // a note-taking burst ends after this much typing silence
  sound: true,            // soft chime with the prompt
});

export const LIMITS = {
  idleSuspicionSec: [15, 600],
  responseWindowSec: [10, 300],
  cooldownSec: [30, 1800],
  fastResponseSec: [1, 15],
  awayGraceSec: [0, 60],
  noteQuietSec: [10, 120],
};

/** Pure: clamp/validate arbitrary input into a full config object. */
export function sanitizeConfig(raw = {}) {
  const out = { ...DEFAULT_CONFIG };
  for (const [key, [lo, hi]] of Object.entries(LIMITS)) {
    const n = Number(raw[key]);
    if (raw[key] !== undefined && Number.isFinite(n)) out[key] = Math.min(hi, Math.max(lo, Math.round(n)));
  }
  if (raw.adaptive !== undefined) out.adaptive = !!raw.adaptive;
  if (raw.sound !== undefined) out.sound = !!raw.sound;
  return out;
}

export async function loadConfig() {
  const { config } = await chrome.storage.local.get('config');
  return sanitizeConfig(config);
}

export async function saveConfig(patch) {
  const next = sanitizeConfig({ ...(await loadConfig()), ...patch });
  await chrome.storage.local.set({ config: next });
  return next;
}
