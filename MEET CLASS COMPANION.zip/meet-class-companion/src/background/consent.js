// Persistent consent state (chrome.storage.local for v1; a server-verified copy comes with Firestore).
//   UNSET --accept--> GRANTED --revoke--> DECLINED;  UNSET --decline--> DECLINED;  DECLINED --accept--> GRANTED
//   Any stored status with an older CONSENT_VERSION is treated as UNSET (the text changed: ask again).
import { CONSENT_VERSION } from '../shared/consentText.js';

const KEY = 'consent';
const PROFILE_KEY = 'profile';       // name + student number, editable at any time, independent of the consent decision
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max);

export async function currentClassId() { return (await chrome.storage.local.get('classLink')).classLink?.classId ?? null; }
async function raw() { return (await chrome.storage.local.get(KEY))[KEY] ?? null; }
async function rawProfile() { return (await chrome.storage.local.get(PROFILE_KEY))[PROFILE_KEY] ?? {}; }

export async function getConsent() {
  const c = await raw();
  const p = await rawProfile();
  if (!c) return { status: 'UNSET', displayName: p.displayName ?? '', studentNumber: p.studentNumber ?? '' };
  // A choice is only valid for the text it was given under AND the class it named: linking another class asks again.
  if (c.version !== CONSENT_VERSION || (c.classId ?? null) !== (await currentClassId())) {
    return { status: 'UNSET', previousStatus: c.status, displayName: c.displayName ?? p.displayName ?? '', studentNumber: c.studentNumber ?? p.studentNumber ?? '' };
  }
  return c;
}

/**
 * Edit name / student number at any time (any consent state). It applies from the NEXT class:
 * events already written carry the old id inside their hash chain and are never rewritten.
 */
export async function updateIdentity({ displayName, studentNumber } = {}) {
  const name = clean(displayName, 80);
  const num = clean(studentNumber, 40);
  if (name.length < 2 || !num) throw new Error('Enter your name and student number.');
  await chrome.storage.local.set({ [PROFILE_KEY]: { displayName: name, studentNumber: num } });
  const c = await raw();
  if (c) await chrome.storage.local.set({ [KEY]: { ...c, displayName: name, studentNumber: num } });
  return { displayName: name, studentNumber: num };
}

export async function grant({ displayName, studentNumber } = {}) {
  const name = clean(displayName, 80);
  const num = clean(studentNumber, 40);
  if (name.length < 2 || !num) throw new Error('Enter your name and student number to turn the attention log on.');
  const rec = { status: 'GRANTED', version: CONSENT_VERSION, ts: Date.now(), classId: await currentClassId(), displayName: name, studentNumber: num };
  await chrome.storage.local.set({ [KEY]: rec, [PROFILE_KEY]: { displayName: name, studentNumber: num } });
  return rec;
}

async function setDeclined(ident = {}, reason) {
  const prev = (await raw()) ?? {};
  const rec = {
    status: 'DECLINED', version: CONSENT_VERSION, ts: Date.now(), classId: await currentClassId(), reason,
    displayName: clean(ident.displayName, 80) || prev.displayName || '',
    studentNumber: clean(ident.studentNumber, 40) || prev.studentNumber || '',
  };
  await chrome.storage.local.set({ [KEY]: rec });
  return rec;
}
export const decline = (ident) => setDeclined(ident, 'declined');
export const revoke = () => setDeclined({}, 'revoked');

export function identityOf(consent) {
  return { studentId: consent.studentNumber || 'unknown', displayName: consent.displayName || '' };
}
