// Tab focus, window focus and screen-lock tracking.
//
// Sources (deliberately NOT the page's window.blur, which also fires when the student clicks into the side panel):
//   tab    : chrome.tabs.onActivated / tabs.get(tabId).active
//   window : chrome.windows.onFocusChanged / windows.getLastFocused().focused  (WINDOW_ID_NONE => left Chrome)
//   lock   : chrome.idle.onStateChanged === 'locked'
//
// At any moment the student is in at most one "away" state (tab beats window beats lock), so time is never double counted.
// An away episode is logged only after the grace period; the first logged event is back-dated to when it began.
// While an episode is open the kind can change (FOCUS_LOST -> WINDOW_UNFOCUSED ...): each change is its own event
// and one RETURNED closes the whole episode.
import { getRT, saveRT, serial } from './state.js';
import { logEvent } from './logger.js';
import { pushEnv } from './push.js';
import { EventType } from '../shared/schema.js';
import { loadConfig } from '../shared/config.js';

function desiredAway(rt) {
  const f = rt.focus;
  if (!f.tabActive) return { kind: EventType.FOCUS_LOST, meta: {} };
  if (f.locked) return { kind: EventType.WINDOW_UNFOCUSED, meta: { cause: 'screen_locked' } };
  if (!f.windowFocused) {
    return { kind: EventType.WINDOW_UNFOCUSED, meta: { focusTarget: f.otherWindow ? 'other_chrome_window' : 'outside_chrome' } };
  }
  return null;
}

// Ambiguity is recorded, not resolved: the professor's summary puts these in separate buckets.
const withContext = (rt, cur) => ({ ...cur.segMeta, pip: rt.env.pip, meetVisible: rt.env.visible });

async function applyAway(now = Date.now()) {
  const rt = await getRT();
  const s = rt.session;
  if (!s) return;
  const want = desiredAway(rt);
  const cur = rt.away;

  if (!want && !cur) return;

  if (want && !cur) {
    rt.away = { episodeStartTs: now, kind: want.kind, segStartTs: now, segMeta: want.meta, episodeLogged: false };
    scheduleCommit();
    return;
  }

  if (!want && cur) {
    rt.away = null;
    if (cur.episodeLogged) {
      await logEvent(s.sessionId, EventType.RETURNED, {
        ts: now, durationMs: now - cur.episodeStartTs, meta: { from: cur.kind, episodeStartTs: cur.episodeStartTs },
      });
    }
    return;
  }

  const changed = want.kind !== cur.kind
    || want.meta.focusTarget !== cur.segMeta.focusTarget
    || want.meta.cause !== cur.segMeta.cause;
  if (!changed) return;
  cur.kind = want.kind;
  cur.segMeta = want.meta;
  cur.segStartTs = now;
  if (cur.episodeLogged) await logEvent(s.sessionId, cur.kind, { ts: now, meta: withContext(rt, cur) });
}

export async function maybeCommitAway(now = Date.now()) {
  const rt = await getRT();
  const cur = rt.away;
  if (!rt.session || !cur || cur.episodeLogged) return;
  const graceMs = (await loadConfig()).awayGraceSec * 1000;
  if (now - cur.episodeStartTs < graceMs) return;      // short blur: forgiven, nothing logged
  cur.episodeLogged = true;
  await logEvent(rt.session.sessionId, cur.kind, {
    ts: cur.episodeStartTs, meta: { ...withContext(rt, cur), graceSec: graceMs / 1000 },
  });
}

function scheduleCommit() {
  // Short timers are safe here (the worker was just woken by an event); the 30s alarm watchdog is the backstop.
  loadConfig().then((c) => {
    const t = setTimeout(() => serial(async () => { await maybeCommitAway(); await saveRT(); }), c.awayGraceSec * 1000 + 100);
    t?.unref?.();
  });
}

/** Re-read the browser's focus facts and reconcile the away episode. Call on every focus-related event. */
export async function refreshFocus() {
  const rt = await getRT();
  const s = rt.session;
  if (!s) return;
  let tab;
  try { tab = await chrome.tabs.get(s.tabId); } catch { return; }   // tab gone: onRemoved / watchdog handle it
  s.windowId = tab.windowId;
  let win = null;
  try { win = await chrome.windows.getLastFocused(); } catch { /* no window */ }
  rt.focus.tabActive = !!tab.active;
  const onCompanion = !!win?.focused && win.id === rt.panelWindowId;     // notes window (fallback mode) is part of the class
  rt.focus.windowFocused = !!win?.focused && (win.id === s.windowId || onCompanion);
  rt.focus.otherWindow = !!win?.focused && win.id !== s.windowId && !onCompanion;
  await applyAway();
  await pushEnv();
  await saveRT();
}

export async function setLocked(locked) {
  const rt = await getRT();
  if (!rt.session || rt.focus.locked === locked) return;
  rt.focus.locked = locked;
  await applyAway();
  await pushEnv();
  await saveRT();
}
