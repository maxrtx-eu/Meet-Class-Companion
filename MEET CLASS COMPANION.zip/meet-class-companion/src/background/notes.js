// Note-taking engagement. The side panel sends a throttled "typing happened" heartbeat (no content, no keys).
// While a burst is open the student counts as engaged (idle prompt suspended). When typing stops for
// noteQuietSec, one NOTE_ACTIVITY event is written: start time + duration, never what was written.
import { getRT, saveRT, serial } from './state.js';
import { logEvent } from './logger.js';
import { pushEnv } from './push.js';
import { EventType, NOTE_HEARTBEAT_MS } from '../shared/schema.js';
import { loadConfig } from '../shared/config.js';

export async function noteHeartbeat(now = Date.now()) {
  const rt = await getRT();
  if (!rt.session) return false;
  if (!rt.note) {
    rt.note = { startTs: now, lastTs: now };
    await pushEnv();
    scheduleQuietCheck();
  } else {
    rt.note.lastTs = now;
  }
  await saveRT();
  return true;
}

export async function flushNoteBurst(now = Date.now(), { force = false } = {}) {
  const rt = await getRT();
  const n = rt.note;
  if (!rt.session || !n) return;
  const quietMs = (await loadConfig()).noteQuietSec * 1000;
  if (!force && now - n.lastTs < quietMs) return;
  rt.note = null;
  await logEvent(rt.session.sessionId, EventType.NOTE_ACTIVITY, {
    ts: n.startTs, durationMs: n.lastTs - n.startTs + NOTE_HEARTBEAT_MS, meta: {},
  });
  await pushEnv();
}

function scheduleQuietCheck() {
  loadConfig().then((c) => {
    const t = setTimeout(() => serial(async () => {
      await flushNoteBurst();
      if ((await getRT()).note) scheduleQuietCheck();
      await saveRT();
    }), c.noteQuietSec * 1000 + 250);
    t?.unref?.();
  });
}
