// Everything the service worker tells other contexts: public state, environment, toolbar badge.
import { getRT } from './state.js';
import { getConsent } from './consent.js';
import { loadConfig } from '../shared/config.js';
import { MSG } from '../shared/messages.js';
import { MEET_MATCH } from '../shared/schema.js';
import { syncConfigured } from '../sync/index.js';

export function currentEnv(rt) {
  return {
    tabActive: rt.focus.tabActive,
    windowFocused: rt.focus.windowFocused,
    locked: rt.focus.locked,
    notesActive: !!rt.note,
  };
}

/** What a content script / side panel may know. Never includes notes or event content. */
export async function publicState(tabId) {
  const rt = await getRT();
  const consent = await getConsent();
  const config = await loadConfig();
  const monitoredHere = !!rt.session && rt.session.tabId === tabId;
  const { classLink, syncStatus } = await chrome.storage.local.get(['classLink', 'syncStatus']);
  return {
    consentStatus: consent.status,
    consentTs: consent.ts ?? null,
    displayName: consent.displayName ?? '',
    studentNumber: consent.studentNumber ?? '',
    monitoring: !!rt.session,
    monitoredHere,
    sessionId: rt.session?.sessionId ?? null,
    meetCode: rt.session?.meetCode ?? null,
    page: tabId != null ? (rt.pages[tabId]?.page ?? 'none') : undefined,
    env: monitoredHere ? currentEnv(rt) : null,
    config,
    syncAvailable: syncConfigured(),
    classInfo: classLink ? { className: classLink.className, professorName: classLink.professorName, retentionDays: classLink.retentionDays } : null,
    syncStatus: syncStatus ?? null,
  };
}

export async function updateBadge() {
  const rt = await getRT();
  await chrome.action.setBadgeText({ text: rt.session ? '●' : '' }).catch(() => {});
  await chrome.action.setBadgeBackgroundColor({ color: '#c2410c' }).catch(() => {});
}

/** Push fresh state to every Meet tab (each gets its own view) and tell extension pages to re-pull. */
export async function broadcastState() {
  const tabs = await chrome.tabs.query({ url: MEET_MATCH }).catch(() => []);
  for (const t of tabs) {
    const state = await publicState(t.id);
    chrome.tabs.sendMessage(t.id, { type: MSG.STATE_CHANGED, state }).catch(() => {});
  }
  chrome.runtime.sendMessage({ type: MSG.STATE_CHANGED }).catch(() => {});
  await updateBadge();
}

/** Tell the monitored tab whether the idle prompt may run (tab active, Chrome focused, not locked, not taking notes). */
export async function pushEnv() {
  const rt = await getRT();
  if (!rt.session) return;
  const env = currentEnv(rt);
  const key = `${rt.session.tabId}:${JSON.stringify(env)}`;
  if (key === rt.lastEnvSent) return;
  rt.lastEnvSent = key;
  chrome.tabs.sendMessage(rt.session.tabId, { type: MSG.ENV_UPDATE, env }).catch(() => {});
}
