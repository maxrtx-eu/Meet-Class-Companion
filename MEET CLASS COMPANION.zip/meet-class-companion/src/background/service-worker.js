// Service worker: wiring + message router. All state changes run through serial() so handlers never race.
// Listeners are registered synchronously at top level (an MV3 requirement for waking the worker).
import { MSG } from '../shared/messages.js';
import { MEET_MATCH, ENGINE_EVENT_TYPES, ENGINE_META_KEYS, EventType, parseMeetCode, NOTE_HEARTBEAT_MS, HEARTBEAT_MS } from '../shared/schema.js';
import { getRT, saveRT, serial, wasFreshStart, setHeartbeat } from './state.js';
import { getConsent, grant, decline, updateIdentity } from './consent.js';
import { logEvent, writeDeclineMarker } from './logger.js';
import { logRepo } from '../storage/index.js';
import { publicState, broadcastState, updateBadge } from './push.js';
import { refreshFocus, setLocked, maybeCommitAway } from './focusTracker.js';
import { noteHeartbeat, flushNoteBurst } from './notes.js';
import { flushSoon, linkClass, unlinkClass, markMemberDirty } from '../sync/index.js';
import { beginOrResume, endSession, revokeTracking, reconcileOrphans, onTabRemoved, sane } from './session.js';

const MEET_URL_RE = /^https:\/\/meet\.google\.com\//;
const PANEL_PATH = 'src/sidepanel/index.html';

// ---------- who may send what ----------
const CONTENT_TYPES = new Set([MSG.GET_STATE, MSG.PAGE_STATE, MSG.ENV_REPORT, MSG.ENGINE_LOG, MSG.PING, MSG.CONSENT_ACCEPT, MSG.CONSENT_DECLINE, MSG.CONSENT_REVOKE, MSG.PROFILE_UPDATE, MSG.CLASS_LINK, MSG.CLASS_UNLINK]);
const PANEL_TYPES = new Set([MSG.GET_STATE, MSG.GET_MY_LOG, MSG.LIST_SESSIONS, MSG.PROFILE_UPDATE, MSG.CLASS_LINK, MSG.CLASS_UNLINK, MSG.CONSENT_ACCEPT, MSG.CONSENT_DECLINE, MSG.CONSENT_REVOKE, MSG.NOTE_HEARTBEAT, MSG.SCREENSHOT_SAVED]);

function allowed(msg, sender) {
  if (sender.id !== chrome.runtime.id || typeof msg?.type !== 'string') return false;
  if ((sender.url ?? '').startsWith(chrome.runtime.getURL(''))) return PANEL_TYPES.has(msg.type);
  return !!sender.tab && MEET_URL_RE.test(sender.url ?? '') && CONTENT_TYPES.has(msg.type);
}

function pickMeta(meta = {}) {
  const out = {};
  for (const k of ENGINE_META_KEYS) {
    const v = meta[k];
    if (typeof v === 'number' || typeof v === 'boolean') out[k] = v;
    else if (typeof v === 'string') out[k] = v.slice(0, 64);
  }
  return out;
}

// ---------- message handlers ----------
async function onPageState(msg, sender) {
  const rt = await getRT();
  const tabId = sender.tab.id;
  const meetCode = parseMeetCode(sender.tab.url ?? sender.url ?? '');   // derived from the trusted URL, not from the message
  const page = msg.page;

  if (page === 'none' || !meetCode) {
    delete rt.pages[tabId];
    if (rt.session?.tabId === tabId) await endSession({ via: 'left_call', ts: sane(msg.since) });
  } else {
    rt.pages[tabId] = { page, meetCode };
    const consent = await getConsent();
    if (consent.status === 'DECLINED' && page === 'in_call') {
      await writeDeclineMarker({ meetCode });
    } else if (consent.status === 'GRANTED') {
      if (rt.session?.tabId === tabId && rt.session.meetCode !== meetCode) await endSession({ via: 'switched_meeting' });
      if (page === 'in_call' && !rt.session) await beginOrResume({ tabId, windowId: sender.tab.windowId, meetCode, since: msg.since });
      else if (page === 'lobby' && rt.session?.tabId === tabId) await endSession({ via: 'left_call', ts: sane(msg.since) });
    }
  }
  await saveRT();
  return { ok: true, state: await publicState(tabId) };
}

async function onEngineLog(msg, sender) {
  const rt = await getRT();
  if (!rt.session || sender.tab?.id !== rt.session.tabId || !ENGINE_EVENT_TYPES.has(msg.eventType)) return { ok: false };
  await logEvent(rt.session.sessionId, msg.eventType, {
    ts: sane(msg.ts),
    durationMs: Number.isFinite(msg.durationMs) ? Math.max(0, Math.round(msg.durationMs)) : null,
    meta: pickMeta(msg.meta),
  });
  return { ok: true };
}

async function startPendingSessions() {
  const rt = await getRT();
  if (rt.session) return;
  for (const [id, p] of Object.entries(rt.pages)) {
    if (p.page !== 'in_call') continue;
    const tab = await chrome.tabs.get(Number(id)).catch(() => null);
    if (tab && await beginOrResume({ tabId: tab.id, windowId: tab.windowId, meetCode: p.meetCode })) break;
  }
}

async function route(msg, sender) {
  const tabId = sender.tab?.id;
  switch (msg.type) {
    case MSG.GET_STATE:
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };

    case MSG.PAGE_STATE:
      return onPageState(msg, sender);

    case MSG.ENV_REPORT: {
      const rt = await getRT();
      rt.env = { visible: !!msg.visible, pip: !!msg.pip };
      await saveRT();
      return { ok: true };
    }

    case MSG.PING: {
      const rt = await getRT();
      const now = Date.now();
      if (rt.session?.tabId === tabId && now - rt.lastHbWrite > 15_000) {
        rt.lastHbWrite = now;
        await setHeartbeat(rt.session.sessionId, now);
        await saveRT();
      }
      return { ok: true, state: await publicState(tabId) };
    }

    case MSG.ENGINE_LOG:
      return onEngineLog(msg, sender);

    case MSG.CONSENT_ACCEPT: {
      try { await grant(msg); } catch (e) { return { ok: false, error: e.message }; }
      await markMemberDirty();
      await startPendingSessions();
      await broadcastState();
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };
    }

    case MSG.CONSENT_DECLINE: {
      const current = await getConsent();
      if (current.status === 'GRANTED') await revokeTracking();      // declining while on == revoking
      else {
        await decline(msg);
        await markMemberDirty();
        const rt = await getRT();
        for (const p of Object.values(rt.pages)) if (p.page === 'in_call') await writeDeclineMarker({ meetCode: p.meetCode });
        await broadcastState();
        flushSoon();
      }
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };
    }

    case MSG.CONSENT_REVOKE:
      await revokeTracking();
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };

    case MSG.PROFILE_UPDATE: {
      try { await updateIdentity(msg); } catch (e) { return { ok: false, error: e.message }; }
      await markMemberDirty();
      await broadcastState();
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };
    }

    case MSG.CLASS_LINK:
    case MSG.CLASS_UNLINK: {
      const rt = await getRT();
      if (rt.session) return { ok: false, error: 'Finish this class first. A class can only be linked or changed before you join.' };
      try { if (msg.type === MSG.CLASS_LINK) await linkClass(msg.code); else await unlinkClass(); }
      catch (e) { return { ok: false, error: e.message }; }
      await broadcastState();          // consent is per class: the student is asked again for the newly linked class
      return { ok: true, state: await publicState(msg.tabId ?? tabId) };
    }

    case MSG.LIST_SESSIONS: {
      const list = await logRepo.listSessions();
      return { ok: true, sessions: list.map((s) => ({ sessionId: s.sessionId, meetCode: s.meetCode, date: s.date, startTs: s.startTs, status: s.status, declinedMarker: s.declinedMarker })) };
    }

    case MSG.GET_MY_LOG: {                 // the student's own attendance record: exactly what a professor would receive
      const rt = await getRT();
      let session = msg.sessionId ? await logRepo.getSession(msg.sessionId) : null;
      session ??= rt.session ? await logRepo.getSession(rt.session.sessionId) : null;
      session ??= (await logRepo.listSessions())[0] ?? null;
      const events = session ? await logRepo.getEvents(session.sessionId) : [];
      if (session) { const { head, ...rest } = session; session = rest; }
      return { ok: true, session, events };
    }

    case MSG.NOTE_HEARTBEAT:
      return { ok: await noteHeartbeat(Date.now()) };

    case MSG.SCREENSHOT_SAVED: {          // sent by the side panel only after a screenshot was stored successfully
      const rt = await getRT();
      if (!rt.session) return { ok: false };
      await noteHeartbeat(Date.now());
      await logEvent(rt.session.sessionId, EventType.SCREENSHOT_CAPTURED, { meta: {} });
      return { ok: true };
    }

    default:
      return { ok: false, error: 'unknown message' };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Must run synchronously inside the click's user gesture, so it is handled before the serial queue.
  if (msg?.type === MSG.OPEN_PANEL && sender.id === chrome.runtime.id && sender.tab && MEET_URL_RE.test(sender.url ?? '')) {
    if (chrome.sidePanel?.open) chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {});
    else openCompanionWindow(sender.tab.id);       // no side panel API in this browser: use a companion window
    sendResponse({ ok: true });
    return false;
  }
  if (!allowed(msg, sender)) { sendResponse({ ok: false, error: 'not allowed' }); return false; }
  serial(() => route(msg, sender)).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e?.message ?? e) }));
  return true;
});

// ---------- browser events ----------
chrome.tabs.onActivated.addListener(() => serial(() => refreshFocus()));
chrome.tabs.onAttached.addListener(() => serial(() => refreshFocus()));
chrome.windows.onFocusChanged.addListener(() => serial(() => refreshFocus()));
chrome.idle.onStateChanged.addListener((state) => serial(() => setLocked(state === 'locked')));
chrome.tabs.onRemoved.addListener((tabId, info) => serial(() => onTabRemoved(tabId, info)));
chrome.tabs.onUpdated.addListener((tabId, info, tab) => serial(async () => {
  if (!info.status && !info.url) return;
  if (tab.url && MEET_URL_RE.test(tab.url)) await enablePanelFor(tabId);
  else chrome.sidePanel?.setOptions({ tabId, enabled: false })?.catch(() => {});
  const rt = await getRT();
  // No `tabs` permission: a tab that left meet.google.com simply has no readable URL, which is all we need to know.
  if (rt.session?.tabId === tabId && (!tab.url || !parseMeetCode(tab.url))) await endSession({ via: 'navigated_away' });
}));

chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'mcc-watchdog') serial(watchdog); });
chrome.idle.setDetectionInterval(60);
chrome.runtime.onInstalled.addListener(() => serial(async () => { await configurePanel(); await injectIntoMeetTabs(); }));

async function watchdog() {
  const now = Date.now();
  const rt = await getRT();
  await reconcileOrphans(now);
  if (!rt.session) return;
  try {
    const tab = await chrome.tabs.get(rt.session.tabId);
    if (!tab.url || !parseMeetCode(tab.url)) { await endSession({ via: 'navigated_away' }); return; }
  } catch { await endSession({ via: 'tab_closed' }); return; }
  rt.lastHbWrite = now;
  await setHeartbeat(rt.session.sessionId, now);      // the heartbeat is how we infer a closed browser later
  await maybeCommitAway(now);
  await flushNoteBurst(now);
  await saveRT();
  flushSoon();
}

// ---------- side panel: only on Meet tabs ----------
async function enablePanelFor(tabId) {
  if (!chrome.sidePanel) return;
  await chrome.sidePanel.setOptions({ tabId, path: PANEL_PATH, enabled: true }).catch(() => {});
}

// Browsers without chrome.sidePanel (Edge, Chrome older than 114, ...): the same panel opens as a small window.
// The window is bound to one Meet tab through ?tab=ID, and focusTracker treats it as part of the class, not as "away".
async function openCompanionWindow(tabId) {
  const rt = await getRT();
  if (rt.panelWindowId != null) {
    try { await chrome.windows.update(rt.panelWindowId, { focused: true }); return; } catch { rt.panelWindowId = null; }
  }
  try {
    const w = await chrome.windows.create({ url: `${chrome.runtime.getURL(PANEL_PATH)}?tab=${tabId}`, type: 'popup', width: 440, height: 780 });
    rt.panelWindowId = w.id;
    await saveRT();
  } catch { /* window could not be created */ }
}

chrome.action.onClicked.addListener((tab) => {      // fires only when there is no side panel behaviour to handle the click
  if (!chrome.sidePanel && tab?.id != null && MEET_URL_RE.test(tab.url ?? '')) openCompanionWindow(tab.id);
});
chrome.windows.onRemoved.addListener((id) => serial(async () => {
  const rt = await getRT();
  if (rt.panelWindowId === id) { rt.panelWindowId = null; await saveRT(); await refreshFocus(); }
}));

async function configurePanel() {
  if (!chrome.sidePanel) return;
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  await chrome.sidePanel.setOptions({ enabled: false }).catch(() => {});
  for (const t of await chrome.tabs.query({ url: MEET_MATCH })) await enablePanelFor(t.id);
}

// Content scripts are not injected into tabs that were open before install / re-enable, so do it ourselves.
async function injectIntoMeetTabs() {
  for (const t of await chrome.tabs.query({ url: MEET_MATCH })) {
    chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['src/content/loader.js'] }).catch(() => {});
  }
}

// ---------- startup (runs every time the worker wakes; cheap) ----------
serial(async () => {
  await getRT();
  if (wasFreshStart()) {            // first run this browser session, or the extension was reloaded / re-enabled
    await configurePanel();
    await injectIntoMeetTabs();
    await saveRT();
  }
  if (!(await chrome.alarms.get('mcc-watchdog'))) chrome.alarms.create('mcc-watchdog', { periodInMinutes: HEARTBEAT_MS / 60_000 });
  await reconcileOrphans();
  await refreshFocus();
  await updateBadge();
  flushSoon();
});
