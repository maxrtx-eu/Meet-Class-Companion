// EventLogger: the ONLY writer of attendance events.
//  - logEvent() is gated: nothing is written unless consent is GRANTED right now.
//  - writeDeclineMarker() / appendRevocationMarker() are the only paths that bypass the gate, and they can
//    only ever write the fixed "declined" marker.
//  - Appends are serialised so each event can chain onto the previous event's hash.
import { EventType, GENESIS_HASH, DECLINED_TEXT, newId, localDate } from '../shared/schema.js';
import { hashEvent } from '../shared/hash.js';
import { getConsent, identityOf, currentClassId } from './consent.js';
import { scheduleFlush } from '../sync/index.js';
import { logRepo } from '../storage/index.js';
import { MSG } from '../shared/messages.js';

let queue = Promise.resolve();
function enqueue(fn) {
  const run = queue.then(fn);
  queue = run.catch(() => {});
  return run;
}

async function appendCore(sessionId, eventType, ts, durationMs, meta, { allowClosed = false } = {}) {
  const sess = await logRepo.getSession(sessionId);
  if (!sess || (sess.status !== 'open' && !allowClosed)) return null;
  const head = sess.head ?? { seq: 0, hash: GENESIS_HASH };
  const evt = {
    eventId: newId(), seq: head.seq + 1,
    sessionId, studentId: sess.studentId, meetCode: sess.meetCode,
    eventType, ts, durationMs, meta, prevHash: head.hash,
  };
  evt.hash = await hashEvent(evt);
  await logRepo.appendEvent(evt);
  chrome.runtime.sendMessage({ type: MSG.LOG_APPENDED, sessionId }).catch(() => {});   // live "My log" refresh
  scheduleFlush();                                                                      // upload soon (no-op unless a class is linked)
  return evt;
}

/** Normal logging path. Returns the stored event, or null if consent is not GRANTED or the session is closed. */
export function logEvent(sessionId, eventType, { ts = Date.now(), durationMs = null, meta = {} } = {}) {
  return enqueue(async () => {
    const consent = await getConsent();
    if (consent.status !== 'GRANTED') return null;            // THE consent gate
    return appendCore(sessionId, eventType, ts, durationMs, meta);
  });
}

/** Revocation mid-session: append the declined marker to the session record (bypasses the gate on purpose). */
export function appendRevocationMarker(sessionId, ts = Date.now()) {
  return enqueue(() => appendCore(sessionId, EventType.CONSENT_DECLINED, ts, null,
    { reason: 'revoked', text: DECLINED_TEXT }, { allowClosed: true }));
}

/**
 * Declined student: exactly one marker per meeting per day. No join/leave times, no activity, date only.
 * Returns the event, or null if the marker for this meeting and date already exists.
 */
export function writeDeclineMarker({ meetCode, now = Date.now() }) {
  return enqueue(async () => {
    const consent = await getConsent();
    if (consent.status !== 'DECLINED') return null;
    const date = localDate(now);
    const meetDate = `${meetCode}|${date}`;
    if ((await logRepo.sessionsForMeetDate(meetDate)).some((s) => s.declinedMarker)) return null;
    const { studentId, displayName } = identityOf(consent);
    const sessionId = `decl-${newId()}`;
    await logRepo.putSession({
      sessionId, studentId, displayName, meetCode, date, meetDate, classId: await currentClassId(),
      startTs: null, endTs: null, status: 'closed', declinedMarker: true, head: null,
    });
    return appendCore(sessionId, EventType.CONSENT_DECLINED, null, null,
      { reason: 'declined', text: DECLINED_TEXT, date }, { allowClosed: true });
  });
}
