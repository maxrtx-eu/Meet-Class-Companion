// Runtime state of the service worker. MV3 service workers are killed after ~30s of inactivity, so
// everything that must survive a restart lives in chrome.storage.session (cleared when the extension reloads).
export const DEFAULT_FOCUS = Object.freeze({ tabActive: true, windowFocused: true, otherWindow: false, locked: false });

export const DEFAULT_RT = {
  session: null,                       // { sessionId, tabId, windowId, meetCode, startTs }
  pages: {},                           // tabId -> { page: 'lobby'|'in_call', meetCode }
  env: { visible: true, pip: false },  // reported by the content script
  focus: { ...DEFAULT_FOCUS },
  away: null,                          // open away episode (see focusTracker.js)
  note: null,                          // open note-taking burst { startTs, lastTs }
  panelWindowId: null,                 // companion window id when the browser has no side panel API
  lastHbWrite: 0,
  lastEnvSent: '',
};

let rt = null;
let loading = null;
let fresh = false;

export function getRT() {
  if (rt) return Promise.resolve(rt);
  loading ??= chrome.storage.session.get('rt').then(({ rt: saved }) => {
    fresh = !saved;     // no saved state => first run this browser session, or the extension was reloaded/re-enabled
    rt = { ...structuredClone(DEFAULT_RT), ...(saved ?? {}) };
    return rt;
  });
  return loading;
}
export const wasFreshStart = () => fresh;
export function resetRuntimeForTests() { rt = null; loading = null; fresh = false; }
export async function saveRT() { if (rt) await chrome.storage.session.set({ rt }); }

// All state transitions run one at a time, so handlers can read-modify-write rt without races.
let queue = Promise.resolve();
export function serial(fn) {
  const run = queue.then(fn);
  queue = run.catch(() => {});
  return run;
}

// Heartbeats: last time we knew a session was alive. Used to infer closed browsers / disabled extension.
export async function getHeartbeats() { return (await chrome.storage.local.get('hb')).hb ?? {}; }
export async function setHeartbeat(sessionId, ts) {
  const hb = await getHeartbeats();
  hb[sessionId] = ts;
  await chrome.storage.local.set({ hb });
}
export async function clearHeartbeat(sessionId) {
  const hb = await getHeartbeats();
  delete hb[sessionId];
  await chrome.storage.local.set({ hb });
}
