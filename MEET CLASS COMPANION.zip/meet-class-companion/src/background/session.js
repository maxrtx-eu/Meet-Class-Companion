// Session lifecycle: start / resume / end, revocation, and inference of what happened while we were not running.
import { getRT, saveRT, DEFAULT_FOCUS, getHeartbeats, setHeartbeat, clearHeartbeat } from './state.js';
import { getConsent, identityOf, revoke, currentClassId } from './consent.js';
import { flushNow, markMemberDirty } from '../sync/index.js';
import { logEvent, appendRevocationMarker } from './logger.js';
import { logRepo } from '../storage/index.js';
import { EventType, ORPHAN_CLOSE_MS, localDate, MEET_MATCH, parseMeetCode } from '../shared/schema.js';
import { CONSENT_VERSION } from '../shared/consentText.js';
import { broadcastState } from './push.js';
import { refreshFocus } from './focusTracker.js';
import { flushNoteBurst } from './notes.js';

const newSessionId = () => `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

/** Accept a timestamp from the content script only if it is recent; otherwise use "now". */
export function sane(ts, now = Date.now()) {
  return Number.isFinite(ts) && ts <= now && now - ts <= 60_000 ? ts : now;
}

function clearRuntime(rt) {
  rt.session = null; rt.away = null; rt.note = null;
  rt.focus = { ...DEFAULT_FOCUS };
  rt.lastEnvSent = '';
}

async function closeRecord(sessionId, ts, extra = {}) {
  const rec = await logRepo.getSession(sessionId);
  if (rec) await logRepo.putSession({ ...rec, status: 'closed', endTs: ts, ...extra });
  await clearHeartbeat(sessionId);
}

/** Start tracking a class on this tab (consent must be GRANTED), or adopt a session that was interrupted moments ago. */
export async function beginOrResume({ tabId, windowId, meetCode, since }) {
  const rt = await getRT();
  const consent = await getConsent();
  if (consent.status !== 'GRANTED' || rt.session) return false;

  const now = Date.now();
  const hbs = await getHeartbeats();
  const open = await logRepo.openSessions();
  const orphan = open.find((o) => o.meetCode === meetCode && now - (hbs[o.sessionId] ?? o.startTs) < ORPHAN_CLOSE_MS);

  if (orphan) {
    // We were not running for a short while (extension reloaded or re-enabled, browser restarted, page crashed).
    const lastSeen = hbs[orphan.sessionId] ?? orphan.startTs;
    rt.session = { sessionId: orphan.sessionId, tabId, windowId, meetCode, startTs: orphan.startTs };
    await logEvent(orphan.sessionId, EventType.MONITORING_STOPPED, {
      ts: lastSeen, durationMs: now - lastSeen, meta: { inferred: true, cause: 'unknown' },
    });
  } else {
    const startTs = sane(since, now);
    const { studentId, displayName } = identityOf(consent);
    const sessionId = newSessionId();
    const date = localDate(startTs);
    await logRepo.putSession({
      sessionId, studentId, displayName, meetCode, date, meetDate: `${meetCode}|${date}`, classId: await currentClassId(),
      startTs, endTs: null, status: 'open', declinedMarker: false, head: null,
    });
    rt.session = { sessionId, tabId, windowId, meetCode, startTs };
    await logEvent(sessionId, EventType.CONSENT_GRANTED, { ts: startTs, meta: { version: consent.version ?? CONSENT_VERSION, grantedTs: consent.ts } });
    await logEvent(sessionId, EventType.JOINED_CLASS, { ts: startTs, meta: {} });
  }

  rt.focus = { ...DEFAULT_FOCUS };
  rt.away = null; rt.note = null; rt.lastEnvSent = '';
  rt.lastHbWrite = now;
  await setHeartbeat(rt.session.sessionId, now);
  await refreshFocus();            // establishes real focus state and pushes the environment to the tab
  await saveRT();
  await broadcastState();
  return true;
}

export async function endSession({ via, ts = Date.now(), meta = {} }) {
  const rt = await getRT();
  const s = rt.session;
  if (!s) return;
  await flushNoteBurst(ts, { force: true });
  await logEvent(s.sessionId, EventType.LEFT_CLASS, { ts, meta: { via, ...meta } });
  await closeRecord(s.sessionId, ts);
  clearRuntime(rt);
  await saveRT();
  await broadcastState();
  flushNow();                          // the class is over: upload the rest and close the session on the server
}

/** The student turns tracking off mid-class (or from the side panel). Logging stops first, then the marker is appended. */
export async function revokeTracking() {
  const rt = await getRT();
  const s = rt.session;
  await revoke();                                   // consent is DECLINED from this instant: the logger gate drops everything else
  if (s) {
    const ts = Date.now();
    await appendRevocationMarker(s.sessionId, ts);
    await closeRecord(s.sessionId, ts, { declinedMarker: true });
  }
  clearRuntime(rt);
  await saveRT();
  await broadcastState();
  await markMemberDirty();
  flushNow();                          // uploads what was consented to, THEN flips the server-side consent to DECLINED
}

export async function onTabRemoved(tabId, info) {
  const rt = await getRT();
  delete rt.pages[tabId];
  if (rt.session?.tabId === tabId) {
    await endSession({ via: info?.isWindowClosing ? 'window_closed' : 'tab_closed', meta: { windowClosing: !!info?.isWindowClosing } });
  } else {
    await saveRT();
  }
}

/**
 * Sessions marked open that nobody is running any more (browser closed, extension disabled, crash).
 * Nothing can log while we are not running, so this is INFERRED after the fact from the last heartbeat:
 *   Meet tab still open  -> MONITORING_STOPPED   (the student is probably still in class, unmonitored)
 *   no Meet tab          -> LEFT_CLASS
 * Both carry inferred:true and the timestamp of the last heartbeat. We cannot tell "disabled" from "crashed".
 */
export async function reconcileOrphans(now = Date.now()) {
  const rt = await getRT();
  const open = await logRepo.openSessions();
  if (!open.length) return;
  const hbs = await getHeartbeats();
  const tabs = await chrome.tabs.query({ url: MEET_MATCH }).catch(() => []);
  for (const o of open) {
    if (rt.session?.sessionId === o.sessionId) continue;
    const lastSeen = hbs[o.sessionId] ?? o.startTs;
    if (now - lastSeen < ORPHAN_CLOSE_MS) continue;
    const tabOpen = tabs.some((t) => parseMeetCode(t.url ?? '') === o.meetCode);
    await logEvent(o.sessionId, tabOpen ? EventType.MONITORING_STOPPED : EventType.LEFT_CLASS, {
      ts: lastSeen,
      durationMs: tabOpen ? now - lastSeen : null,
      meta: { inferred: true, cause: tabOpen ? 'extension_inactive' : 'browser_or_tab_closed' },
    });
    await closeRecord(o.sessionId, lastSeen);
  }
}
