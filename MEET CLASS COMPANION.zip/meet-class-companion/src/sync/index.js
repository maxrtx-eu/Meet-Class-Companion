// The extension's single sync instance. Does nothing until firebaseConfig.js is filled in AND a class is linked.
import { FIREBASE, syncConfigured } from './firebaseConfig.js';
import { createClient } from './firestoreRest.js';
import { createSync } from './syncEngine.js';
import { logRepo } from '../storage/index.js';
import { getConsent } from '../background/consent.js';

let instance = null;
const get = () => (instance ??= createSync({
  client: createClient({ apiKey: FIREBASE.apiKey, projectId: FIREBASE.projectId }),
  repo: logRepo,
  store: chrome.storage.local,
  getConsent,
  configured: syncConfigured,
}));

export { syncConfigured };
export const scheduleFlush = () => { try { if (syncConfigured()) get().scheduleFlush(); } catch { /* never let sync break logging */ } };
export const flushNow = () => (syncConfigured() ? get().flushNow() : Promise.resolve({ skipped: 'not_configured' }));
export const flushSoon = () => (syncConfigured() ? get().flush() : Promise.resolve({ skipped: 'not_configured' }));
export const markMemberDirty = () => (syncConfigured() ? get().markMemberDirty() : Promise.resolve());
export const linkClass = (code) => get().linkClass(code);
export const unlinkClass = () => get().unlinkClass();
