// Minimal Firebase client over the public REST APIs (no SDK, so nothing remote is loaded into the extension):
//   Identity Toolkit  : anonymous sign-in      Secure Token : refresh      Firestore : get document, atomic commit
// Rules in firestore.rules are the real gatekeeper; this file only speaks the protocol.

export function encodeValue(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (v instanceof Date) return { timestampValue: v.toISOString() };
  switch (typeof v) {
    case 'boolean': return { booleanValue: v };
    case 'number': return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
    case 'string': return { stringValue: v };
    case 'object': return Array.isArray(v) ? { arrayValue: { values: v.map(encodeValue) } } : { mapValue: { fields: encodeFields(v) } };
    default: throw new TypeError(`Cannot encode ${typeof v}`);
  }
}
export function encodeFields(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) if (v !== undefined) out[k] = encodeValue(v);
  return out;
}
export function decodeValue(v) {
  if ('nullValue' in v) return null;
  if ('booleanValue' in v) return v.booleanValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return v.doubleValue;
  if ('stringValue' in v) return v.stringValue;
  if ('timestampValue' in v) return new Date(v.timestampValue);
  if ('mapValue' in v) return decodeFields(v.mapValue.fields ?? {});
  if ('arrayValue' in v) return (v.arrayValue.values ?? []).map(decodeValue);
  return null;
}
export function decodeFields(fields) {
  const out = {};
  for (const [k, v] of Object.entries(fields ?? {})) out[k] = decodeValue(v);
  return out;
}
export const decodeDoc = (doc) => ({ __id: doc.name.split('/').pop(), ...decodeFields(doc.fields) });

export const createWrite = (name, data) => ({ update: { name, fields: encodeFields(data) }, currentDocument: { exists: false } });
export const updateWrite = (name, data) => ({ update: { name, fields: encodeFields(data) }, updateMask: { fieldPaths: Object.keys(data) } });

export function createClient({ apiKey, projectId, fetchImpl }) {
  const doFetch = (...a) => (fetchImpl ?? globalThis.fetch)(...a);
  const root = `projects/${projectId}/databases/(default)/documents`;
  const base = `https://firestore.googleapis.com/v1/${root}`;

  async function json(res) {
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(body?.error?.message ?? `HTTP ${res.status}`);
      err.status = res.status;
      err.code = body?.error?.status ?? body?.error?.message ?? null;
      throw err;
    }
    return body;
  }

  return {
    docName: (path) => `${root}/${path}`,
    async signUpAnonymous() {
      const r = await json(await doFetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ returnSecureToken: true }),
      }));
      return { idToken: r.idToken, refreshToken: r.refreshToken, uid: r.localId, expiresIn: Number(r.expiresIn) };
    },
    async refresh(refreshToken) {
      const r = await json(await doFetch(`https://securetoken.googleapis.com/v1/token?key=${apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}`,
      }));
      return { idToken: r.id_token, refreshToken: r.refresh_token, uid: r.user_id, expiresIn: Number(r.expires_in) };
    },
    async getDoc(path, idToken) {
      const res = await doFetch(`${base}/${path}`, { headers: { Authorization: `Bearer ${idToken}` } });
      if (res.status === 404) return null;
      return decodeDoc(await json(res));
    },
    async commit(writes, idToken) {
      return json(await doFetch(`${base}:commit`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` }, body: JSON.stringify({ writes }),
      }));
    },
  };
}
