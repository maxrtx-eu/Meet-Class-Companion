// Uploads the attendance log (and ONLY the attendance log) to the professor's class in Firestore.
//
//  * Local-first: logging never waits for the network. Events sit in IndexedDB and are pushed when possible.
//  * Nothing leaves the device before the student has decided (consent UNSET), or for sessions not tied to a class.
//  * Events are create-only on the server (rules forbid update/delete), session docs may only go open -> closed.
//  * Order matters for consent: GRANTED  => member doc first, then sessions.
//                                DECLINED => finish uploading what was consented to, THEN flip the member to DECLINED.
//  * Progress cursors live in chrome.storage (syncState), never in the session records: rewriting those could race
//    with the logger and break the hash chain.
import { createWrite, updateWrite } from './firestoreRest.js';

const CHUNK = 200;
const DAY = 86_400_000;

const isAlreadyExists = (e) => e?.code === 'ALREADY_EXISTS' || e?.status === 409;

export function createSync({ client, repo, store, getConsent, configured = () => true, now = () => Date.now() }) {
  let token = null;
  let inflight = null;
  let timer = null;
  let failures = 0;
  let nextAttempt = 0;

  // ----- auth (anonymous Firebase user, refresh token kept in extension storage) -----
  async function auth() {
    if (token && token.exp - 60_000 > now()) return token;
    const stored = (await store.get('fbAuth')).fbAuth;
    let r = null;
    if (stored?.refreshToken) {
      try { r = await client.refresh(stored.refreshToken); } catch (e) { if (e.status !== 400) throw e; }
    }
    r ??= await client.signUpAnonymous();
    token = { idToken: r.idToken, uid: r.uid, exp: now() + r.expiresIn * 1000 };
    await store.set({ fbAuth: { refreshToken: r.refreshToken, uid: r.uid } });
    return token;
  }

  const getLink = async () => (await store.get('classLink')).classLink ?? null;
  const getState = async () => (await store.get('syncState')).syncState ?? { sessions: {}, memberDirty: true };
  const saveState = (s) => store.set({ syncState: s });

  async function commitCreates(writes, t) {
    try { await client.commit(writes, t.idToken); }
    catch (e) {
      if (!isAlreadyExists(e)) throw e;
      // A previous attempt succeeded but its reply was lost: redo one by one and treat "already there" as done.
      for (const w of writes) {
        try { await client.commit([w], t.idToken); } catch (e2) { if (!isAlreadyExists(e2)) throw e2; }
      }
    }
  }

  async function pushMember(link, consent, t, st) {
    const name = client.docName(`classes/${link.classId}/members/${t.uid}`);
    await client.commit([updateWrite(name, {
      uid: t.uid, studentId: consent.studentNumber || 'unknown', displayName: consent.displayName || '',
      consentStatus: consent.status, consentVersion: consent.version ?? null, updatedAt: now(),
    })], t.idToken);
    st.memberDirty = false;
    await saveState(st);
  }

  async function pushSession(s, link, t, st) {
    const ss = (st.sessions[s.sessionId] ??= { syncedSeq: 0, opened: false, closed: false });
    if (ss.closed) return;
    const sessName = client.docName(`classes/${link.classId}/sessions/${s.sessionId}`);
    const expireAt = new Date((s.startTs ?? now()) + (link.retentionDays ?? 120) * DAY);

    if (!ss.opened) {
      await commitCreates([createWrite(sessName, {
        uid: t.uid, classId: link.classId, studentId: s.studentId, displayName: s.displayName ?? '', meetCode: s.meetCode, date: s.date,
        startTs: s.startTs, status: s.declinedMarker ? 'closed' : 'open', declinedMarker: !!s.declinedMarker, lastSeen: now(), endTs: s.endTs ?? null, expireAt,
      })], t);
      ss.opened = true;
      await saveState(st);
    }

    const events = (await repo.getEvents(s.sessionId)).filter((e) => e.seq > ss.syncedSeq);
    for (let i = 0; i < events.length; i += CHUNK) {
      const chunk = events.slice(i, i + CHUNK);
      const writes = chunk.map((e) => createWrite(client.docName(`classes/${link.classId}/sessions/${s.sessionId}/events/${e.seq}`), {
        uid: t.uid, eventId: e.eventId, seq: e.seq, sessionId: e.sessionId, studentId: e.studentId, meetCode: e.meetCode, eventType: e.eventType,
        ts: e.ts, durationMs: e.durationMs, meta: e.meta ?? {}, prevHash: e.prevHash, hash: e.hash, expireAt,
      }));
      if (!s.declinedMarker) writes.push(updateWrite(sessName, { lastSeen: now() }));
      await commitCreates(writes, t);
      ss.syncedSeq = chunk.at(-1).seq;
      await saveState(st);
    }

    if (s.declinedMarker) { if (ss.syncedSeq >= 1) { ss.closed = true; await saveState(st); } return; }
    if (s.status === 'closed') {
      await client.commit([updateWrite(sessName, { status: 'closed', endTs: s.endTs ?? now(), lastSeen: now() })], t.idToken);
      ss.closed = true;
      await saveState(st);
    }
  }

  async function runFlush() {
    if (!configured()) return { skipped: 'not_configured' };
    const link = await getLink();
    if (!link) return { skipped: 'no_class' };
    const consent = await getConsent();
    if (consent.status === 'UNSET') return { skipped: 'undecided' };      // nothing leaves the device before a decision
    const t = await auth();
    const st = await getState();
    if (consent.status === 'GRANTED' && st.memberDirty) await pushMember(link, consent, t, st);
    const sessions = (await repo.listSessions()).filter((s) => s.classId === link.classId).sort((a, b) => (a.startTs ?? 0) - (b.startTs ?? 0));
    for (const s of sessions) await pushSession(s, link, t, st);
    if (consent.status === 'DECLINED' && st.memberDirty) await pushMember(link, consent, t, st);
    return { ok: true };
  }

  async function flush({ force = false } = {}) {
    if (inflight) return inflight;
    if (!force && now() < nextAttempt) return { skipped: 'backoff' };
    inflight = (async () => {
      try {
        const r = await runFlush();
        if (r.ok) { failures = 0; nextAttempt = 0; await store.set({ syncStatus: { lastOkTs: now(), lastError: null } }); }
        return r;
      } catch (e) {
        failures += 1;
        nextAttempt = now() + Math.min(300_000, 5_000 * 2 ** failures);
        await store.set({ syncStatus: { lastOkTs: (await store.get('syncStatus')).syncStatus?.lastOkTs ?? null, lastError: String(e.message ?? e).slice(0, 200) } });
        return { error: e.message };
      } finally { inflight = null; }
    })();
    return inflight;
  }

  return {
    flush,
    flushNow: () => flush({ force: true }),
    scheduleFlush(ms = 5000) {
      if (!configured() || timer) return;
      timer = setTimeout(() => { timer = null; flush(); }, ms);
      timer?.unref?.();
    },
    async markMemberDirty() { const st = await getState(); st.memberDirty = true; await saveState(st); },

    /** Resolve a class code and remember the class. The consent text then names the professor and class. */
    async linkClass(code) {
      if (!configured()) throw new Error('Class upload is not set up in this copy of the extension.');
      const clean = String(code ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (clean.length < 6 || clean.length > 12) throw new Error('That class code does not look right.');
      const t = await auth();
      const doc = await client.getDoc(`joinCodes/${clean}`, t.idToken);
      if (!doc?.classId) throw new Error('Class code not found. Check it with your professor.');
      const link = {
        classId: String(doc.classId), joinCode: clean,
        className: String(doc.className ?? '').slice(0, 80), professorName: String(doc.professorName ?? '').slice(0, 80),
        retentionDays: Number(doc.retentionDays) > 0 ? Number(doc.retentionDays) : 120,
      };
      await store.set({ classLink: link });
      await this.markMemberDirty();
      return link;
    },
    async unlinkClass() { await store.remove('classLink'); },
    getLink,
  };
}
