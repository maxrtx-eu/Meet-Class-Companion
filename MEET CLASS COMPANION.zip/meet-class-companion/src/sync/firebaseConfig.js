// Fill in from Firebase console > Project settings > Your apps > Web app.
// The apiKey is an identifier, not a secret: access is enforced by Firebase Auth + firestore.rules.
// While apiKey/projectId are empty the extension works fully offline (hand-in file mode) and uploads nothing.
export const FIREBASE = {
  apiKey: 'AIzaSyCt8cEKXHEqgb_XkWO56cbP54eipSRXzm4',
  projectId: 'class-companion-ce085',
};
export const syncConfigured = () => !!(FIREBASE.apiKey && FIREBASE.projectId);
