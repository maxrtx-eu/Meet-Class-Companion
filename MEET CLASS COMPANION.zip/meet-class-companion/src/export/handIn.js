// The "hand-in file": what a student gives their professor. It contains the attendance log ONLY
// (events, session record). Notes and screenshots are stored elsewhere and this file cannot reference them.
// The professor's viewer re-verifies the hash chain and recomputes the summary itself; it does not trust a summary in the file.
import { EventType } from '../shared/schema.js';

export const HANDIN_FORMAT = 'mcc-attendance';
export const HANDIN_VERSION = 1;
const MAX_BYTES = 8_000_000;
const VALID_TYPES = new Set(Object.values(EventType));

export function buildHandIn({ session, events, exportedAt = Date.now(), extensionVersion = '' }) {
  return JSON.stringify({
    format: HANDIN_FORMAT, version: HANDIN_VERSION, exportedAt, extensionVersion,
    session, events: [...events].sort((a, b) => a.seq - b.seq),
  }, null, 1);
}

export const handInFilename = (session, safe) => `attendance_${safe(session.studentId || 'student')}_${safe(session.meetCode)}_${session.date}.json`;

/** @returns {{ok:true,data:{session,events}}|{ok:false,error:string}} */
export function parseHandIn(text) {
  if (typeof text !== 'string' || text.length > MAX_BYTES) return { ok: false, error: 'File is empty or too large.' };
  let d;
  try { d = JSON.parse(text); } catch { return { ok: false, error: 'This is not a valid hand-in file (not JSON).' }; }
  if (d?.format !== HANDIN_FORMAT) return { ok: false, error: 'This is not a Class Companion attendance file.' };
  if (d.version !== HANDIN_VERSION) return { ok: false, error: `Unsupported file version ${d.version}.` };
  if (!d.session || typeof d.session !== 'object' || !Array.isArray(d.events)) return { ok: false, error: 'The file is missing its session or events.' };
  for (const e of d.events) {
    const good = e && Number.isInteger(e.seq) && VALID_TYPES.has(e.eventType) && typeof e.hash === 'string' && typeof e.prevHash === 'string'
      && e.sessionId === d.session.sessionId && (e.ts === null || Number.isFinite(e.ts));
    if (!good) return { ok: false, error: 'An event in the file is malformed.' };
  }
  return { ok: true, data: { session: d.session, events: d.events, exportedAt: d.exportedAt } };
}
