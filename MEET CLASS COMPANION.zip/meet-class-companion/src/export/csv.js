// CSV for spreadsheets. Names and notes-free metadata come from the student's machine, so cells that could be read
// as spreadsheet formulas (= + - @) are neutralised. A UTF-8 BOM keeps accents readable in Excel.
import { describeEvent, localDate, localTime } from '../shared/schema.js';

const FORMULA_START = /^[=+\-@\t\r]/;

export function csvCell(v) {
  if (v === null || v === undefined) return '';
  let s = String(v);
  if (typeof v === 'string' && FORMULA_START.test(s)) s = `'${s}`;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(columns, rows) {
  const head = columns.map((c) => csvCell(c.header)).join(',');
  const body = rows.map((r) => columns.map((c) => csvCell(c.value(r))).join(','));
  return '\ufeff' + [head, ...body].join('\r\n') + '\r\n';
}

const iso = (ts) => (ts == null ? '' : new Date(ts).toISOString());
const local = (ts) => (ts == null ? '' : `${localDate(ts)} ${localTime(ts)}`);
const min = (ms) => (ms == null ? '' : Math.round((ms / 60000) * 100) / 100);

export function eventsCsv(session, events) {
  const cols = [
    { header: 'seq', value: (e) => e.seq },
    { header: 'time_local', value: (e) => local(e.ts) },
    { header: 'time_utc', value: (e) => iso(e.ts) },
    { header: 'event_type', value: (e) => e.eventType },
    { header: 'duration_s', value: (e) => (e.durationMs == null ? '' : Math.round(e.durationMs / 100) / 10) },
    { header: 'description', value: (e) => describeEvent(e) },
    { header: 'details_json', value: (e) => JSON.stringify(e.meta ?? {}) },
    { header: 'student_id', value: (e) => e.studentId },
    { header: 'student_name', value: () => session.displayName ?? '' },
    { header: 'meet_code', value: (e) => e.meetCode },
    { header: 'session_id', value: (e) => e.sessionId },
    { header: 'prev_hash', value: (e) => e.prevHash },
    { header: 'hash', value: (e) => e.hash },
  ];
  return toCsv(cols, [...events].sort((a, b) => a.seq - b.seq));
}

// One row per session. `integrityOk` is only known where the hash chain was checked (professor viewer / export time).
export function summaryCsv(summaries) {
  const p = (s) => s.prompts ?? {};
  const cols = [
    { header: 'status', value: (s) => s.status },
    { header: 'student_id', value: (s) => s.studentId },
    { header: 'student_name', value: (s) => s.displayName },
    { header: 'meet_code', value: (s) => s.meetCode },
    { header: 'date', value: (s) => s.date },
    { header: 'start_local', value: (s) => local(s.startTs) },
    { header: 'end_local', value: (s) => local(s.endTs) },
    { header: 'ended_by', value: (s) => s.endedBy },
    { header: 'total_min', value: (s) => min(s.totalMs) },
    { header: 'present_pct', value: (s) => s.percent?.present },
    { header: 'note_taking_pct', value: (s) => s.percent?.noteTaking },
    { header: 'engaged_pct', value: (s) => s.percent?.engaged },
    { header: 'confirmed_idle_pct', value: (s) => s.percent?.confirmedIdle },
    { header: 'away_pct', value: (s) => s.percent?.away },
    { header: 'unmonitored_pct', value: (s) => s.percent?.unmonitored },
    { header: 'away_other_tab_min', value: (s) => min(s.ms?.AWAY_TAB) },
    { header: 'away_other_app_or_window_min', value: (s) => min(s.ms?.AWAY_WINDOW) },
    { header: 'away_picture_in_picture_min', value: (s) => min(s.ms?.AWAY_PIP) },
    { header: 'away_other_chrome_window_meet_visible_min', value: (s) => min(s.ms?.AWAY_OTHER_WINDOW_VISIBLE) },
    { header: 'away_screen_locked_min', value: (s) => min(s.ms?.AWAY_SCREEN_LOCKED) },
    { header: 'prompts_shown', value: (s) => p(s).shown },
    { header: 'prompts_answered', value: (s) => p(s).answered },
    { header: 'prompts_answered_late', value: (s) => p(s).answeredLate },
    { header: 'prompts_never_answered', value: (s) => p(s).neverAnswered },
    { header: 'prompts_cancelled_student_left', value: (s) => p(s).cancelled },
    { header: 'avg_response_sec', value: (s) => p(s).avgResponseSec },
    { header: 'median_response_sec', value: (s) => p(s).medianResponseSec },
    { header: 'responses_fast', value: (s) => p(s).fast },
    { header: 'responses_medium', value: (s) => p(s).medium },
    { header: 'responses_slow', value: (s) => p(s).slow },
    { header: 'longest_away_min', value: (s) => min(s.longestAwayMs) },
    { header: 'longest_confirmed_idle_min', value: (s) => min(s.longestIdleMs) },
    { header: 'integrity_chain_ok', value: (s) => (s.integrityOk === undefined ? '' : s.integrityOk ? 'yes' : 'NO') },
    { header: 'note', value: (s) => s.text ?? '' },
  ];
  return toCsv(cols, summaries);
}
