import { DEFAULT_CONFIG, loadConfig, saveConfig, sanitizeConfig } from '../shared/config.js';

const form = document.getElementById('form');
const msg = document.getElementById('msg');

function fill(cfg) {
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') el.checked = !!cfg[el.name];
    else el.value = cfg[el.name];
  }
}
function read() {
  const raw = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    raw[el.name] = el.type === 'checkbox' ? el.checked : el.value;
  }
  return sanitizeConfig(raw);
}
function flash(text) { msg.textContent = text; setTimeout(() => { msg.textContent = ''; }, 2500); }

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const saved = await saveConfig(read());
  fill(saved);                       // shows any clamping that was applied
  flash('Saved');
});
document.getElementById('reset').addEventListener('click', async () => { fill(await saveConfig({ ...DEFAULT_CONFIG })); flash('Defaults restored'); });
loadConfig().then(fill);
