// Activity sensor. It records ONE number: the time of the last user input in this tab.
// Event objects are never inspected (no keys, no coordinates) apart from isTrusted, which filters out
// synthetic events dispatched by page scripts. Listeners exist only while monitoring is on.
const EVENTS = ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart'];

export function createInputSensor(onActivity) {
  let last = 0;
  let ac = null;
  const handler = (e) => {
    if (!e.isTrusted) return;
    const t = Date.now();
    if (t - last < 500) return;
    last = t;
    onActivity();
  };
  return {
    start() {
      if (ac) return;
      ac = new AbortController();
      for (const ev of EVENTS) document.addEventListener(ev, handler, { capture: true, passive: true, signal: ac.signal });
    },
    stop() { ac?.abort(); ac = null; },
  };
}
