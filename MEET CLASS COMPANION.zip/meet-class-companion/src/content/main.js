// Content-script orchestrator. Owns: Meet page detection, the 1-second idle clock, the in-tab UI.
// The service worker stays authoritative for consent, sessions and logging; this file only reports and displays.
// While consent is not GRANTED nothing here listens to input or runs a timer.
import { MSG } from '../shared/messages.js';
import { DEFAULT_CONFIG } from '../shared/config.js';
import { createIdleState, stepIdle } from '../shared/idleEngine.js';
import { createMeetDetector } from './meetDetector.js';
import { createInputSensor } from './inputSensor.js';
import { createUI } from './ui.js';

const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
const isPip = () => !!document.pictureInPictureElement || !!globalThis.documentPictureInPicture?.window;

export function start() {
  try { globalThis.__mccShutdown?.(); } catch { /* previous instance already gone */ }

  const ac = new AbortController();
  let state = { consentStatus: 'UNSET', monitoredHere: false, config: DEFAULT_CONFIG, displayName: '', studentNumber: '' };
  let env = { tabActive: true, windowFocused: true, locked: false, notesActive: false };
  let page = { page: 'none', meetCode: null };
  let running = false;
  let consentDismissed = false;
  let dead = false;
  let tickTimer = null;
  let pingTimer = null;
  let idle = createIdleState(Date.now());

  const send = (msg) => {
    if (!alive()) { shutdown(); return Promise.resolve(null); }    // extension was reloaded: this instance is orphaned
    return chrome.runtime.sendMessage(msg).catch(() => null);
  };

  // ----- idle engine glue -----
  function dispatch(input) {
    const { state: next, effects } = stepIdle(idle, input, Date.now(), state.config);
    idle = next;
    for (const fx of effects) {
      if (fx.type === 'SHOW_PROMPT') {
        ui.showIdlePrompt({ shownTs: fx.shownTs, windowMs: fx.windowMs, sound: state.config.sound, onRespond: () => dispatch({ type: 'RESPOND' }) });
      } else if (fx.type === 'HIDE_PROMPT') {
        ui.hideIdlePrompt();
      } else if (fx.type === 'LOG') {
        send({ type: MSG.ENGINE_LOG, eventType: fx.eventType, ts: fx.ts, durationMs: fx.durationMs, meta: fx.meta });
      }
    }
  }
  const eligible = () => running && env.tabActive && env.windowFocused && !env.locked && !env.notesActive && document.visibilityState === 'visible';
  const syncEligibility = () => dispatch({ type: 'ENV', eligible: eligible() });

  const sensor = createInputSensor(() => dispatch({ type: 'INPUT' }));

  function startMonitoring() {
    if (running) return;
    running = true;
    idle = createIdleState(Date.now());
    sensor.start();
    tickTimer = setInterval(() => { if (!alive()) return shutdown(); ui.ensureAttached(); dispatch({ type: 'TICK' }); }, 1000);
    pingTimer = setInterval(async () => { const r = await send({ type: MSG.PING }); if (r?.state) applyState(r.state); }, 20_000);
    syncEligibility();
  }
  function stopMonitoring({ emit }) {
    if (!running) return;
    if (emit) dispatch({ type: 'RESET', cause: 'call_left' });      // closes an open idle episode so its duration is recorded
    else { idle = createIdleState(Date.now()); ui.hideIdlePrompt(); }  // revoked: record nothing more
    running = false;
    sensor.stop();
    clearInterval(tickTimer);
    clearInterval(pingTimer);
  }

  // ----- UI + consent -----
  const ui = createUI({
    onOpenPanel: () => { send({ type: MSG.OPEN_PANEL }); },          // must be called synchronously from the click
    getIdentity: () => ({ displayName: state.displayName ?? '', studentNumber: state.studentNumber ?? '' }),
    getClass: () => ({ classInfo: state.classInfo ?? null, syncAvailable: !!state.syncAvailable }),
    onLinkClass: (code, ident) => changeClass({ type: MSG.CLASS_LINK, code }, ident),
    onUnlinkClass: (ident) => changeClass({ type: MSG.CLASS_UNLINK }, ident),
    onSaveProfile: async (ident) => {
      const res = await send({ type: MSG.PROFILE_UPDATE, ...ident });
      if (!res?.ok) return res?.error ?? 'Could not save your details. Try again.';
      applyState(res.state);
      return null;
    },
    onRevoke: async () => {
      stopMonitoring({ emit: false });
      applyState((await send({ type: MSG.CONSENT_REVOKE }))?.state);
    },
    onReopenConsent: () => { consentDismissed = false; openConsent(); },
  });

  // Linking or changing the class changes who sees the log, so the choice is asked again, with the new text.
  async function changeClass(msg, ident) {
    const res = await send(msg);
    if (!res?.ok) return res?.error ?? 'Could not change the class. Try again.';
    applyState(res.state);
    if (ident) state = { ...state, displayName: ident.displayName || state.displayName, studentNumber: ident.studentNumber || state.studentNumber };
    ui.hideConsent();
    consentDismissed = false;
    refreshUI();
    return null;
  }

  function openConsent() {
    ui.showConsent({
      config: state.config,
      identity: state,
      classInfo: state.classInfo ?? null,
      syncAvailable: !!state.syncAvailable,
      onLinkClass: (code, ident) => changeClass({ type: MSG.CLASS_LINK, code }, ident),
      onUnlinkClass: (ident) => changeClass({ type: MSG.CLASS_UNLINK }, ident),
      onAccept: async (ident) => {
        const res = await send({ type: MSG.CONSENT_ACCEPT, ...ident });
        if (!res?.ok) return res?.error ?? 'Could not save your choice. Try again.';
        ui.hideConsent();
        applyState(res.state);
        return null;
      },
      onDecline: async (ident) => {
        const res = await send({ type: MSG.CONSENT_DECLINE, ...ident });
        ui.hideConsent();
        applyState(res?.state);
      },
      onLater: () => { consentDismissed = true; ui.hideConsent(); refreshUI(); },
    });
  }

  function refreshUI() {
    if (page.page === 'none' && !running) { ui.hideIndicator(); ui.hideConsent(); return; }
    const status = state.consentStatus;
    // The corner badge is always there inside a meeting: it is how the student sees, edits and changes their choice.
    ui.showIndicator(status === 'GRANTED' ? 'active' : status === 'DECLINED' ? 'off' : 'undecided');
    if (status === 'GRANTED') ui.hideConsent();
    else if (status === 'UNSET' && !consentDismissed && page.page !== 'none') openConsent();
  }

  function applyState(next) {
    if (!next) return;
    state = next;
    if (next.env) env = next.env;
    const shouldRun = next.consentStatus === 'GRANTED' && next.monitoredHere;
    if (shouldRun && !running) startMonitoring();
    else if (!shouldRun && running) stopMonitoring({ emit: false });
    syncEligibility();
    refreshUI();
  }

  // ----- page detection -----
  const detector = createMeetDetector(async (next) => {
    page = { page: next.page, meetCode: next.meetCode };
    if (next.page === 'none' && running) stopMonitoring({ emit: true });
    const res = await send({ type: MSG.PAGE_STATE, page: next.page, meetCode: next.meetCode, since: next.since });
    applyState(res?.state);
    refreshUI();
  });

  // ----- environment the page can observe -----
  const reportEnv = () => send({ type: MSG.ENV_REPORT, visible: document.visibilityState === 'visible', pip: isPip() });
  const opts = { signal: ac.signal };
  document.addEventListener('visibilitychange', () => { syncEligibility(); reportEnv(); }, opts);
  document.addEventListener('enterpictureinpicture', reportEnv, { ...opts, capture: true });
  document.addEventListener('leavepictureinpicture', reportEnv, { ...opts, capture: true });
  globalThis.documentPictureInPicture?.addEventListener?.('enter', reportEnv, opts);

  const onMsg = (msg) => {
    if (msg?.type === MSG.STATE_CHANGED && msg.state) applyState(msg.state);
    else if (msg?.type === MSG.ENV_UPDATE && msg.env) { env = msg.env; syncEligibility(); }
  };
  chrome.runtime.onMessage.addListener(onMsg);

  function shutdown() {
    if (dead) return;
    dead = true;
    clearInterval(tickTimer);
    clearInterval(pingTimer);
    sensor.stop();
    detector.stop();
    ui.destroy();
    ac.abort();
    try { chrome.runtime.onMessage.removeListener(onMsg); } catch { /* context invalidated */ }
    if (globalThis.__mccShutdown === shutdown) delete globalThis.__mccShutdown;
  }
  globalThis.__mccShutdown = shutdown;

  send({ type: MSG.GET_STATE }).then((res) => {      // a reloaded page re-joins an active session immediately
    applyState(res?.state);
    reportEnv();
    detector.start();
  });
}
