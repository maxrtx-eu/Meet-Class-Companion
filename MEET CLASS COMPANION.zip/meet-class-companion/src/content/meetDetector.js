// Decides whether this tab is NOT a meeting, the pre-join/ended screen ("lobby"), or an active call ("in_call").
//
// Meet's DOM is not a public API: expect to maintain this file. All page-specific knowledge lives HERE.
// Signals for "in a call", any one is enough:
//   1. the Leave-call button's icon ligature text "call_end" (locale independent, best signal)
//   2. a button whose aria-label says leave call/meeting (a few locales; extend LEAVE_LABELS as needed)
// Hysteresis stops flicker: entering a call must hold 1.5s, leaving it must hold 6s (Meet hides its toolbar).
import { parseMeetCode } from '../shared/schema.js';

const LEAVE_LABELS = [/leave call/i, /leave meeting/i, /salir de la llamada/i, /quitter l.appel/i, /anruf verlassen/i, /sair da chamada/i];
const STABLE_MS = { in_call: 1500, lobby: 800, none: 800 };
const LEAVE_STABLE_MS = 6000;

export function hasInCallUI(doc = document) {
  for (const el of doc.querySelectorAll('button i, button .google-symbols, button .material-icons')) {
    if (el.textContent.trim() === 'call_end') return true;
  }
  for (const b of doc.querySelectorAll('button[aria-label]')) {
    const label = b.getAttribute('aria-label') ?? '';
    if (LEAVE_LABELS.some((re) => re.test(label))) return true;
  }
  return false;
}

export function classify(href = location.href, doc = document) {
  const meetCode = parseMeetCode(href);
  if (!meetCode) return { page: 'none', meetCode: null };
  return { page: hasInCallUI(doc) ? 'in_call' : 'lobby', meetCode };
}

/** onChange({page, meetCode, since}) fires only after the new classification has been stable; `since` is when it began. */
export function createMeetDetector(onChange, { pollMs = 1000 } = {}) {
  let current = { page: 'none', meetCode: null };
  let cand = null;
  let candSince = 0;
  let timer = null;

  function evaluate() {
    const raw = classify();
    const now = Date.now();
    if (raw.page === current.page && raw.meetCode === current.meetCode) { cand = null; return; }
    if (!cand || cand.page !== raw.page || cand.meetCode !== raw.meetCode) { cand = raw; candSince = now; return; }
    const need = current.page === 'in_call' && raw.page !== 'in_call' ? LEAVE_STABLE_MS : STABLE_MS[raw.page];
    if (now - candSince >= need) {
      current = raw;
      cand = null;
      onChange({ ...current, since: candSince });
    }
  }
  return {
    start() { if (!timer) { evaluate(); timer = setInterval(evaluate, pollMs); } },
    stop() { clearInterval(timer); timer = null; },
    current: () => ({ ...current }),
  };
}
