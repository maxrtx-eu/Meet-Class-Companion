// Classic content script (manifest-declared). Loads the real code as an ES module so it can share
// src/shared/* with the service worker and the unit tests. Re-injection safe: main.js shuts down any previous instance.
(async () => {
  try {
    const mod = await import(chrome.runtime.getURL('src/content/main.js'));
    mod.start();
  } catch (e) {
    console.warn('[Class Companion] could not start', e);
  }
})();
