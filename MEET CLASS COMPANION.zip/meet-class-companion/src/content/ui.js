// All in-tab UI lives in one closed Shadow DOM: the consent dialog, the "monitoring is on" badge and the
// "Are you still there?" overlay. Meet's CSS cannot reach in, and Meet's scripts cannot reach the nodes.
// Visual language: a classroom chalkboard for the prompt (unmistakably not Meet), paper for the consent text.
import { h } from '../shared/dom.js';
import { buildConsentText } from '../shared/consentText.js';

const CSS = `
:host{all:initial}
*,*::before,*::after{box-sizing:border-box}
[hidden]{display:none!important}
.layer{position:fixed;inset:0;pointer-events:none;font:15px/1.5 "Segoe UI",system-ui,-apple-system,Roboto,sans-serif;color:#17201e}
.layer>*{pointer-events:auto}
button,input{font:inherit}
button{cursor:pointer}
:focus-visible{outline:3px solid #0b6e63;outline-offset:2px}

.pill{position:fixed;top:12px;left:12px;display:flex;align-items:center;gap:8px;padding:8px 15px 8px 12px;border:0;border-radius:999px;background:#17201e;color:#eef2ee;font-size:13px;font-weight:600;box-shadow:0 2px 12px rgba(0,0,0,.4)}
.pill:focus-visible{outline-color:#ffd966}
.dot{width:10px;height:10px;border-radius:50%;flex:none}
.dot.active{background:#ff5a52}
.dot.off{background:#9aa5a0}
.dot.undecided{background:#ffd966}
.pop{position:fixed;top:54px;left:12px;width:min(360px,calc(100vw - 24px));max-height:calc(100vh - 70px);overflow:auto;padding:16px 18px;border-radius:14px;background:#fff;box-shadow:0 8px 32px rgba(0,0,0,.45);font-size:14px}
.pop p{margin:0 0 12px}
.pop-title{margin:0 0 6px;font-size:17px}
.pop h3{margin:10px 0 6px;font-size:14px}
.pop-status{font-weight:600}
.fields.one{grid-template-columns:1fr;margin:0 0 6px}
.row.sep{margin-top:14px;padding-top:12px;border-top:1px solid #dfe5e2}
.ok{min-height:20px;margin:6px 0 0;color:#0b6e63;font-weight:600}
.classbox{margin:12px 0 4px;padding:12px 14px;border:2px solid #cfd8d4;border-radius:12px;display:grid;gap:8px}
.classbox label{font-weight:600;font-size:13px}
.classbox input{height:42px;padding:0 10px;border:2px solid #8b9894;border-radius:8px;font-size:15px;text-transform:uppercase}
.row{display:flex;flex-wrap:wrap;gap:8px}

.btn{min-height:46px;padding:0 18px;border-radius:10px;border:2px solid #17201e;background:#fff;color:#17201e;font-weight:700}
.btn.solid{background:#17201e;color:#fff}
.btn:disabled{opacity:.55;cursor:default}
.link{background:none;border:0;padding:6px 0;color:#0b6e63;text-decoration:underline;font-size:14px}

.scrim{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(14,20,18,.8)}
.paper{width:min(620px,100%);max-height:94vh;overflow:auto;padding:26px 30px 22px;border-radius:16px;background:#fff;box-shadow:0 12px 48px rgba(0,0,0,.5)}
.paper h2{margin:0 0 6px;font-size:22px;line-height:1.25}
.paper h3{margin:18px 0 4px;font-size:15px}
.paper p{margin:0 0 8px}
.paper ul{margin:0;padding-left:20px}
.paper li{margin:3px 0}
.fields{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0 6px}
.fields label{display:flex;flex-direction:column;gap:4px;font-size:13px;font-weight:600}
.fields input{height:42px;padding:0 10px;border:2px solid #8b9894;border-radius:8px;font-size:15px}
.err{min-height:20px;margin:6px 0 0;color:#b3261e;font-weight:600}
.foot{margin:12px 0 0;font-size:13px;color:#4d5a56}
.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:10px}

.board{width:min(660px,100%);padding:52px 40px 38px;text-align:center;border-radius:14px;border:12px solid #7a5230;background:#1e3a34;color:#eef2ee;box-shadow:0 16px 60px rgba(0,0,0,.6)}
.board h2{margin:0 0 10px;font-size:clamp(34px,6vw,54px);line-height:1.1;font-weight:800}
.board .sub{margin:0;font-size:19px;color:#d4e0da}
.chalk{margin-top:30px;min-height:78px;padding:0 48px;border:0;border-radius:16px;background:#ffd966;color:#17201e;font-size:28px;font-weight:800}
.chalk:focus-visible{outline-color:#fff}
.count{margin:22px 0 0;font-size:18px;color:#c3d3cc}
.away .count{color:#ffd966;font-weight:700}
@media (prefers-reduced-motion:no-preference){.chalk{animation:nudge 1.8s ease-in-out infinite}}
@keyframes nudge{50%{box-shadow:0 0 0 12px rgba(255,217,102,.28)}}
`;

function chime() {
  try {
    const ctx = new (globalThis.AudioContext || globalThis.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    const t = ctx.currentTime;
    o.type = 'sine';
    o.frequency.setValueAtTime(784, t);
    o.frequency.setValueAtTime(1047, t + 0.16);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
    o.connect(g).connect(ctx.destination);
    o.start(t);
    o.stop(t + 0.6);
    o.onended = () => ctx.close();
  } catch { /* autoplay blocked or no audio: the visual prompt is enough */ }
}

export function createUI(cb) {
  const host = document.createElement('div');
  host.id = 'mcc-host';
  host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
  const root = host.attachShadow({ mode: 'closed' });
  try {
    const sheet = new CSSStyleSheet();     // constructable stylesheet: not subject to the page's CSP
    sheet.replaceSync(CSS);
    root.adoptedStyleSheets = [sheet];
  } catch {
    root.append(h('style', {}, CSS));
  }
  const layer = h('div', { class: 'layer' });
  root.append(layer);

  const slots = { pill: null, pop: null, consent: null, idle: null };
  let indicatorMode = null;
  let idleTimer = null;
  let savedFocus = null;

  const ensureAttached = () => { if (!host.isConnected) document.documentElement.append(host); };
  const unmount = (name) => { slots[name]?.remove(); slots[name] = null; };
  const mount = (name, el) => { unmount(name); slots[name] = el; layer.append(el); ensureAttached(); };

  function trapTab(e, container) {
    if (e.key !== 'Tab') return;
    const f = [...container.querySelectorAll('button:not([disabled]), input')];
    if (!f.length) return;
    const first = f[0];
    const last = f[f.length - 1];
    if (e.shiftKey && root.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && root.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  // Keep typing inside our dialogs from triggering Meet's keyboard shortcuts.
  const isolateKeys = (el) => ['keydown', 'keyup', 'keypress'].forEach((t) => el.addEventListener(t, (e) => e.stopPropagation()));

  // ---------- "Your class": link a class code so the professor's report arrives automatically ----------
  function classSection({ classInfo, syncAvailable, onLink, onUnlink, getIdent }) {
    if (!syncAvailable) return null;
    const msg = h('p', { class: 'err', role: 'status' });
    if (classInfo) {
      return h('div', { class: 'classbox' },
        h('div', {}, h('strong', {}, classInfo.className || 'Your class'), classInfo.professorName ? ` with ${classInfo.professorName}` : ''),
        h('button', { class: 'link', type: 'button', onclick: async () => { const p = await onUnlink(getIdent()); if (p) msg.textContent = p; } }, 'Change class'), msg);
    }
    const code = h('input', { type: 'text', id: 'mcc-code', maxlength: '14', placeholder: 'Class code, e.g. K7M2QX9P', autocomplete: 'off', autocapitalize: 'characters' });
    const btn = h('button', {
      class: 'btn', type: 'button',
      onclick: async () => { msg.textContent = ''; btn.disabled = true; const p = await onLink(code.value, getIdent()); btn.disabled = false; if (p) msg.textContent = p; },
    }, 'Link class');
    return h('div', { class: 'classbox' },
      h('label', { for: 'mcc-code' }, 'Class code from your professor (optional)'), code, btn, msg,
      h('p', { class: 'foot' }, 'With a code, your professor receives the report automatically after class. Without one, nothing is uploaded and you can hand in a file yourself.'));
  }

  // ---------- corner badge + profile popover (available in every consent state, inside a meeting) ----------
  const MODE_LABEL = { active: 'Attention log on', off: 'Attention log off', undecided: 'Attention log: not set' };
  const MODE_TEXT = {
    active: 'On. Your professor receives focus and idle timestamps only. Never your notes, screenshots or keystrokes.',
    off: 'Off. Nothing is tracked. Your notes and screenshots still work.',
    undecided: 'Not set. Nothing is logged until you choose.',
  };
  function closePop() { unmount('pop'); }

  function popover(mode) {
    const id = cb.getIdentity();
    const name = h('input', { type: 'text', id: 'mcc-pname', autocomplete: 'name', maxlength: '80', value: id.displayName, placeholder: 'Full name' });
    const num = h('input', { type: 'text', id: 'mcc-pnum', maxlength: '40', value: id.studentNumber, placeholder: 'Student number' });
    const note = h('p', { class: 'err', role: 'status' });
    const save = h('button', {
      class: 'btn', type: 'button',
      onclick: async () => {
        note.className = 'err'; note.textContent = ''; save.disabled = true;
        const problem = await cb.onSaveProfile({ displayName: name.value, studentNumber: num.value });
        save.disabled = false;
        if (problem) note.textContent = problem;
        else { note.className = 'ok'; note.textContent = mode === 'active' ? 'Saved. Applies from your next class.' : 'Saved.'; }
      },
    }, 'Save details');

    const confirm = h('div', { hidden: true },
      h('p', {}, 'Stop now? Logging ends immediately and your record gets one line: "No tracking record. Student declined tracking."'),
      h('div', { class: 'row' },
        h('button', { class: 'btn solid', type: 'button', onclick: () => { closePop(); cb.onRevoke(); } }, 'Yes, stop logging'),
        h('button', { class: 'btn', type: 'button', onclick: () => { confirm.hidden = true; main.hidden = false; } }, 'Keep it on')));

    const toggle = mode === 'active'
      ? h('button', { class: 'btn', type: 'button', onclick: () => { main.hidden = true; confirm.hidden = false; } }, 'Stop sharing my log')
      : h('button', { class: 'btn solid', type: 'button', onclick: () => { closePop(); cb.onReopenConsent(); } }, 'Turn on the attention log');

    const main = h('div', {},
      h('p', { class: 'pop-status' }, MODE_TEXT[mode]),
      h('h3', {}, 'Your details'),
      h('div', { class: 'fields one' },
        h('label', { for: 'mcc-pname' }, 'Name', name),
        h('label', { for: 'mcc-pnum' }, 'Student number', num)),
      note,
      h('div', { class: 'row' }, save, h('button', { class: 'btn', type: 'button', onclick: () => { cb.onOpenPanel(); closePop(); } }, 'Open notes and my log')),
      h('h3', {}, 'Your class'),
      classSection({ classInfo: cb.getClass().classInfo, syncAvailable: cb.getClass().syncAvailable, onLink: cb.onLinkClass, onUnlink: cb.onUnlinkClass, getIdent: () => ({ displayName: name.value, studentNumber: num.value }) }) ?? h('p', { class: 'foot' }, 'Class upload is not set up in this copy of the extension. You can hand in a file instead.'),
      h('div', { class: 'row sep' }, toggle));
    const pop = h('div', { class: 'pop', role: 'dialog', 'aria-label': 'Attention log and your details' },
      h('h2', { class: 'pop-title' }, 'Attention log'), main, confirm);
    isolateKeys(pop);
    pop.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePop(); });
    return pop;
  }

  function showIndicator(mode) {
    if (indicatorMode === mode && slots.pill) return;
    indicatorMode = mode;
    closePop();
    mount('pill', h('button', {
      class: 'pill', type: 'button', 'aria-haspopup': 'dialog', title: 'Attention log settings and your details',
      onclick: () => (slots.pop ? closePop() : mount('pop', popover(indicatorMode))),
    }, h('span', { class: 'dot ' + mode, 'aria-hidden': 'true' }), MODE_LABEL[mode]));
  }
  function hideIndicator() { indicatorMode = null; closePop(); unmount('pill'); }

  // ---------- consent dialog ----------
  function showConsent({ config, identity, classInfo, syncAvailable, onLinkClass, onUnlinkClass, onAccept, onDecline, onLater }) {
    if (slots.consent) return;
    const t = buildConsentText(config, classInfo);
    const name = h('input', { type: 'text', id: 'mcc-name', autocomplete: 'name', maxlength: '80', placeholder: 'Full name', value: identity?.displayName ?? '' });
    const num = h('input', { type: 'text', id: 'mcc-num', maxlength: '40', placeholder: 'Student number', value: identity?.studentNumber ?? '' });
    const err = h('p', { class: 'err', role: 'alert' });
    const ident = () => ({ displayName: name.value, studentNumber: num.value });
    const accept = h('button', {
      class: 'btn solid', type: 'button',
      onclick: async () => {
        err.textContent = '';
        accept.disabled = true;
        const problem = await onAccept(ident());
        accept.disabled = false;
        if (problem) err.textContent = problem;
      },
    }, 'Turn on the attention log');
    const no = h('button', { class: 'btn', type: 'button', onclick: () => onDecline(ident()) }, 'No thanks, do not track me');
    const later = h('button', { class: 'link', type: 'button', onclick: () => onLater() }, 'Decide later. Nothing is logged until you choose.');

    const paper = h('div', { class: 'paper', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'mcc-ct' },
      h('h2', { id: 'mcc-ct' }, t.title),
      h('p', {}, t.intro),
      classSection({ classInfo, syncAvailable, onLink: onLinkClass, onUnlink: onUnlinkClass, getIdent: ident }),
      t.sections.map((s) => h('section', {}, h('h3', {}, s.heading), h('ul', {}, s.items.map((i) => h('li', {}, i))))),
      h('div', { class: 'fields' },
        h('label', { for: 'mcc-name' }, 'Your name', name),
        h('label', { for: 'mcc-num' }, 'Student number', num)),
      err,
      h('div', { class: 'actions' }, accept, no),
      h('p', { class: 'foot' }, t.footer),
      later);
    isolateKeys(paper);
    paper.addEventListener('keydown', (e) => { if (e.key === 'Escape') onLater(); trapTab(e, paper); });
    const scrim = h('div', { class: 'scrim' }, paper);
    mount('consent', scrim);
    savedFocus = document.activeElement;
    (name.value ? num : name).focus();
  }
  function hideConsent() { unmount('consent'); try { savedFocus?.focus?.(); } catch { /* page element gone */ } }
  const isConsentOpen = () => !!slots.consent;

  // ---------- "Are you still there?" ----------
  function showIdlePrompt({ shownTs, windowMs, sound, onRespond }) {
    hideIdlePrompt();
    savedFocus = document.activeElement;
    const count = h('p', { class: 'count' });
    const btn = h('button', { class: 'chalk', type: 'button', onclick: () => onRespond() }, "Yes, I'm here");
    const board = h('div', { class: 'board', role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': 'mcc-it', 'aria-describedby': 'mcc-id' },
      h('h2', { id: 'mcc-it' }, 'Are you still there?'),
      h('p', { id: 'mcc-id', class: 'sub' }, 'Click the button so your class record shows you are present.'),
      btn, count);
    const scrim = h('div', { class: 'scrim' }, board);
    isolateKeys(scrim);
    scrim.addEventListener('keydown', (e) => { if (e.key === 'Tab') { e.preventDefault(); btn.focus(); } });
    const update = () => {
      const left = Math.ceil((windowMs - (Date.now() - shownTs)) / 1000);
      if (left > 0) count.textContent = `Please answer within ${left} s.`;
      else { count.textContent = 'No answer yet, so you are marked as away. Click to confirm you are back.'; board.classList.add('away'); }
    };
    update();
    idleTimer = setInterval(update, 250);
    mount('idle', scrim);
    btn.focus();
    if (sound) chime();
  }
  function hideIdlePrompt() {
    clearInterval(idleTimer);
    idleTimer = null;
    if (!slots.idle) return;
    unmount('idle');
    try { savedFocus?.focus?.(); } catch { /* page element gone */ }
  }

  function destroy() { clearInterval(idleTimer); host.remove(); }

  return { ensureAttached, showIndicator, hideIndicator, showConsent, hideConsent, isConsentOpen, showIdlePrompt, hideIdlePrompt, destroy };
}
