// In-memory LogRepository: used by unit tests, and a reference for other implementations (e.g. Firestore).
export function createMemoryRepo() {
  const sessions = new Map();
  const events = [];
  const copy = (x) => (x === undefined ? undefined : structuredClone(x));
  return {
    async getSession(id) { return copy(sessions.get(id)); },
    async putSession(rec) { sessions.set(rec.sessionId, copy(rec)); },
    async openSessions() { return [...sessions.values()].filter((s) => s.status === 'open').map(copy); },
    async sessionsForMeetDate(key) { return [...sessions.values()].filter((s) => s.meetDate === key).map(copy); },
    async listSessions() { return [...sessions.values()].map(copy).sort((a, b) => (b.startTs ?? 0) - (a.startTs ?? 0)); },
    async appendEvent(evt) {
      events.push(copy(evt));
      const s = sessions.get(evt.sessionId);
      if (s) s.head = { seq: evt.seq, hash: evt.hash };
    },
    async getEvents(sessionId) { return events.filter((e) => e.sessionId === sessionId).sort((a, b) => a.seq - b.seq).map(copy); },
  };
}
