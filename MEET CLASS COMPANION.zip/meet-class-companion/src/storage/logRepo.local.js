// LogRepository implementation backed by IndexedDB (database "attendance-log").
// Notes and screenshots live in a DIFFERENT database ("study-notes") on purpose: nothing that can be
// exported to the professor can reach them. A Firestore implementation later only needs this same interface:
//   getSession(id) putSession(rec) openSessions() sessionsForMeetDate(key) listSessions()
//   appendEvent(evt) getEvents(sessionId)
// NOTE: only call this from the service worker or extension pages. A content script's IndexedDB is the page's.

const DB_NAME = 'attendance-log';
const DB_VERSION = 1;
let dbPromise = null;

function db() {
  dbPromise ??= new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const d = r.result;
      const ev = d.createObjectStore('events', { keyPath: 'eventId' });
      ev.createIndex('bySession', ['sessionId', 'seq'], { unique: true });
      const se = d.createObjectStore('sessions', { keyPath: 'sessionId' });
      se.createIndex('byStatus', 'status');
      se.createIndex('byMeetDate', 'meetDate');
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  return dbPromise;
}

const wrap = (req) => new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });
const done = (tx) => new Promise((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); });

export const logRepo = {
  async getSession(id) {
    const d = await db();
    return wrap(d.transaction('sessions').objectStore('sessions').get(id));
  },
  async putSession(rec) {
    const d = await db();
    const tx = d.transaction('sessions', 'readwrite');
    tx.objectStore('sessions').put(rec);
    return done(tx);
  },
  async openSessions() {
    const d = await db();
    return wrap(d.transaction('sessions').objectStore('sessions').index('byStatus').getAll('open'));
  },
  async sessionsForMeetDate(key) {
    const d = await db();
    return wrap(d.transaction('sessions').objectStore('sessions').index('byMeetDate').getAll(key));
  },
  async listSessions() {
    const d = await db();
    const all = await wrap(d.transaction('sessions').objectStore('sessions').getAll());
    return all.sort((a, b) => (b.startTs ?? 0) - (a.startTs ?? 0));
  },
  /** Adds the event and advances the session's chain head in ONE transaction. */
  async appendEvent(evt) {
    const d = await db();
    const tx = d.transaction(['events', 'sessions'], 'readwrite');
    tx.objectStore('events').add(evt);
    const sessions = tx.objectStore('sessions');
    const get = sessions.get(evt.sessionId);
    get.onsuccess = () => {
      const rec = get.result;
      if (rec) { rec.head = { seq: evt.seq, hash: evt.hash }; sessions.put(rec); }
    };
    return done(tx);
  },
  async getEvents(sessionId) {
    const d = await db();
    const range = IDBKeyRange.bound([sessionId, 0], [sessionId, Number.MAX_SAFE_INTEGER]);
    return wrap(d.transaction('events').objectStore('events').index('bySession').getAll(range));
  },
};
