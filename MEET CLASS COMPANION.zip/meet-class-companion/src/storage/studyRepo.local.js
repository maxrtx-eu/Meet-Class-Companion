// Student-private study material: notes + screenshots. A separate IndexedDB from the attendance log ("attendance-log"),
// and nothing that exports to the professor imports this file.
// A note is one per meeting per day, keyed "meetCode|YYYY-MM-DD". It exists whether or not the student consented to tracking.
const DB_NAME = 'study-notes';
const DB_VERSION = 1;
let dbPromise = null;

function db() {
  dbPromise ??= new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const d = r.result;
      d.createObjectStore('notes', { keyPath: 'key' });
      d.createObjectStore('shots', { keyPath: 'id' }).createIndex('byNote', 'noteKey');
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  return dbPromise;
}
const wrap = (req) => new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });
const done = (tx) => new Promise((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); });

export const studyRepo = {
  async getNote(key) { return wrap((await db()).transaction('notes').objectStore('notes').get(key)); },
  async putNote(rec) { const tx = (await db()).transaction('notes', 'readwrite'); tx.objectStore('notes').put(rec); return done(tx); },
  async listNotes() {
    const all = await wrap((await db()).transaction('notes').objectStore('notes').getAll());
    return all.sort((a, b) => b.updatedAt - a.updatedAt);
  },
  async putShot(shot) { const tx = (await db()).transaction('shots', 'readwrite'); tx.objectStore('shots').put(shot); return done(tx); },
  async getShot(id) { return wrap((await db()).transaction('shots').objectStore('shots').get(id)); },
  /** Deletes the note and every screenshot stored for it. */
  async deleteNote(key) {
    const d = await db();
    const tx = d.transaction(['notes', 'shots'], 'readwrite');
    tx.objectStore('notes').delete(key);
    const shots = tx.objectStore('shots');
    const cur = shots.index('byNote').openKeyCursor(IDBKeyRange.only(key));
    cur.onsuccess = () => { const c = cur.result; if (c) { shots.delete(c.primaryKey); c.continue(); } };
    return done(tx);
  },
};
