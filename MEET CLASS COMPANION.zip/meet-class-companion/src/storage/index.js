// The one place that decides which LogRepository the extension uses.
// Swap in a Firestore-backed repo later by calling setLogRepo() (or changing the default below).
import { logRepo as localRepo } from './logRepo.local.js';

export let logRepo = localRepo;
export function setLogRepo(repo) { logRepo = repo; }   // test seam + future server-backed repo
