// The Notes tab: per-class Markdown notes, optional timestamps, slide capture with crop review, export.
// Notes are saved only in the student's "study-notes" database. The professor-facing log only ever learns
// that note-taking happened (a heartbeat with no content) and that a screenshot was saved (no image).
import { h } from '../shared/dom.js';
import { MSG } from '../shared/messages.js';
import { parseMeetCode, localDate, localTime, newId } from '../shared/schema.js';
import { shotIds } from '../shared/mdcore.js';
import { studyRepo } from '../storage/studyRepo.local.js';
import { renderMarkdown } from './markdown.js';
import { captureSlide, canvasToBlob } from './capture.js';
import { reviewCrop } from './cropper.js';
import { getTargetTab } from './target.js';
import { buildMarkdown, openPrintView } from './exportNotes.js';
import { download, safeName } from '../export/download.js';

const stamp = () => `[${localTime(Date.now()).slice(0, 5)}] `;

export function createNotesView(pane, { getState, send }) {
  let note = null;          // stored record for the open note (null until the first keystroke)
  let key = null;           // "meetCode|date"
  let meta = null;          // { meetCode, date } for the open note
  let previewing = false;
  let saveTimer = null;
  let lastStamp = 0;
  let lastBeat = 0;
  let busy = false;
  let confirmingDelete = false;
  let lastSig = '';
  const urls = new Map();   // screenshot id -> object URL (preview only)
  const prefs = { autoStamp: false };

  const ta = h('textarea', { class: 'note-text', 'aria-label': 'Notes', placeholder: 'Type your notes here. They are private: your professor never sees them.' });
  const preview = h('div', { class: 'note-preview', hidden: true });
  const status = h('p', { class: 'meta', role: 'status' });
  const select = h('select', { 'aria-label': 'Choose which notes to open', onchange: () => openKey(select.value) });
  const autoStamp = h('input', { type: 'checkbox', id: 'auto-stamp', onchange: () => { prefs.autoStamp = autoStamp.checked; chrome.storage.local.set({ notePrefs: prefs }); } });
  const previewBtn = h('button', { class: 'tool', type: 'button', 'aria-pressed': 'false', onclick: () => togglePreview() }, 'Preview');
  const captureBtn = h('button', { class: 'btn solid', type: 'button', onclick: () => capture() }, 'Capture slide');
  const actions = h('div', { class: 'row' });

  const say = (text, isError = false) => { status.textContent = text; status.className = isError ? 'meta err' : 'meta'; };

  // ----- note lifecycle -----
  async function meetingKey() {
    const tab = await getTargetTab();
    const code = tab?.url ? parseMeetCode(tab.url) : null;
    return code ? { key: `${code}|${localDate(Date.now())}`, meetCode: code, date: localDate(Date.now()) } : null;
  }

  async function openKey(k) {
    await flush();
    key = k;
    note = await studyRepo.getNote(k);
    const [meetCode, date] = k.split('|');
    meta = { meetCode, date };
    ta.value = note?.text ?? '';
    confirmingDelete = false;
    if (previewing) await renderPreview();
    await refreshSelect();
    drawActions();
    say(note ? `Saved ${localTime(note.updatedAt)}` : 'New notes. They are saved as you type.');
  }

  async function refreshContext() {
    const cur = await meetingKey();
    if (!key) {
      const first = cur?.key ?? (await studyRepo.listNotes())[0]?.key;
      if (first) await openKey(first); else await refreshSelect();
      return;
    }
    await refreshSelect();
  }

  async function refreshSelect() {
    const notes = await studyRepo.listNotes();
    const cur = await meetingKey();
    const opts = [];
    if (cur && !notes.some((n) => n.key === cur.key)) opts.push({ key: cur.key, label: `Today: ${cur.meetCode} (new)` });
    for (const n of notes) opts.push({ key: n.key, label: `${n.date}: ${n.meetCode}` });
    if (key && !opts.some((o) => o.key === key)) opts.unshift({ key, label: key.replace('|', ': ') });
    const sig = JSON.stringify([key, opts]);
    if (sig !== lastSig) {              // avoid collapsing an open dropdown on every refresh
      lastSig = sig;
      select.replaceChildren(...opts.map((o) => h('option', { value: o.key, selected: o.key === key }, o.label)));
    }
    select.disabled = opts.length === 0;
    ta.disabled = !key;                 // nothing to save into until a class is open
    if (!key) say('Open a Meet class to start notes for it.');
  }

  async function save() {
    if (!key) return;
    const now = Date.now();
    note ??= { key, meetCode: meta.meetCode, date: meta.date, createdAt: now, text: '' };
    note.text = ta.value;
    note.updatedAt = now;
    await studyRepo.putNote(note);
    say(`Saved ${localTime(now)}`);
  }
  async function flush() { if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; await save(); } }
  const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => { saveTimer = null; save(); }, 700); };

  // ----- editing helpers -----
  function fireInput() { ta.dispatchEvent(new Event('input', { bubbles: true })); }
  function insert(text) {
    ta.focus();
    ta.setRangeText(text, ta.selectionStart, ta.selectionEnd, 'end');
    fireInput();
  }
  function wrap(mark) {
    ta.focus();
    const { selectionStart: s, selectionEnd: e } = ta;
    const chosen = ta.value.slice(s, e) || 'text';
    ta.setRangeText(`${mark}${chosen}${mark}`, s, e, 'select');
    fireInput();
  }
  function linePrefix(prefix) {
    ta.focus();
    const start = ta.value.lastIndexOf('\n', ta.selectionStart - 1) + 1;
    ta.setRangeText(prefix, start, start, 'preserve');
    fireInput();
  }

  ta.addEventListener('input', () => { if (key) scheduleSave(); });
  ta.addEventListener('keydown', (e) => {
    // Read only for these two editor shortcuts; keys are never stored or sent anywhere.
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && prefs.autoStamp && Date.now() - lastStamp > 60_000 && ta.selectionStart === ta.selectionEnd) {
      e.preventDefault();
      insert(`\n${stamp()}`);
      lastStamp = Date.now();
    } else if ((e.ctrlKey || e.metaKey) && e.key === ';') {
      e.preventDefault();
      insert(stamp());
      lastStamp = Date.now();
    }
  });

  // "Typing happened" heartbeat for the idle logic. Throttled; carries no content. Only while the log is on.
  const beat = () => {
    const s = getState();
    if (!s || s.consentStatus !== 'GRANTED' || !s.monitoring) return;
    const t = Date.now();
    if (t - lastBeat < 5000) return;
    lastBeat = t;
    send({ type: MSG.NOTE_HEARTBEAT });
  };
  for (const ev of ['input', 'keydown', 'pointerdown', 'wheel']) pane.addEventListener(ev, beat, { capture: true, passive: true });
  window.addEventListener('pagehide', () => { flush(); });

  // ----- preview -----
  async function renderPreview() {
    for (const id of new Set(shotIds(ta.value))) {
      if (urls.has(id)) continue;
      const s = await studyRepo.getShot(id);
      if (s) urls.set(id, URL.createObjectURL(s.blob));
    }
    preview.replaceChildren(ta.value.trim() ? renderMarkdown(ta.value, (id) => urls.get(id)) : h('p', { class: 'meta' }, 'Nothing to preview yet.'));
  }
  async function togglePreview() {
    previewing = !previewing;
    if (previewing) await renderPreview();
    preview.hidden = !previewing;
    ta.hidden = previewing;
    previewBtn.setAttribute('aria-pressed', String(previewing));
    previewBtn.textContent = previewing ? 'Edit' : 'Preview';
  }

  // ----- capture -----
  async function capture() {
    if (busy) return;
    busy = true;
    captureBtn.disabled = true;
    try {
      if (!key) { const cur = await meetingKey(); if (!cur) { say('Switch to your Meet tab first, then capture.', true); return; } await openKey(cur.key); }
      if (previewing) await togglePreview();
      say('Capturing...');
      const res = await captureSlide();
      if (!res.ok) { say(res.message, true); return; }                // failure: friendly message, nothing saved, nothing logged
      const canvas = await reviewCrop(res.img);
      if (!canvas) { say('Capture cancelled. Nothing was saved.'); return; }
      const blob = await canvasToBlob(canvas);
      const id = newId();
      await studyRepo.putShot({ id, noteKey: key, ts: Date.now(), blob, w: canvas.width, h: canvas.height, mime: blob.type });
      ta.focus();
      const end = ta.value.length;
      ta.setSelectionRange(end, end);
      insert(`${end && !ta.value.endsWith('\n') ? '\n' : ''}![Slide ${localTime(Date.now()).slice(0, 5)}](shot:${id})\n`);
      await flush();
      send({ type: MSG.SCREENSHOT_SAVED });                            // only after a successful save; the log learns THAT, never WHAT
      say('Screenshot added to your notes.');
    } catch {
      say('The screenshot could not be saved. Nothing was added.', true);
    } finally {
      busy = false;
      setTimeout(() => { captureBtn.disabled = false; }, 600);        // captureVisibleTab is rate limited (2 per second)
    }
  }

  // ----- export / delete -----
  async function exportMd() {
    await flush();
    if (!note?.text.trim()) { say('Nothing to export yet.', true); return; }
    download(`notes-${safeName(note.meetCode)}-${note.date}.md`, await buildMarkdown(note));
    say('Markdown file downloaded.');
  }
  async function exportPdf() {
    await flush();
    if (!note?.text.trim()) { say('Nothing to export yet.', true); return; }
    openPrintView(key);
  }
  async function removeNote() {
    await studyRepo.deleteNote(key);
    for (const u of urls.values()) URL.revokeObjectURL(u);
    urls.clear();
    note = null; ta.value = ''; confirmingDelete = false;
    say('Notes deleted.');
    await refreshSelect();
    drawActions();
  }

  function drawActions() {
    actions.replaceChildren(...(confirmingDelete
      ? [h('span', { class: 'meta' }, 'Delete these notes and their screenshots for good?'),
        h('button', { class: 'btn solid', type: 'button', onclick: removeNote }, 'Yes, delete'),
        h('button', { class: 'btn', type: 'button', onclick: () => { confirmingDelete = false; drawActions(); } }, 'Keep')]
      : [captureBtn,
        h('button', { class: 'btn', type: 'button', onclick: exportMd }, 'Export Markdown'),
        h('button', { class: 'btn', type: 'button', onclick: exportPdf }, 'Save as PDF'),
        h('button', { class: 'link', type: 'button', disabled: !note, onclick: () => { confirmingDelete = true; drawActions(); } }, 'Delete these notes')]));
  }

  pane.replaceChildren(
    h('p', { class: 'privacy-note' }, 'Private to you. Your professor never sees notes or screenshots.'),
    h('div', { class: 'row tight' }, select),
    h('div', { class: 'toolbar', role: 'toolbar', 'aria-label': 'Formatting' },
      h('button', { class: 'tool', type: 'button', title: 'Bold', onclick: () => wrap('**') }, 'B'),
      h('button', { class: 'tool', type: 'button', title: 'Italic', onclick: () => wrap('*') }, 'I'),
      h('button', { class: 'tool', type: 'button', title: 'Heading', onclick: () => linePrefix('## ') }, 'H'),
      h('button', { class: 'tool', type: 'button', title: 'Bullet', onclick: () => linePrefix('- ') }, 'List'),
      h('button', { class: 'tool', type: 'button', title: 'Insert the time (Ctrl+;)', onclick: () => { insert(stamp()); lastStamp = Date.now(); } }, 'Time'),
      previewBtn),
    h('label', { class: 'check', for: 'auto-stamp' }, autoStamp, 'Add the time to new paragraphs automatically'),
    ta, preview, status, actions);
  chrome.storage.local.get('notePrefs').then(({ notePrefs }) => { prefs.autoStamp = !!notePrefs?.autoStamp; autoStamp.checked = prefs.autoStamp; });
  drawActions();

  return { refreshContext, flush };
}
