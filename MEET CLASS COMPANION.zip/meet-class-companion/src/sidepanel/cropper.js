// Crop-review step: the student always sees the capture before anything is saved.
// Drag to choose the area, or keep the whole capture, or cancel (nothing is stored, nothing is logged).
import { h } from '../shared/dom.js';

const MAX_W = 1600;   // stored width cap; keeps blobs small

/** @returns {Promise<HTMLCanvasElement|null>} cropped canvas, or null if cancelled */
export function reviewCrop(img) {
  return new Promise((resolve) => {
    const W = img.naturalWidth;
    const H = img.naturalHeight;
    const scale = Math.min(1, Math.min(document.body.clientWidth - 56, 640) / W);
    const cw = Math.max(1, Math.round(W * scale));
    const ch = Math.max(1, Math.round(H * scale));
    const canvas = h('canvas', { width: cw, height: ch, class: 'crop-canvas', 'aria-label': 'Screenshot preview. Drag to choose the area to keep.' });
    const ctx = canvas.getContext('2d');
    let sel = null;
    let start = null;

    const draw = () => {
      ctx.clearRect(0, 0, cw, ch);
      ctx.drawImage(img, 0, 0, cw, ch);
      if (!sel) return;
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillRect(0, 0, cw, ch);
      ctx.drawImage(img, sel.x / scale, sel.y / scale, sel.w / scale, sel.h / scale, sel.x, sel.y, sel.w, sel.h);
      ctx.strokeStyle = '#ffd966';
      ctx.lineWidth = 2;
      ctx.strokeRect(sel.x + 1, sel.y + 1, Math.max(0, sel.w - 2), Math.max(0, sel.h - 2));
    };
    const pos = (e) => {
      const r = canvas.getBoundingClientRect();
      return { x: Math.min(cw, Math.max(0, ((e.clientX - r.left) * cw) / r.width)), y: Math.min(ch, Math.max(0, ((e.clientY - r.top) * ch) / r.height)) };
    };
    canvas.addEventListener('pointerdown', (e) => { canvas.setPointerCapture(e.pointerId); start = pos(e); sel = null; useSel.disabled = true; });
    canvas.addEventListener('pointermove', (e) => {
      if (!start) return;
      const p = pos(e);
      sel = { x: Math.min(start.x, p.x), y: Math.min(start.y, p.y), w: Math.abs(p.x - start.x), h: Math.abs(p.y - start.y) };
      draw();
    });
    canvas.addEventListener('pointerup', () => {
      start = null;
      if (sel && (sel.w < 20 || sel.h < 20)) sel = null;
      useSel.disabled = !sel;
      draw();
    });

    const finish = (mode) => {
      overlay.remove();
      if (mode === 'cancel') return resolve(null);
      const r = mode === 'sel' && sel ? { x: sel.x / scale, y: sel.y / scale, w: sel.w / scale, h: sel.h / scale } : { x: 0, y: 0, w: W, h: H };
      const k = Math.min(1, MAX_W / r.w);
      const out = document.createElement('canvas');
      out.width = Math.max(1, Math.round(r.w * k));
      out.height = Math.max(1, Math.round(r.h * k));
      out.getContext('2d').drawImage(img, r.x, r.y, r.w, r.h, 0, 0, out.width, out.height);
      return resolve(out);
    };

    const useSel = h('button', { class: 'btn solid', type: 'button', disabled: true, onclick: () => finish('sel') }, 'Keep selected area');
    const overlay = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'crop-title' },
      h('div', { class: 'modal-card' },
        h('h2', { id: 'crop-title' }, 'Review your screenshot'),
        h('p', { class: 'meta' }, 'Drag on the picture to keep only the slide, or keep everything. Nothing is saved until you choose.'),
        canvas,
        h('div', { class: 'row' },
          useSel,
          h('button', { class: 'btn', type: 'button', onclick: () => finish('full') }, 'Keep whole capture'),
          h('button', { class: 'btn', type: 'button', onclick: () => finish('cancel') }, 'Cancel'))));
    overlay.addEventListener('keydown', (e) => { if (e.key === 'Escape') finish('cancel'); });
    document.body.append(overlay);
    draw();
    overlay.querySelector('button:nth-of-type(2)').focus();
  });
}
