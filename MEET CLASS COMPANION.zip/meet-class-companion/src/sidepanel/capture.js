// Slide capture. Only ever runs from an explicit button press, only for the Meet tab the student is looking at.
// Host permission is limited to meet.google.com, so Chrome itself refuses to capture any other site.
import { parseMeetCode } from './../shared/schema.js';
import { getTargetTab } from './target.js';

export function friendlyCaptureError(e) {
  const m = String(e?.message ?? e).toLowerCase();
  if (m.includes('permission') || m.includes('cannot access') || m.includes('activetab')) {
    return 'Chrome did not allow the capture on this page. Make sure the Meet tab is the one you are looking at, then try again.';
  }
  if (m.includes('minimized') || m.includes('not visible') || m.includes('no window') || m.includes('no tab')) {
    return 'Chrome cannot capture while the window is minimized or hidden. Bring the Meet window to the front and try again.';
  }
  if (m.includes('quota') || m.includes('rate') || m.includes('per second')) return 'That was too fast. Wait a second and try again.';
  return 'The screenshot could not be taken. Nothing was saved. Try again in a moment.';
}

/** Pure: max minus min brightness over RGBA pixels. A near-zero spread means a blank (black/white) capture. */
export function luminanceSpread(rgba) {
  let lo = 255;
  let hi = 0;
  for (let i = 0; i < rgba.length; i += 4) {
    const l = (rgba[i] * 3 + rgba[i + 1] * 6 + rgba[i + 2]) / 10;
    if (l < lo) lo = l;
    if (l > hi) hi = l;
  }
  return hi - lo;
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('decode failed'));
    img.src = src;
  });
}

/** @returns {Promise<{ok:true,img:HTMLImageElement}|{ok:false,message:string}>} Never throws; on failure nothing is stored or logged. */
export async function captureSlide() {
  const tab = await getTargetTab();
  if (!tab?.url || !parseMeetCode(tab.url) || !tab.active) return { ok: false, message: 'Switch to your Meet tab first, then capture.' };

  let dataUrl;
  try { dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }); }
  catch (e) { return { ok: false, message: friendlyCaptureError(e) }; }
  if (!dataUrl) return { ok: false, message: friendlyCaptureError(null) };

  let img;
  try { img = await loadImage(dataUrl); } catch { return { ok: false, message: friendlyCaptureError(null) }; }

  const c = document.createElement('canvas');
  c.width = 48; c.height = 27;
  const x = c.getContext('2d', { willReadFrequently: true });
  x.drawImage(img, 0, 0, 48, 27);
  if (luminanceSpread(x.getImageData(0, 0, 48, 27).data) < 4) {
    return { ok: false, message: 'The capture came back blank. Some systems block capturing video. Try again, or type your notes instead.' };
  }
  return { ok: true, img };
}

export function canvasToBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((webp) => {
      if (webp && webp.type === 'image/webp') return resolve(webp);
      canvas.toBlob((jpg) => (jpg ? resolve(jpg) : reject(new Error('encode failed'))), 'image/jpeg', 0.85);
    }, 'image/webp', 0.85);
  });
}
