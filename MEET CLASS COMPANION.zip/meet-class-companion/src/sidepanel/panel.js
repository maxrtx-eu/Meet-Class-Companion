// Side panel: Notes (private) | My log (exactly what the professor's file contains + export) | Privacy and your details.
import { h } from '../shared/dom.js';
import { MSG } from '../shared/messages.js';
import { describeEvent, localTime, EventType } from '../shared/schema.js';
import { buildConsentText } from '../shared/consentText.js';
import { summarizeSession } from '../shared/timeline.js';
import { timelineBar, summaryTable, promptLine } from '../shared/timelineView.js';
import { verifyChain } from '../shared/hash.js';
import { eventsCsv, summaryCsv } from '../export/csv.js';
import { buildHandIn, handInFilename } from '../export/handIn.js';
import { download, safeName } from '../export/download.js';
import { createNotesView } from './notesView.js';
import { getTargetTab } from './target.js';

const $ = (sel) => document.querySelector(sel);
const send = (m) => chrome.runtime.sendMessage(m).catch(() => null);

let tabId = null;
let state = null;
let confirmingStop = false;
let lastPrivacyKey = '';
let selectedId = null;       // session shown in My log
let followLive = true;       // follow the current class until the student picks another
let currentLog = null;       // { session, events, summary } behind the export buttons
const notes = createNotesView($('#pane-notes'), { getState: () => state, send });

function statusText(s) {
  if (s.consentStatus === 'GRANTED') return s.monitoredHere ? 'Attention log is on for this class.' : 'Attention log is on. It records while you are in a class.';
  if (s.consentStatus === 'DECLINED') return 'Attention log is off. Nothing is tracked.';
  return 'Not set yet. Nothing is logged until you choose.';
}
const PAGE_TEXT = { in_call: 'Meet page: in a call', lobby: 'Meet page: waiting room or call ended', none: 'Meet page: not a meeting' };

// ---------- My log ----------
async function renderLog() {
  const pane = $('#pane-log');
  if (pane.contains(document.activeElement) && document.activeElement.tagName === 'SELECT') return;   // do not collapse an open dropdown
  const list = (await send({ type: MSG.LIST_SESSIONS }))?.sessions ?? [];
  if (!list.length) {
    pane.replaceChildren(h('p', { class: 'empty' }, 'Nothing logged yet. When the attention log is on, every event appears here exactly as your professor will see it.'));
    currentLog = null;
    return;
  }
  if (followLive || !list.some((s) => s.sessionId === selectedId)) selectedId = state?.sessionId ?? list[0].sessionId;
  const res = await send({ type: MSG.GET_MY_LOG, sessionId: selectedId });
  if (!res?.session) return;
  const { session, events } = res;
  const { summary, segments, bounds } = summarizeSession(session, events, { now: Date.now() });
  currentLog = { session, events, summary };

  const select = h('select', {
    'aria-label': 'Choose a class', onchange: () => { selectedId = select.value; followLive = false; renderLog(); },
  }, list.map((s) => h('option', { value: s.sessionId, selected: s.sessionId === selectedId },
    `${s.date}: ${s.meetCode}${s.declinedMarker ? ' (declined)' : s.status === 'open' ? ' (in progress)' : ''}`)));

  const report = summary.status === 'declined'
    ? [h('p', { class: 'tl-declined' }, summary.text)]
    : [
      h('h2', {}, 'Your report'),
      h('p', { class: 'meta' }, `${localTime(summary.startTs)} to ${localTime(summary.endTs)}${summary.status === 'in_progress' ? ' (so far)' : ''}. Engaged ${summary.percent.engaged}%, confirmed idle ${summary.percent.confirmedIdle}%, away ${summary.percent.away}%.`),
      timelineBar(segments, bounds.start, bounds.end),
      summaryTable(summary),
      h('p', { class: 'meta' }, promptLine(summary.prompts)),
      h('p', { class: 'meta' }, 'Longest time away: ' + (summary.longestAwayMs ? `${Math.round(summary.longestAwayMs / 1000)}s` : 'none') + '.')];

  pane.replaceChildren(
    h('div', { class: 'row tight' }, select),
    ...report,
    h('h2', {}, 'Hand in to your professor'),
    h('p', { class: 'meta' }, 'The hand-in file is what your professor opens in their report viewer. It contains this log only, never your notes or screenshots. Your professor never receives anything unless you send it.'),
    h('div', { class: 'row' },
      h('button', { class: 'btn solid', type: 'button', onclick: exportHandIn }, 'Hand-in file (.json)'),
      h('button', { class: 'btn', type: 'button', onclick: () => exportCsv('events') }, 'Events (.csv)'),
      h('button', { class: 'btn', type: 'button', onclick: () => exportCsv('summary') }, 'Summary (.csv)')),
    h('p', { class: 'meta err', id: 'export-msg', role: 'status' }),
    h('h2', {}, 'Every event'),
    h('ol', { class: 'log', 'aria-label': 'Events in your attention log, newest first' },
      [...events].sort((a, b) => b.seq - a.seq).map((e) => h('li', {},
        h('time', {}, e.ts ? localTime(e.ts) : session.date),
        h('span', {}, e.eventType === EventType.CONSENT_DECLINED ? (e.meta?.text ?? describeEvent(e)) : describeEvent(e))))));
}

function flash(text) { const el = $('#export-msg'); if (el) { el.textContent = text; el.className = 'meta'; } }

async function exportHandIn() {
  if (!currentLog) return;
  const { session, events } = currentLog;
  download(handInFilename(session, safeName), buildHandIn({ session, events, extensionVersion: chrome.runtime.getManifest().version }), 'application/json');
  flash('Hand-in file downloaded. Send it to your professor the way your course asks (email or LMS upload).');
}
async function exportCsv(kind) {
  if (!currentLog) return;
  const { session, events, summary } = currentLog;
  const chain = await verifyChain(events);
  const base = handInFilename(session, safeName).replace(/^attendance_/, '').replace(/\.json$/, '');
  if (kind === 'events') download(`events_${base}.csv`, eventsCsv(session, events), 'text/csv');
  else download(`summary_${base}.csv`, summaryCsv([{ ...summary, integrityOk: chain.ok }]), 'text/csv');
  flash('CSV downloaded.');
}

// ---------- Privacy and your details ----------
function renderPrivacy() {
  const pane = $('#pane-privacy');
  const s = state;
  const t = buildConsentText(s.config, s.classInfo);
  const name = h('input', { type: 'text', id: 'p-name', autocomplete: 'name', maxlength: '80', value: s.displayName });
  const num = h('input', { type: 'text', id: 'p-num', maxlength: '40', value: s.studentNumber });
  const msg = h('p', { class: 'err', role: 'alert' });
  const ident = () => ({ displayName: name.value, studentNumber: num.value, tabId });

  const run = async (type, okText) => {
    msg.className = 'err';
    msg.textContent = '';
    const res = await send({ type, ...ident() });
    if (!res?.ok) { msg.textContent = res?.error ?? 'Could not save. Try again.'; return; }
    confirmingStop = false;
    await refresh();
    if (okText) { const m = $('#pane-privacy .err'); if (m) { m.className = 'ok'; m.textContent = okText; } }
  };

  const code = h('input', { type: 'text', id: 'p-code', maxlength: '14', placeholder: 'Class code, e.g. K7M2QX9P', autocomplete: 'off' });
  const classMsg = h('p', { class: 'err', role: 'alert' });
  const changeClass = async (type) => {
    classMsg.textContent = '';
    const res = await send({ type, code: code.value, tabId });
    if (!res?.ok) { classMsg.textContent = res?.error ?? 'Could not change the class.'; return; }
    await refresh();
  };
  const st = s.syncStatus;
  const syncLine = !s.classInfo ? '' : st?.lastError ? `Upload problem: ${st.lastError}. Your log is safe on this computer and will retry.` : st?.lastOkTs ? `Last upload to your professor: ${localTime(st.lastOkTs)}.` : 'Nothing uploaded yet.';
  const classBlock = !s.syncAvailable
    ? h('p', { class: 'meta' }, 'Class upload is not set up in this copy of the extension. Use the hand-in file in My log.')
    : s.classInfo
      ? h('div', {}, h('p', {}, h('strong', {}, s.classInfo.className), s.classInfo.professorName ? ` with ${s.classInfo.professorName}` : ''), h('p', { class: 'meta' }, syncLine),
        h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => changeClass(MSG.CLASS_UNLINK) }, 'Change class')), classMsg)
      : h('div', {}, h('div', { class: 'fields' }, h('label', { for: 'p-code' }, 'Class code from your professor', code)),
        h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => changeClass(MSG.CLASS_LINK) }, 'Link class')), classMsg,
        h('p', { class: 'meta' }, 'With a code your professor receives the report automatically after class. Linking a class asks for your choice again.'));

  let controls;
  if (s.consentStatus === 'GRANTED') {
    controls = confirmingStop
      ? h('div', {},
        h('p', {}, 'Stop now? Logging ends immediately and your record gets one line: "No tracking record. Student declined tracking."'),
        h('div', { class: 'row' },
          h('button', { class: 'btn solid', type: 'button', onclick: () => run(MSG.CONSENT_REVOKE) }, 'Yes, stop logging'),
          h('button', { class: 'btn', type: 'button', onclick: () => { confirmingStop = false; renderPrivacy(); } }, 'Keep it on')))
      : h('div', { class: 'row' }, h('button', { class: 'btn solid', type: 'button', onclick: () => { confirmingStop = true; renderPrivacy(); } }, 'Stop sharing my log'));
  } else {
    controls = h('div', { class: 'row' },
      h('button', { class: 'btn solid', type: 'button', onclick: () => run(MSG.CONSENT_ACCEPT) }, 'Turn on the attention log'),
      h('button', { class: 'btn', type: 'button', onclick: () => run(MSG.CONSENT_DECLINE) }, s.consentStatus === 'DECLINED' ? 'Keep it off' : 'No thanks, do not track me'));
  }

  pane.replaceChildren(
    h('div', { class: 'state' }, statusText(s)),
    h('h2', {}, 'Your details'),
    h('div', { class: 'fields' }, h('label', { for: 'p-name' }, 'Your name', name), h('label', { for: 'p-num' }, 'Student number', num)),
    h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: () => run(MSG.PROFILE_UPDATE, s.consentStatus === 'GRANTED' ? 'Saved. Applies from your next class.' : 'Saved.') }, 'Save details')),
    msg,
    h('h2', {}, 'Your class'),
    classBlock,
    h('h2', {}, 'Attention log'),
    controls,
    h('h2', {}, t.title),
    h('p', {}, t.intro),
    ...t.sections.map((sec) => h('section', {}, h('h3', {}, sec.heading), h('ul', {}, sec.items.map((i) => h('li', {}, i))))),
    h('p', { class: 'meta' }, t.footer));
}

async function activeTabId() { return (await getTargetTab())?.id ?? null; }

async function refresh() {
  tabId ??= await activeTabId();
  const res = await send({ type: MSG.GET_STATE, tabId });
  if (!res?.state) return;
  state = res.state;
  $('#status').textContent = statusText(state);
  $('#detect').textContent = PAGE_TEXT[state.page ?? 'none'];
  await renderLog();
  const key = `${state.consentStatus}|${state.monitoredHere}|${confirmingStop}`;
  const typing = $('#pane-privacy').contains(document.activeElement);
  if (key !== lastPrivacyKey || !typing) { renderPrivacy(); lastPrivacyKey = key; }    // never wipe a form the student is filling in
  notes.refreshContext();
}

document.querySelectorAll('nav [role="tab"]').forEach((btn) => btn.addEventListener('click', () => {
  document.querySelectorAll('nav [role="tab"]').forEach((b) => b.setAttribute('aria-selected', String(b === btn)));
  for (const name of ['notes', 'log', 'privacy']) $(`#pane-${name}`).hidden = btn.dataset.tab !== name;
  if (btn.dataset.tab === 'notes') notes.refreshContext();
}));

let pending = null;
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === MSG.STATE_CHANGED || msg?.type === MSG.LOG_APPENDED) {
    clearTimeout(pending);
    pending = setTimeout(refresh, 150);       // coalesce bursts
  }
});
refresh();
