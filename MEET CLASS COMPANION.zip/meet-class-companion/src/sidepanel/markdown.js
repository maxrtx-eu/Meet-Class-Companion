import { h } from '../shared/dom.js';
import { tokenizeInline, parseBlocks } from '../shared/mdcore.js';

function inline(text, resolve) {
  return tokenizeInline(text).map((t) => {
    switch (t.t) {
      case 'b': return h('strong', {}, t.v);
      case 'i': return h('em', {}, t.v);
      case 'code': return h('code', {}, t.v);
      case 'img': {
        const src = t.src.startsWith('shot:') ? resolve?.(t.src.slice(5)) : (t.src.startsWith('data:image/') ? t.src : null);
        return src ? h('img', { src, alt: t.alt || 'Slide screenshot', class: 'shot' }) : h('em', {}, '(screenshot not available)');
      }
      default: return t.v;
    }
  });
}

/** Builds DOM with createElement only (never innerHTML). `resolve(id)` returns an object URL for a stored screenshot. */
export function renderMarkdown(text, resolve) {
  const frag = document.createDocumentFragment();
  for (const b of parseBlocks(text)) {
    if (b.type === 'h') frag.append(h(`h${b.level + 1}`, {}, inline(b.text, resolve)));
    else if (b.type === 'ul' || b.type === 'ol') frag.append(h(b.type, {}, b.items.map((i) => h('li', {}, inline(i, resolve)))));
    else frag.append(h('p', {}, b.lines.map((l, idx) => [idx ? h('br') : null, inline(l, resolve)])));
  }
  return frag;
}
