// Student-side export of their own notes. Markdown is a single self-contained file (screenshots embedded as data URIs).
// PDF goes through a print-styled page and the browser's "Save as PDF": zero dependencies, nothing remote.
import { studyRepo } from '../storage/studyRepo.local.js';
import { shotIds, embedImages } from '../shared/mdcore.js';

const blobToDataUrl = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });

export async function buildMarkdown(note) {
  const urls = new Map();
  for (const id of new Set(shotIds(note.text))) {
    const shot = await studyRepo.getShot(id);
    if (shot) urls.set(id, await blobToDataUrl(shot.blob));
  }
  return `# Notes: ${note.meetCode}, ${note.date}\n\n${embedImages(note.text, urls)}\n`;
}

export { download, safeName } from '../export/download.js';

export function openPrintView(key) {
  chrome.tabs.create({ url: `${chrome.runtime.getURL('src/sidepanel/print.html')}?key=${encodeURIComponent(key)}` });
}
