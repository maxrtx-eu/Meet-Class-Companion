// Which Meet tab is this panel about? As a side panel it is the active tab of its window.
// As a fallback companion window it is the tab named in ?tab=ID (the window itself has no Meet tab).
export async function getTargetTab() {
  try {
    const id = Number(new URLSearchParams(location.search).get('tab'));
    if (id) return await chrome.tabs.get(id);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ?? null;
  } catch { return null; }
}
