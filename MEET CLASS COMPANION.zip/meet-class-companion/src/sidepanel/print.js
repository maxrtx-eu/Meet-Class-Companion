import { h } from '../shared/dom.js';
import { studyRepo } from '../storage/studyRepo.local.js';
import { shotIds } from '../shared/mdcore.js';
import { renderMarkdown } from './markdown.js';

const key = new URLSearchParams(location.search).get('key');
const doc = document.getElementById('doc');
document.getElementById('print').addEventListener('click', () => window.print());

(async () => {
  const note = key ? await studyRepo.getNote(key) : null;
  if (!note) { doc.append(h('p', {}, 'These notes could not be found.')); return; }
  const urls = new Map();
  for (const id of new Set(shotIds(note.text))) {
    const shot = await studyRepo.getShot(id);
    if (shot) urls.set(id, URL.createObjectURL(shot.blob));
  }
  document.title = `Notes ${note.meetCode} ${note.date}`;
  doc.append(h('h1', {}, `Notes: ${note.meetCode}`), h('p', { class: 'sub' }, note.date), renderMarkdown(note.text, (id) => urls.get(id)));
  await Promise.all([...doc.querySelectorAll('img')].map((i) => i.decode().catch(() => {})));
  setTimeout(() => window.print(), 300);
})();
