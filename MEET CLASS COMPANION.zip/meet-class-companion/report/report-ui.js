// Professor's offline report viewer. Bundled with the shared modules into ONE html file (tools/build-report.mjs)
// so it opens by double-click, needs no install and sends nothing anywhere. All checking happens in this page.
const results = [];
let selected = 0;
const app = document.getElementById('app');

async function loadFiles(files) {
  for (const file of files) {
    const parsed = parseHandIn(await file.text());
    if (!parsed.ok) { results.push({ name: file.name, error: parsed.error }); continue; }
    const { session, events, exportedAt } = parsed.data;
    const chain = await verifyChain(events);
    results.push({ name: file.name, session, events, chain, ...summarizeSession(session, events, { now: exportedAt ?? Date.now() }) });
  }
  selected = 0;
  render();
}

function render() {
  const good = results.filter((r) => r.summary).sort((a, b) => (a.summary.displayName || a.summary.studentId || '').localeCompare(b.summary.displayName || b.summary.studentId || ''));
  const bad = results.filter((r) => r.error);
  const picker = h('input', { type: 'file', id: 'file', accept: '.json,application/json', multiple: true, onchange: (e) => loadFiles(e.target.files) });
  const drop = h('label', { class: 'drop', for: 'file' }, h('strong', {}, 'Choose the hand-in files'), ' or drop them here. Open one file per student, or select the whole folder at once.', picker);
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); loadFiles(e.dataTransfer.files); });

  const kids = [h('header', {}, h('h1', {}, 'Class Companion report viewer'), h('p', {}, 'Works offline. Files never leave this page. For files students hand in manually.')), drop];
  for (const r of bad) kids.push(h('p', { class: 'bad box' }, `${r.name}: ${r.error}`));
  if (good.length) {
    kids.push(studentsTable(good, selected, (i) => { selected = i; render(); }));
    kids.push(h('div', { class: 'row' }, h('button', { type: 'button', onclick: () => download('class-summary.csv', summaryCsv(good.map((r) => ({ ...r.summary, integrityOk: r.chain.ok }))), 'text/csv') }, 'Download summary CSV (all students)')));
    kids.push(studentDetail(good[Math.min(selected, good.length - 1)]));
  }
  kids.push(reportFooter());
  app.replaceChildren(...kids);
}

render();
