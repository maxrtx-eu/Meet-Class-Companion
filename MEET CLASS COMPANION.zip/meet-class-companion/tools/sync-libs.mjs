// Copies the shared, pure modules next to the dashboard and the Cloud Function so all three run the SAME code
// for hashing, summaries and CSV. Run after changing anything in src/shared or src/export:  node tools/sync-libs.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const COPY = { 'dashboard/public/lib': ['shared', 'export'], 'functions/lib': ['shared', 'export'] };
for (const [dest, dirs] of Object.entries(COPY)) {
  for (const d of dirs) {
    const from = path.join(root, 'src', d);
    const to = path.join(root, dest, d);
    fs.rmSync(to, { recursive: true, force: true });
    fs.mkdirSync(to, { recursive: true });
    for (const f of fs.readdirSync(from)) fs.copyFileSync(path.join(from, f), path.join(to, f));
  }
}
console.log('libs copied');
