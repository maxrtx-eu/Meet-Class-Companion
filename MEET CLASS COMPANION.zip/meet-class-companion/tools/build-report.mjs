// Builds report/professor-report-viewer.html: the shared modules + the viewer UI inlined into ONE file,
// because browsers will not load ES modules from file:// (a professor double-clicks the file).
// Usage: node tools/build-report.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const LIB = ['src/shared/schema.js', 'src/shared/hash.js', 'src/shared/timeline.js', 'src/shared/dom.js', 'src/shared/timelineView.js', 'src/shared/reportView.js', 'src/export/csv.js', 'src/export/download.js', 'src/export/handIn.js'];

function strip(src) {
  return src
    .replace(/^import[^;]*?from\s+['"][^'"]+['"];?[ \t]*$/gm, '')
    .replace(/^export\s+\{[^}]*\}\s+from\s+['"][^'"]+['"];?[ \t]*$/gm, '')
    .replace(/^export\s+(?=(?:async\s+function|function|const|let|class)\b)/gm, '');
}

/** All shared modules as one script body. Throws if two modules declare the same top-level name. */
export function topLevelNames(code) {
  return [...code.matchAll(/^(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)/gm)].map((m) => m[1]);
}

export function bundleLib() {
  const seen = new Map();
  const parts = LIB.map((file) => {
    const code = strip(fs.readFileSync(path.join(root, file), 'utf8'));
    for (const name of topLevelNames(code)) {
      if (seen.has(name)) throw new Error(`Name clash in bundle: "${name}" in ${file} and ${seen.get(name)}`);
      seen.set(name, file);
    }
    if (/^\s*(import|export)\s/m.test(code)) throw new Error(`Unstripped import/export left in ${file}`);
    return `// ---- ${file}\n${code}`;
  });
  return parts.join('\n');
}

const CSS = `
:root{--ink:#17201e;--board:#1e3a34;--teal:#0b6e63;--line:#d5ddd9}
*{box-sizing:border-box}body{margin:0;font:15px/1.5 "Segoe UI",system-ui,sans-serif;color:var(--ink);background:#f4f6f5}
#app{max-width:1100px;margin:0 auto;padding:0 20px 60px}
header{margin:0 -20px 20px;padding:22px 20px 16px;background:var(--board);color:#eef2ee;border-bottom:8px solid #7a5230}
header h1{margin:0;font-size:26px}header p{margin:4px 0 0;color:#c3d3cc}
.drop{display:block;padding:26px;border:3px dashed #8b9894;border-radius:14px;background:#fff;text-align:center;cursor:pointer}
.drop.over{border-color:var(--teal);background:#e6f2ee}.drop input{display:block;margin:12px auto 0}
.grid{width:100%;border-collapse:collapse;margin:16px 0;background:#fff;font-size:14px}
.grid th,.grid td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
.grid th{background:#e9eeec;font-size:13px}.num{text-align:right;font-variant-numeric:tabular-nums}
small{display:block;color:#5a6763}.clickable{cursor:pointer}.clickable:hover,.sel{background:#eef6f3}
.good{color:#0b6e63;font-weight:700}.bad{color:#b3261e;font-weight:700}
.box{padding:10px 12px;border-radius:10px;background:#fff;border:1px solid var(--line)}
.detail{padding:18px;border-radius:14px;background:#fff;border:1px solid var(--line);margin-top:12px}
.detail h2{margin:0 0 6px}
.row{display:flex;gap:10px;margin:8px 0}
button{min-height:42px;padding:0 16px;border:2px solid var(--ink);border-radius:10px;background:#fff;font:inherit;font-weight:700;cursor:pointer}
:focus-visible{outline:3px solid var(--teal);outline-offset:2px}
footer{margin-top:28px;color:#37433f}footer h2{font-size:16px}
.tl-bar{display:flex;height:26px;margin:10px 0;border-radius:6px;overflow:hidden;background:#e6ebe8}.tl-seg{display:block;height:100%;min-width:1px}
.tl-table{width:100%;max-width:640px;border-collapse:collapse;margin:8px 0 12px;font-size:14px}
.tl-table th,.tl-table td{padding:5px 8px;border-bottom:1px solid #e6ebe8;text-align:left}.tl-table .num{text-align:right}
.tl-swatch{display:inline-block;width:12px;height:12px;margin-right:8px;border-radius:3px;vertical-align:-1px}
.tl-declined{padding:10px 12px;border-radius:10px;background:#eef2ee;font-weight:600}
@media print{.drop,.row,input{display:none}}
`;

export function buildViewer() {
  const ui = fs.readFileSync(path.join(root, 'report/report-ui.js'), 'utf8');
  const lib = bundleLib();
  const libNames = new Set(topLevelNames(lib));
  for (const name of topLevelNames(ui)) if (libNames.has(name)) throw new Error(`Name clash: "${name}" is declared in report-ui.js and in the library`);
  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Class Companion report viewer</title><style>${CSS}</style></head>
<body><div id="app"></div>
<script>
(() => {
${lib}
// ---- viewer UI
${ui}
})();
</script></body></html>
`;
  const out = path.join(root, 'report/professor-report-viewer.html');
  fs.writeFileSync(out, html);
  return out;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) console.log('built', buildViewer());
