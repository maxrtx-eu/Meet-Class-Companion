import test from 'node:test';
import assert from 'node:assert/strict';
import { createIdleState, stepIdle, currentThresholdMs, Phase } from '../../src/shared/idleEngine.js';
import { DEFAULT_CONFIG } from '../../src/shared/config.js';

function sim(over = {}) {
  const cfg = { ...DEFAULT_CONFIG, ...over };
  let t = 1_000_000;
  let s = createIdleState(t);
  const fx = [];
  const api = {
    cfg, fx,
    get s() { return s; },
    get t() { return t; },
    send(input) { const r = stepIdle(s, input, t, cfg); s = r.state; fx.push(...r.effects); return r.effects; },
    advance(ms) { const end = t + ms; while (t < end) { t = Math.min(t + 1000, end); api.send({ type: 'TICK' }); } },
    jump(ms) { t += ms; api.send({ type: 'TICK' }); },       // one tick after a long gap (machine slept)
    logs(type) { return fx.filter((e) => e.type === 'LOG' && (!type || e.eventType === type)); },
    untilPrompt() { const start = t; for (let i = 0; i < 2000 && s.phase !== Phase.PROMPTED; i++) api.advance(1000); return t - start; },
  };
  api.send({ type: 'ENV', eligible: true });
  return api;
}

test('respond FAST: logged as fast, then a cooldown blocks the next prompt', () => {
  const x = sim();
  x.advance(59_000);
  assert.equal(x.s.phase, Phase.ARMED);
  assert.equal(x.logs('IDLE_PROMPT_SHOWN').length, 0);
  x.advance(1_000);
  assert.equal(x.s.phase, Phase.PROMPTED);
  assert.equal(x.logs('IDLE_PROMPT_SHOWN').length, 1);
  assert.ok(x.fx.some((e) => e.type === 'SHOW_PROMPT'));

  x.advance(3_000);
  x.send({ type: 'RESPOND' });
  const [r] = x.logs('IDLE_PROMPT_RESPONDED');
  assert.equal(r.meta.responseSec, 3);
  assert.equal(r.meta.speed, 'fast');
  assert.equal(r.meta.late, false);
  assert.equal(x.s.phase, Phase.COOLDOWN);
  assert.equal(x.logs('IDLE_CONFIRMED').length, 0);

  x.advance(299_000);                                     // still inside the 5 minute cooldown
  assert.equal(x.logs('IDLE_PROMPT_SHOWN').length, 1);
  x.advance(1_000);                                       // cooldown over and still quiet: prompt again
  assert.equal(x.logs('IDLE_PROMPT_SHOWN').length, 2);
});

test('respond SLOW: bucketed as slow, never confirmed idle, fast streak reset', () => {
  const x = sim();
  x.untilPrompt();
  x.advance(30_000);
  x.send({ type: 'RESPOND' });
  const [r] = x.logs('IDLE_PROMPT_RESPONDED');
  assert.equal(r.meta.responseSec, 30);
  assert.equal(r.meta.speed, 'slow');
  assert.equal(x.logs('IDLE_CONFIRMED').length, 0);
  assert.equal(x.s.fastStreak, 0);
});

test('NEVER respond: IDLE_CONFIRMED at the end of the window; idle clock starts there, not at last input', () => {
  const x = sim();
  x.untilPrompt();
  const shown = x.fx.find((e) => e.type === 'SHOW_PROMPT');
  x.advance(60_000);
  const [c] = x.logs('IDLE_CONFIRMED');
  assert.equal(c.ts, shown.shownTs + 60_000);
  assert.equal(x.s.phase, Phase.IDLE);

  x.advance(120_000);
  const out = x.send({ type: 'ENV', eligible: false });   // student leaves the tab
  const [ret] = x.logs('RETURNED');
  assert.equal(ret.durationMs, 120_000);
  assert.equal(ret.meta.from, 'IDLE_CONFIRMED');
  assert.equal(ret.meta.cause, 'suspended');
  assert.ok(out.some((e) => e.type === 'HIDE_PROMPT'));
  assert.equal(x.logs('IDLE_PROMPT_RESPONDED').length, 0);
});

test('LATE response after confirmed idle: both the response time and the idle duration are recorded', () => {
  const x = sim();
  x.untilPrompt();
  x.advance(60_000 + 90_000);
  x.send({ type: 'RESPOND' });
  const [r] = x.logs('IDLE_PROMPT_RESPONDED');
  assert.equal(r.meta.late, true);
  assert.equal(r.meta.responseSec, 150);
  const [ret] = x.logs('RETURNED');
  assert.equal(ret.durationMs, 90_000);
  assert.equal(ret.meta.cause, 'late_response');
  assert.equal(x.s.phase, Phase.COOLDOWN);
});

test('input resets the suspicion timer', () => {
  const x = sim();
  x.advance(59_000);
  x.send({ type: 'INPUT' });
  x.advance(59_000);
  assert.equal(x.s.phase, Phase.ARMED);
  x.advance(1_000);
  assert.equal(x.s.phase, Phase.PROMPTED);
});

test('leaving the tab while prompted cancels the prompt without logging idle', () => {
  const x = sim();
  x.untilPrompt();
  const out = x.send({ type: 'ENV', eligible: false });
  assert.ok(out.some((e) => e.type === 'HIDE_PROMPT'));
  assert.equal(x.s.phase, Phase.SUSPENDED);
  x.advance(300_000);
  assert.equal(x.logs('IDLE_CONFIRMED').length, 0);
  x.send({ type: 'ENV', eligible: true });
  assert.equal(x.s.phase, Phase.ARMED);
});

test('no prompt while the environment is not eligible (notes panel active, Chrome unfocused...)', () => {
  const x = sim();
  x.send({ type: 'ENV', eligible: false });
  x.advance(600_000);
  assert.equal(x.logs().length, 0);
});

test('adaptive mode lengthens the threshold after consecutive fast responses and resets after a slow one', () => {
  const x = sim({ adaptive: true, cooldownSec: 30 });
  assert.equal(x.untilPrompt(), 60_000);
  x.advance(1_000); x.send({ type: 'RESPOND' });
  assert.equal(x.untilPrompt(), 90_000);                  // 60 * 1.5
  x.advance(1_000); x.send({ type: 'RESPOND' });
  assert.equal(x.untilPrompt(), 135_000);                 // 60 * 1.5^2
  x.advance(30_000); x.send({ type: 'RESPOND' });         // slow answer
  assert.equal(x.s.fastStreak, 0);
  assert.equal(currentThresholdMs(x.s, x.cfg), 60_000);
});

test('adaptive threshold is capped', () => {
  const s = { ...createIdleState(0), fastStreak: 20 };
  assert.equal(currentThresholdMs(s, { ...DEFAULT_CONFIG, adaptive: true }), 60_000 * 4);
});

test('a long gap between ticks (laptop sleep) is not treated as idleness', () => {
  const x = sim();
  x.advance(30_000);
  x.jump(600_000);
  assert.equal(x.s.phase, Phase.ARMED);
  assert.equal(x.logs('IDLE_PROMPT_SHOWN').length, 0);
});

test('RESET while idle closes the episode so the duration is kept', () => {
  const x = sim();
  x.untilPrompt();
  x.advance(60_000 + 10_000);
  x.send({ type: 'RESET', cause: 'call_left' });
  const [ret] = x.logs('RETURNED');
  assert.equal(ret.durationMs, 10_000);
  assert.equal(ret.meta.cause, 'call_left');
});
