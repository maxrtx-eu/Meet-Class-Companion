import test from 'node:test';
import assert from 'node:assert/strict';
import { parseMeetCode, describeEvent, EventType } from '../../src/shared/schema.js';
import { canonical, hashEvent, verifyChain } from '../../src/shared/hash.js';
import { GENESIS_HASH } from '../../src/shared/schema.js';
import { sanitizeConfig, DEFAULT_CONFIG } from '../../src/shared/config.js';
import { buildConsentText, formatDuration } from '../../src/shared/consentText.js';

test('parseMeetCode accepts meeting URLs and rejects everything else', () => {
  assert.equal(parseMeetCode('https://meet.google.com/abc-defg-hij'), 'abc-defg-hij');
  assert.equal(parseMeetCode('https://meet.google.com/abc-defg-hij?authuser=1'), 'abc-defg-hij');
  assert.equal(parseMeetCode('https://meet.google.com/my-class'), 'my-class');          // Workspace nickname
  assert.equal(parseMeetCode('https://meet.google.com/landing'), null);
  assert.equal(parseMeetCode('https://meet.google.com/'), null);
  assert.equal(parseMeetCode('https://meet.google.com/lookup/abc123'), null);
  assert.equal(parseMeetCode('https://example.com/abc-defg-hij'), null);
  assert.equal(parseMeetCode('not a url'), null);
});

test('canonical() is key-order independent', () => {
  assert.equal(canonical({ b: 1, a: { d: [1, 2], c: null } }), canonical({ a: { c: null, d: [1, 2] }, b: 1 }));
});

async function chain(n) {
  const events = [];
  let prev = GENESIS_HASH;
  for (let i = 1; i <= n; i++) {
    const e = { eventId: `e${i}`, seq: i, sessionId: 's', studentId: 'x', meetCode: 'm', eventType: EventType.JOINED_CLASS, ts: i * 1000, durationMs: null, meta: { i }, prevHash: prev };
    e.hash = await hashEvent(e);
    prev = e.hash;
    events.push(e);
  }
  return events;
}

test('hash chain verifies, and detects edits, deletions and reordering', async () => {
  const ev = await chain(4);
  assert.deepEqual(await verifyChain(ev), { ok: true });
  assert.equal((await verifyChain(ev.map((e, i) => (i === 1 ? { ...e, ts: 5 } : e)))).ok, false);
  assert.equal((await verifyChain(ev.filter((e) => e.seq !== 2))).ok, false);
  assert.equal((await verifyChain([ev[0], ev[2], ev[1], ev[3]].map((e, i) => ({ ...e, seq: i + 1 })))).ok, false);
});

test('sanitizeConfig clamps and ignores junk', () => {
  const c = sanitizeConfig({ idleSuspicionSec: 1, responseWindowSec: 99999, cooldownSec: 'abc', adaptive: 1 });
  assert.equal(c.idleSuspicionSec, 15);
  assert.equal(c.responseWindowSec, 300);
  assert.equal(c.cooldownSec, DEFAULT_CONFIG.cooldownSec);
  assert.equal(c.adaptive, true);
});

test('consent text always reflects the live configuration', () => {
  const flat = (cfg) => buildConsentText(cfg).sections.flatMap((s) => s.items).join(' ');
  assert.match(flat(DEFAULT_CONFIG), /about 1 minute/);
  assert.match(flat(DEFAULT_CONFIG), /at least 5 minutes/);
  assert.match(flat({ ...DEFAULT_CONFIG, idleSuspicionSec: 90, cooldownSec: 600 }), /about 1 minute 30 seconds/);
  assert.match(flat({ ...DEFAULT_CONFIG, idleSuspicionSec: 90, cooldownSec: 600 }), /at least 10 minutes/);
  assert.doesNotMatch(flat(DEFAULT_CONFIG), /appear less often/);
  assert.match(flat({ ...DEFAULT_CONFIG, adaptive: true }), /appear less often/);
  assert.equal(formatDuration(150), '2 minutes 30 seconds');
});

test('describeEvent never needs content, only metadata', () => {
  assert.match(describeEvent({ eventType: EventType.NOTE_ACTIVITY, durationMs: 90_000, meta: {} }), /Taking notes for 1m 30s/);
  assert.match(describeEvent({ eventType: EventType.CONSENT_DECLINED, meta: { text: 'No tracking record. Student declined tracking.' } }), /declined tracking/);
});
