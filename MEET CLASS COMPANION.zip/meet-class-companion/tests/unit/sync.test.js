import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { installMockChrome } from '../helpers/mockChrome.js';
import { createMemoryRepo } from '../../src/storage/logRepo.memory.js';
import { createSync } from '../../src/sync/syncEngine.js';
import { encodeFields, decodeFields } from '../../src/sync/firestoreRest.js';
import { GENESIS_HASH, EventType as T } from '../../src/shared/schema.js';
import { hashEvent } from '../../src/shared/hash.js';

// A tiny fake Firestore that enforces the two properties the engine relies on: create-only docs and atomic commits.
function fakeServer() {
  const docs = new Map();
  const calls = [];
  const rootLen = 'projects/p/databases/(default)/documents/'.length;
  return {
    docs, calls,
    client: {
      docName: (path) => `projects/p/databases/(default)/documents/${path}`,
      async signUpAnonymous() { return { idToken: 'tok', refreshToken: 'ref', uid: 'uid1', expiresIn: 3600 }; },
      async refresh() { return { idToken: 'tok2', refreshToken: 'ref2', uid: 'uid1', expiresIn: 3600 }; },
      async getDoc(path) { const d = docs.get(path); return d ? { __id: path.split('/').pop(), ...d } : null; },
      async commit(writes) {
        calls.push(writes.map((w) => w.update.name.slice(rootLen)));
        if (server.fail) { const e = new Error('unavailable'); e.status = 503; throw e; }
        for (const w of writes) if (w.currentDocument?.exists === false && docs.has(w.update.name.slice(rootLen))) { const e = new Error('exists'); e.status = 409; e.code = 'ALREADY_EXISTS'; throw e; }
        for (const w of writes) {
          const path = w.update.name.slice(rootLen);
          docs.set(path, { ...(docs.get(path) ?? {}), ...decodeFields(w.update.fields) });
        }
      },
    },
  };
}
let server; let repo; let clock; let consentStatus;
const consent = () => ({ status: consentStatus, studentNumber: '2024-0001', displayName: 'Ana', version: 2 });

function engine(over = {}) {
  return createSync({ client: server.client, repo, store: chrome.storage.local, getConsent: async () => consent(), now: () => clock, ...over });
}
async function seedSession({ id = 's1', classId = 'c1', events = 3, status = 'open', declinedMarker = false } = {}) {
  await repo.putSession({ sessionId: id, studentId: '2024-0001', displayName: 'Ana', meetCode: 'abc-defg-hij', date: '2026-10-06', meetDate: 'abc-defg-hij|2026-10-06', classId, startTs: 1000, endTs: status === 'closed' ? 9000 : null, status, declinedMarker, head: null });
  let prev = GENESIS_HASH;
  for (let i = 1; i <= events; i++) {
    const e = { eventId: `${id}-${i}`, seq: i, sessionId: id, studentId: '2024-0001', meetCode: 'abc-defg-hij', eventType: i === 1 ? T.JOINED_CLASS : T.FOCUS_LOST, ts: declinedMarker ? null : 1000 + i, durationMs: null, meta: { n: i, f: 1.5 }, prevHash: prev };
    e.hash = await hashEvent(e); prev = e.hash;
    await repo.appendEvent(e);
  }
}
const link = { classId: 'c1', joinCode: 'ABCD2345', className: 'CS 101', professorName: 'Dr X', retentionDays: 30 };

beforeEach(async () => { installMockChrome(); server = fakeServer(); repo = createMemoryRepo(); clock = 1_000_000; consentStatus = 'GRANTED'; await chrome.storage.local.set({ classLink: link }); });

test('Firestore value encoding round-trips ints, doubles, null, nested maps', () => {
  const src = { a: 1, b: 1.5, c: null, d: 'x', e: true, f: { g: [1, 'two'] }, h: 1_760_000_000_000 };
  assert.deepEqual(decodeFields(encodeFields(src)), src);
  assert.deepEqual(encodeFields({ n: 5 }).n, { integerValue: '5' });
  assert.deepEqual(encodeFields({ n: 5.5 }).n, { doubleValue: 5.5 });
});

test('uploads nothing without Firebase config, without a class, or before the student has decided', async () => {
  await seedSession();
  assert.deepEqual(await engine({ configured: () => false }).flush(), { skipped: 'not_configured' });
  await chrome.storage.local.remove('classLink');
  assert.deepEqual(await engine().flush(), { skipped: 'no_class' });
  await chrome.storage.local.set({ classLink: link });
  consentStatus = 'UNSET';
  assert.deepEqual(await engine().flush(), { skipped: 'undecided' });
  assert.equal(server.calls.length, 0);
});

test('a consented class uploads: member first, then session, then events in order; only that class\'s sessions', async () => {
  await seedSession();
  await seedSession({ id: 'other', classId: 'c2' });
  await seedSession({ id: 'local', classId: null });
  const r = await engine().flush();
  assert.equal(r.ok, true);
  const names = server.calls.flat();
  assert.match(names[0], /^classes\/c1\/members\/uid1$/);
  assert.match(names[1], /^classes\/c1\/sessions\/s1$/);
  assert.deepEqual(names.filter((n) => n.includes('/events/')).map((n) => n.split('/').pop()), ['1', '2', '3']);
  assert.equal(names.some((n) => n.includes('other') || n.includes('local')), false);
  assert.equal(server.docs.get('classes/c1/sessions/s1').status, 'open');
  const ev = server.docs.get('classes/c1/sessions/s1/events/2');
  assert.equal(ev.eventType, T.FOCUS_LOST);
  assert.equal(ev.uid, 'uid1');
  assert.equal(ev.meta.f, 1.5);
  assert.ok(ev.expireAt instanceof Date || typeof ev.expireAt === 'object');
});

test('only new events are sent next time, and a closed session is closed on the server last', async () => {
  await seedSession({ events: 2 });
  const e = engine();
  await e.flush({ force: true });
  server.calls.length = 0;
  await e.flush({ force: true });
  assert.equal(server.calls.length, 0);                                    // nothing new: nothing sent
  const rec = await repo.getSession('s1');
  await repo.putSession({ ...rec, status: 'closed', endTs: 9000 });
  await e.flush({ force: true });
  assert.equal(server.docs.get('classes/c1/sessions/s1').status, 'closed');
  assert.equal(server.docs.get('classes/c1/sessions/s1').endTs, 9000);
  await e.flush({ force: true });
  assert.equal(server.calls.filter((c) => c.some((n) => n.endsWith('/sessions/s1'))).length >= 1, true);
});

test('large sessions upload in chunks that respect the commit limit', async () => {
  await seedSession({ events: 450 });
  await engine().flush();
  const eventCommits = server.calls.filter((c) => c.some((n) => n.includes('/events/')));
  assert.equal(eventCommits.length, 3);
  assert.ok(eventCommits.every((c) => c.length <= 201));
  assert.equal([...server.docs.keys()].filter((k) => k.includes('/events/')).length, 450);
});

test('lost-reply recovery: events that already exist on the server are skipped, the rest still arrive', async () => {
  await seedSession({ events: 5 });
  for (const i of [1, 2, 3]) server.docs.set(`classes/c1/sessions/s1/events/${i}`, { seq: i });
  await engine().flush();
  assert.equal([...server.docs.keys()].filter((k) => k.includes('/events/')).length, 5);
  assert.equal((await chrome.storage.local.get('syncStatus')).syncStatus.lastError, null);
});

test('declined student: only the one-line marker goes up, then the member is flipped to DECLINED', async () => {
  consentStatus = 'DECLINED';
  await seedSession({ id: 'decl-1', status: 'closed', declinedMarker: true, events: 1 });
  await engine().flush();
  const s = server.docs.get('classes/c1/sessions/decl-1');
  assert.equal(s.status, 'closed');
  assert.equal(s.declinedMarker, true);
  assert.equal(server.docs.get('classes/c1/sessions/decl-1/events/1').ts, null);
  const order = server.calls.flat();
  assert.ok(order.findIndex((n) => n.includes('/events/1')) < order.findIndex((n) => n.includes('/members/')), 'member is written after the marker');
  assert.equal(server.docs.get('classes/c1/members/uid1').consentStatus, 'DECLINED');
});

test('revocation: everything consented to is uploaded BEFORE the server learns the student said no', async () => {
  await seedSession({ events: 3 });
  const e = engine();
  await e.flush({ force: true });                                          // member GRANTED on server
  const rec = await repo.getSession('s1');
  const last = { eventId: 'm', seq: 4, sessionId: 's1', studentId: '2024-0001', meetCode: 'abc-defg-hij', eventType: T.CONSENT_DECLINED, ts: 5000, durationMs: null, meta: { reason: 'revoked' }, prevHash: rec.head.hash };
  last.hash = await hashEvent(last);
  await repo.appendEvent(last);
  await repo.putSession({ ...(await repo.getSession('s1')), status: 'closed', endTs: 5000 });
  consentStatus = 'DECLINED';
  await e.markMemberDirty();
  server.calls.length = 0;
  await e.flush({ force: true });
  const order = server.calls.flat();
  const iMarker = order.findIndex((n) => n.endsWith('/events/4'));
  const iClose = order.findIndex((n) => n.endsWith('/sessions/s1'));
  const iMember = order.findIndex((n) => n.includes('/members/'));
  assert.ok(iMarker >= 0 && iMarker < iMember && iClose < iMember, 'marker + close first, member DECLINED last');
  assert.equal(server.docs.get('classes/c1/members/uid1').consentStatus, 'DECLINED');
});

test('a failing network never loses data: backoff, then recovery uploads everything', async () => {
  await seedSession({ events: 3 });
  const e = engine();
  server.fail = true;
  assert.ok((await e.flush()).error);
  const st = (await chrome.storage.local.get('syncStatus')).syncStatus;
  assert.match(st.lastError, /unavailable/);
  server.calls.length = 0;
  assert.deepEqual(await e.flush(), { skipped: 'backoff' });               // does not hammer the server
  assert.equal(server.calls.length, 0);
  server.fail = false;
  clock += 10 * 60_000;
  assert.equal((await e.flush()).ok, true);
  assert.equal([...server.docs.keys()].filter((k) => k.includes('/events/')).length, 3);
});

test('linking a class: validates the code, resolves the professor and class, rejects unknown codes', async () => {
  await chrome.storage.local.remove('classLink');
  server.docs.set('joinCodes/K7M2QX9P', { classId: 'c9', className: 'Bio 2', professorName: 'Dr Y', retentionDays: 60 });
  const e = engine();
  await assert.rejects(() => e.linkClass('abc'), /does not look right/);
  await assert.rejects(() => e.linkClass('ZZZZZZZZ'), /not found/);
  const l = await e.linkClass(' k7m2-qx9p ');
  assert.deepEqual([l.classId, l.className, l.professorName, l.retentionDays], ['c9', 'Bio 2', 'Dr Y', 60]);
  assert.equal((await chrome.storage.local.get('classLink')).classLink.classId, 'c9');
});
