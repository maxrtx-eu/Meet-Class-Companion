import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { installMockChrome } from '../helpers/mockChrome.js';
import { setLogRepo } from '../../src/storage/index.js';
import { createMemoryRepo } from '../../src/storage/logRepo.memory.js';
import { logEvent, writeDeclineMarker, appendRevocationMarker } from '../../src/background/logger.js';
import { grant, decline, revoke, getConsent } from '../../src/background/consent.js';
import { verifyChain } from '../../src/shared/hash.js';
import { EventType, DECLINED_TEXT } from '../../src/shared/schema.js';

let repo;
beforeEach(() => { installMockChrome(); repo = createMemoryRepo(); setLogRepo(repo); });

const openSession = (id = 's1') => repo.putSession({
  sessionId: id, studentId: '2024-0001', displayName: 'Ana', meetCode: 'abc-defg-hij', date: '2026-10-06',
  meetDate: 'abc-defg-hij|2026-10-06', startTs: 1, endTs: null, status: 'open', declinedMarker: false, head: null,
});

test('consent UNSET or DECLINED: nothing is ever logged', async () => {
  await openSession();
  assert.equal(await logEvent('s1', EventType.FOCUS_LOST), null);          // UNSET
  await decline({});
  assert.equal(await logEvent('s1', EventType.FOCUS_LOST), null);          // DECLINED
  assert.deepEqual(await repo.getEvents('s1'), []);
});

test('consent GRANTED: events are stored in a verifiable hash chain; tampering is detected', async () => {
  await grant({ displayName: 'Ana', studentNumber: '2024-0001' });
  await openSession();
  await logEvent('s1', EventType.JOINED_CLASS, { ts: 10 });
  await logEvent('s1', EventType.FOCUS_LOST, { ts: 20, meta: { pip: false } });
  await logEvent('s1', EventType.RETURNED, { ts: 50, durationMs: 30, meta: { from: 'FOCUS_LOST' } });
  const events = await repo.getEvents('s1');
  assert.equal(events.length, 3);
  assert.deepEqual(events.map((e) => e.seq), [1, 2, 3]);
  assert.equal(events[0].studentId, '2024-0001');
  assert.deepEqual(await verifyChain(events), { ok: true });
  events[1].meta.pip = true;
  assert.equal((await verifyChain(events)).ok, false);
});

test('declined path: exactly one marker per meeting per day, date only, no activity data', async () => {
  await decline({ displayName: 'Ana', studentNumber: '2024-0001' });
  const first = await writeDeclineMarker({ meetCode: 'abc-defg-hij', now: new Date(2026, 9, 6, 10, 14).getTime() });
  const second = await writeDeclineMarker({ meetCode: 'abc-defg-hij', now: new Date(2026, 9, 6, 11, 30).getTime() });
  assert.ok(first);
  assert.equal(second, null);                                                // idempotent
  assert.equal(first.eventType, EventType.CONSENT_DECLINED);
  assert.equal(first.ts, null);                                              // no time of day: date only
  assert.equal(first.meta.text, DECLINED_TEXT);
  assert.equal(first.meta.date, '2026-10-06');
  assert.equal(first.studentId, '2024-0001');
  const sessions = await repo.listSessions();
  assert.equal(sessions.length, 1);
  assert.equal(sessions[0].startTs, null);
  assert.equal(sessions[0].status, 'closed');
  assert.equal(await logEvent(sessions[0].sessionId, EventType.FOCUS_LOST), null);   // nothing else can ever be added
  assert.equal((await repo.getEvents(sessions[0].sessionId)).length, 1);
  // A different day gets its own single marker.
  assert.ok(await writeDeclineMarker({ meetCode: 'abc-defg-hij', now: new Date(2026, 9, 7, 9, 0).getTime() }));
});

test('the decline marker cannot be written for a student who has not declined', async () => {
  assert.equal(await writeDeclineMarker({ meetCode: 'abc-defg-hij' }), null);            // UNSET
  await grant({ displayName: 'Ana', studentNumber: '1' });
  assert.equal(await writeDeclineMarker({ meetCode: 'abc-defg-hij' }), null);            // GRANTED
});

test('revocation mid-session: later events are dropped immediately, the marker closes the record', async () => {
  await grant({ displayName: 'Ana', studentNumber: '1' });
  await openSession();
  await logEvent('s1', EventType.JOINED_CLASS, { ts: 10 });
  await revoke();
  assert.equal(await logEvent('s1', EventType.FOCUS_LOST, { ts: 20 }), null);
  const marker = await appendRevocationMarker('s1', 30);
  assert.equal(marker.eventType, EventType.CONSENT_DECLINED);
  assert.equal(marker.meta.reason, 'revoked');
  assert.equal(marker.meta.text, DECLINED_TEXT);
  const events = await repo.getEvents('s1');
  assert.deepEqual(events.map((e) => e.eventType), [EventType.JOINED_CLASS, EventType.CONSENT_DECLINED]);
  assert.deepEqual(await verifyChain(events), { ok: true });
  assert.equal((await getConsent()).status, 'DECLINED');
});

test('consent from an older text version counts as UNSET (ask again)', async () => {
  await chrome.storage.local.set({ consent: { status: 'GRANTED', version: 0, ts: 1, displayName: 'Ana', studentNumber: '1' } });
  assert.equal((await getConsent()).status, 'UNSET');
});

test('granting requires a name and a student number', async () => {
  await assert.rejects(() => grant({ displayName: 'Ana', studentNumber: '' }), /student number/);
  await assert.rejects(() => grant({ displayName: '', studentNumber: '1' }), /student number/);
  assert.equal((await getConsent()).status, 'UNSET');
});
