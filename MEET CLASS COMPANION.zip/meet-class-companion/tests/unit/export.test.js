import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import { csvCell, toCsv, eventsCsv, summaryCsv } from '../../src/export/csv.js';
import { buildHandIn, parseHandIn } from '../../src/export/handIn.js';
import { hashEvent, verifyChain } from '../../src/shared/hash.js';
import { summarizeSession } from '../../src/shared/timeline.js';
import { GENESIS_HASH, EventType as T } from '../../src/shared/schema.js';
import { bundleLib } from '../../tools/build-report.mjs';

async function chain() {
  const base = 1_760_000_000_000;
  const spec = [[T.CONSENT_GRANTED, 0], [T.JOINED_CLASS, 0], [T.FOCUS_LOST, 60, { pip: false }], [T.RETURNED, 90, { from: 'FOCUS_LOST' }, 30_000], [T.LEFT_CLASS, 300, { via: 'left_call' }]];
  let prev = GENESIS_HASH;
  const events = [];
  for (const [i, [type, at, meta = {}, dur = null]] of spec.entries()) {
    const e = { eventId: `e${i}`, seq: i + 1, sessionId: 's1', studentId: '=2024-0001', meetCode: 'abc-defg-hij', eventType: type, ts: base + at * 1000, durationMs: dur, meta, prevHash: prev };
    e.hash = await hashEvent(e);
    prev = e.hash;
    events.push(e);
  }
  const session = { sessionId: 's1', studentId: '=2024-0001', displayName: '+Ana, "the" Cruz', meetCode: 'abc-defg-hij', date: '2026-10-06', startTs: base, endTs: base + 300_000, status: 'closed', declinedMarker: false };
  return { session, events };
}

test('CSV escaping and spreadsheet-formula protection', () => {
  assert.equal(csvCell('plain'), 'plain');
  assert.equal(csvCell('a,b'), '"a,b"');
  assert.equal(csvCell('say "hi"'), '"say ""hi"""');
  assert.equal(csvCell('line1\nline2'), '"line1\nline2"');
  assert.equal(csvCell('=HYPERLINK("http://x")'), `"'=HYPERLINK(""http://x"")"`);   // a student-controlled name can never run as a formula
  assert.equal(csvCell('+1'), "'+1");
  assert.equal(csvCell(null), '');
  assert.equal(csvCell(0), '0');
  assert.ok(toCsv([{ header: 'a', value: (r) => r }], [1]).startsWith('\ufeffa\r\n1'));
});

test('events and summary CSV: one row per event / per session, hashes included, declined row carries the text', async () => {
  const { session, events } = await chain();
  const rows = eventsCsv(session, events).trim().split('\r\n');
  assert.equal(rows.length, 1 + events.length);
  assert.match(rows[0], /event_type.*prev_hash,hash/);
  assert.match(rows[2], /JOINED_CLASS/);
  assert.match(rows[1], /'=2024-0001/);
  const { summary } = summarizeSession(session, events);
  const srows = summaryCsv([{ ...summary, integrityOk: true }]).trim().split('\r\n');
  assert.equal(srows.length, 2);
  assert.match(srows[1], /completed/);
  const declined = summaryCsv([{ status: 'declined', studentId: '1', displayName: 'Ana', meetCode: 'm', date: 'd', text: 'No tracking record. Student declined tracking.' }]);
  assert.match(declined, /No tracking record\. Student declined tracking\./);
});

test('hand-in file round trip, and junk is rejected with a clear message', async () => {
  const { session, events } = await chain();
  const file = buildHandIn({ session, events, exportedAt: 123 });
  const ok = parseHandIn(file);
  assert.equal(ok.ok, true);
  assert.equal(ok.data.events.length, events.length);
  assert.equal((await verifyChain(ok.data.events)).ok, true);
  assert.equal(parseHandIn('not json').ok, false);
  assert.equal(parseHandIn(JSON.stringify({ format: 'something-else' })).ok, false);
  const bad = JSON.parse(file); bad.events[1].eventType = 'MADE_UP';
  assert.match(parseHandIn(JSON.stringify(bad)).error, /malformed/);
});

test('the professor-bound code never imports notes or screenshot storage', () => {
  const files = ['src/export/csv.js', 'src/export/handIn.js', 'src/export/download.js', 'src/shared/timeline.js', 'src/shared/reportView.js', 'src/shared/timelineView.js', 'src/sync/syncEngine.js', 'src/sync/firestoreRest.js', 'src/sync/index.js', 'src/storage/logRepo.local.js', 'dashboard/public/app.js', 'functions/index.js'];
  for (const f of files) {
    const code = fs.readFileSync(f, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');   // comments may mention the notes DB; code may not use it
    assert.doesNotMatch(code, /studyRepo|study-notes|exportNotes|notesView/, `${f} must not touch notes storage`);
  }
});

test('the offline viewer bundle verifies and summarises exactly like the extension does (and spots tampering)', async () => {
  const { session, events } = await chain();
  const ctx = vm.createContext({ crypto: globalThis.crypto, TextEncoder, console });
  const api = vm.runInContext(`${bundleLib()}\n;({ verifyChain, summarizeSession, parseHandIn, summaryCsv })`, ctx);
  const parsed = api.parseHandIn(buildHandIn({ session, events, exportedAt: 1 }));
  assert.equal(parsed.ok, true);
  assert.equal((await api.verifyChain(parsed.data.events)).ok, true);
  const viewer = JSON.parse(JSON.stringify(api.summarizeSession(parsed.data.session, parsed.data.events, { now: 1 }).summary));
  const ext = JSON.parse(JSON.stringify(summarizeSession(session, events, { now: 1 }).summary));
  assert.deepEqual(viewer, ext);
  const tampered = JSON.parse(buildHandIn({ session, events }));
  tampered.events[2].ts += 5000;
  assert.equal((await api.verifyChain(tampered.events)).ok, false);
});
