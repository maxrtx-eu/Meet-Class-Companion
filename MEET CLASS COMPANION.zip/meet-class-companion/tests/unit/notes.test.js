import test from 'node:test';
import assert from 'node:assert/strict';
import { tokenizeInline, parseBlocks, shotIds, embedImages } from '../../src/shared/mdcore.js';
import { luminanceSpread, friendlyCaptureError } from '../../src/sidepanel/capture.js';

test('inline Markdown tokens', () => {
  const t = tokenizeInline('a **b** and *c* and `d` ![Slide 10:14](shot:abc-1)');
  assert.deepEqual(t.map((x) => x.t), ['text', 'b', 'text', 'i', 'text', 'code', 'text', 'img']);
  assert.equal(t.at(-1).src, 'shot:abc-1');
  assert.deepEqual(tokenizeInline('2 * 3 * 4').map((x) => x.t), ['text']);       // maths is not italic
});

test('block Markdown: headings, lists, paragraphs keep line breaks', () => {
  const b = parseBlocks('## Topic\n\n- one\n- two\n\n1. first\n2. second\n\nline a\nline b');
  assert.deepEqual(b.map((x) => x.type), ['h', 'ul', 'ol', 'p']);
  assert.equal(b[0].level, 2);
  assert.deepEqual(b[1].items, ['one', 'two']);
  assert.deepEqual(b[3].lines, ['line a', 'line b']);
});

test('export embeds screenshots as data URIs and degrades gracefully when one is gone', () => {
  const text = 'x\n![Slide](shot:a1)\n![Slide](shot:gone)\n';
  assert.deepEqual(shotIds(text), ['a1', 'gone']);
  const out = embedImages(text, new Map([['a1', 'data:image/webp;base64,AAAA']]));
  assert.match(out, /!\[Slide\]\(data:image\/webp;base64,AAAA\)/);
  assert.match(out, /screenshot no longer available/);
  assert.doesNotMatch(out, /shot:/);
});

test('blank-capture detection: a flat black or white frame has no spread, a real frame does', () => {
  const flat = new Uint8ClampedArray(48 * 27 * 4).fill(0);
  assert.ok(luminanceSpread(flat) < 4);
  const real = new Uint8ClampedArray(48 * 27 * 4).fill(30);
  real[0] = 255; real[1] = 255; real[2] = 255;
  assert.ok(luminanceSpread(real) > 100);
});

test('screenshot failures map to friendly messages that never expose raw errors', () => {
  for (const raw of ['Cannot access contents of the page', 'The window is minimized', 'quota exceeded', 'weird failure', null]) {
    const msg = friendlyCaptureError(raw instanceof Object || raw === null ? raw : new Error(raw));
    assert.match(msg, /^[A-Z]/);
    assert.doesNotMatch(msg, /Error|undefined|chrome\./);
  }
  assert.match(friendlyCaptureError(new Error('Cannot access contents of the page')), /Meet tab/);
  assert.match(friendlyCaptureError(new Error('The window is minimized')), /minimized/);
});
