import test, { beforeEach, afterEach, mock } from 'node:test';
import assert from 'node:assert/strict';
import { installMockChrome } from '../helpers/mockChrome.js';
import { setLogRepo } from '../../src/storage/index.js';
import { createMemoryRepo } from '../../src/storage/logRepo.memory.js';
import { resetRuntimeForTests, getRT, setHeartbeat } from '../../src/background/state.js';
import { grant, getConsent } from '../../src/background/consent.js';
import { beginOrResume, endSession, revokeTracking, reconcileOrphans } from '../../src/background/session.js';
import { refreshFocus, maybeCommitAway } from '../../src/background/focusTracker.js';
import { noteHeartbeat, flushNoteBurst } from '../../src/background/notes.js';
import { logEvent, writeDeclineMarker } from '../../src/background/logger.js';
import { decline } from '../../src/background/consent.js';
import { verifyChain } from '../../src/shared/hash.js';
import { summarizeSession } from '../../src/shared/timeline.js';
import { EventType as T, DECLINED_TEXT } from '../../src/shared/schema.js';

const T0 = 1_760_000_000_000;
let repo; let world;
const seen = new Set();
const types = async (id) => { const ev = await repo.getEvents(id); ev.forEach((e) => seen.add(e.eventType)); return ev; };

beforeEach(async () => {
  world = installMockChrome().world;
  resetRuntimeForTests();
  repo = createMemoryRepo();
  setLogRepo(repo);
  mock.timers.enable({ apis: ['Date'], now: T0 });
  await grant({ displayName: 'Ana Cruz', studentNumber: '2024-0001' });
});
afterEach(() => mock.timers.reset());
const tick = (ms) => mock.timers.tick(ms);
const join = () => beginOrResume({ tabId: 7, windowId: 1, meetCode: 'abc-defg-hij', since: T0 });

test('a full class: joins, drifts, takes notes, leaves, and the log tells the whole story in a verifiable chain', async () => {
  assert.equal(await join(), true);
  const id = (await getRT()).session.sessionId;

  // a 3-second glance away is forgiven: nothing is logged
  world.tab.active = false; await refreshFocus(); tick(3000);
  world.tab.active = true; await refreshFocus();
  assert.equal((await repo.getEvents(id)).length, 2);

  // a real tab switch: logged (back-dated to when it began), then RETURNED with the duration
  tick(10_000);
  world.tab.active = false; await refreshFocus(); const awayStart = Date.now();
  tick(20_000); await maybeCommitAway(Date.now());
  tick(5_000);
  world.tab.active = true; await refreshFocus();

  // Chrome loses focus to another app, then to another Chrome window (second monitor), then returns
  tick(10_000);
  world.win = { id: 1, focused: false }; await refreshFocus();
  tick(15_000); await maybeCommitAway(Date.now());
  world.win = { id: 2, focused: true }; await refreshFocus();
  tick(10_000);
  world.win = { id: 1, focused: true }; await refreshFocus();

  // notes: two heartbeats, then silence
  tick(5_000);
  await noteHeartbeat(Date.now()); tick(5_000); await noteHeartbeat(Date.now());
  tick(40_000); await flushNoteBurst(Date.now());

  // idle prompt + screenshot events arrive through the same gated logger
  await logEvent(id, T.IDLE_PROMPT_SHOWN, { meta: { promptId: 'p1' } });
  await logEvent(id, T.IDLE_PROMPT_RESPONDED, { meta: { promptId: 'p1', responseSec: 2.5, late: false, speed: 'fast' } });
  await logEvent(id, T.SCREENSHOT_CAPTURED);
  await logEvent(id, T.IDLE_PROMPT_SHOWN, { meta: { promptId: 'p2' } });       // a prompt nobody answers
  tick(60_000);
  await logEvent(id, T.IDLE_CONFIRMED, { meta: { promptId: 'p2' } });
  tick(30_000);
  await logEvent(id, T.RETURNED, { durationMs: 30_000, meta: { from: 'IDLE_CONFIRMED', promptId: 'p2', cause: 'late_response' } });

  tick(30_000);
  await endSession({ via: 'left_call' });

  const ev = await types(id);
  const byType = (t) => ev.filter((e) => e.eventType === t);
  assert.deepEqual(byType(T.CONSENT_GRANTED).length + byType(T.JOINED_CLASS).length, 2);
  const [tabAway] = byType(T.FOCUS_LOST);
  assert.equal(tabAway.ts, awayStart);                                   // back-dated to the true start
  const returns = byType(T.RETURNED);
  assert.equal(returns[0].meta.from, 'FOCUS_LOST');
  assert.equal(returns[0].durationMs, 25_000);
  const win = byType(T.WINDOW_UNFOCUSED);
  assert.deepEqual(win.map((e) => e.meta.focusTarget), ['outside_chrome', 'other_chrome_window']);
  assert.equal(win[1].meta.meetVisible, true);
  assert.equal(returns[1].meta.from, 'WINDOW_UNFOCUSED');
  assert.equal(returns[1].durationMs, 25_000);                           // one episode across both segments (15s + 10s)
  const [note] = byType(T.NOTE_ACTIVITY);
  assert.equal(note.durationMs, 10_000);                                 // 5s between heartbeats + one heartbeat's worth
  assert.equal(byType(T.LEFT_CLASS)[0].meta.via, 'left_call');
  assert.deepEqual(await verifyChain(ev), { ok: true });
  assert.equal((await repo.getSession(id)).status, 'closed');
  assert.equal((await getRT()).session, null);

  const { summary } = summarizeSession(await repo.getSession(id), ev);
  assert.equal(Object.values(summary.ms).reduce((a, b) => a + b, 0), summary.totalMs);
  assert.equal(summary.ms.AWAY_TAB, 25_000);
  assert.equal(summary.ms.AWAY_OTHER_WINDOW_VISIBLE, 10_000);
});

test('picture-in-picture is recorded on the away event so it lands in its own bucket', async () => {
  await join();
  const rt = await getRT(); rt.env.pip = true;
  world.tab.active = false; await refreshFocus(); tick(15_000); await maybeCommitAway(Date.now());
  const [e] = (await repo.getEvents(rt.session.sessionId)).filter((x) => x.eventType === T.FOCUS_LOST);
  assert.equal(e.meta.pip, true);
});

test('revoking mid-session stops logging at once and appends the declined marker', async () => {
  await join();
  const id = (await getRT()).session.sessionId;
  world.tab.active = false; await refreshFocus(); tick(20_000);
  await revokeTracking();
  const ev = await types(id);
  assert.equal(ev.at(-1).eventType, T.CONSENT_DECLINED);
  assert.equal(ev.at(-1).meta.text, DECLINED_TEXT);
  assert.equal(ev.some((e) => e.eventType === T.FOCUS_LOST), false);     // the open away episode was NOT written after the "no"
  assert.equal((await getConsent()).status, 'DECLINED');
  assert.equal((await getRT()).session, null);
  assert.equal(await logEvent(id, T.FOCUS_LOST), null);
  assert.equal((await repo.getSession(id)).declinedMarker, true);
});

test('declined path end to end: one marker, no session activity, ever', async () => {
  await decline({});
  assert.equal(await join(), false);                                     // no session can be opened
  const marker = await writeDeclineMarker({ meetCode: 'abc-defg-hij' });
  seen.add(marker.eventType);
  assert.equal(marker.ts, null);
  assert.equal((await repo.listSessions()).length, 1);
  assert.equal((await repo.openSessions()).length, 0);
});

test('closed browser or disabled extension: inferred from the last heartbeat, never invented', async () => {
  const mk = async (id, hbAgoMs) => {
    await repo.putSession({ sessionId: id, studentId: '1', displayName: 'A', meetCode: 'abc-defg-hij', date: 'd', meetDate: 'k', classId: null, startTs: T0 - 3_600_000, endTs: null, status: 'open', declinedMarker: false, head: null });
    await setHeartbeat(id, T0 - hbAgoMs);
  };
  await mk('with-tab', 600_000);
  await reconcileOrphans(T0);                                            // Meet tab still open => monitoring stopped
  let ev = await types('with-tab');
  assert.equal(ev[0].eventType, T.MONITORING_STOPPED);
  assert.equal(ev[0].meta.inferred, true);
  assert.equal(ev[0].ts, T0 - 600_000);
  assert.equal(ev[0].durationMs, 600_000);

  world.tab = null;                                                      // no Meet tab any more => left class
  await mk('no-tab', 600_000);
  await reconcileOrphans(T0);
  ev = await types('no-tab');
  assert.equal(ev[0].eventType, T.LEFT_CLASS);
  assert.equal(ev[0].meta.inferred, true);
  assert.equal((await repo.openSessions()).length, 0);
});

test('a fresh interruption (extension reloaded mid-class) resumes the same session with a MONITORING_STOPPED gap', async () => {
  await join();
  const id = (await getRT()).session.sessionId;
  tick(60_000);
  resetRuntimeForTests();                                                // storage.session wiped, as on reload
  await chrome.storage.session.remove('rt');
  assert.equal(await join(), true);
  const ev = await repo.getEvents(id);
  const stop = ev.find((e) => e.eventType === T.MONITORING_STOPPED);
  assert.equal(stop.durationMs, 60_000);
  assert.equal(ev.filter((e) => e.eventType === T.JOINED_CLASS).length, 1);
  assert.equal((await repo.listSessions()).length, 1);
  seen.add(stop.eventType);
});

test('the suite as a whole produces every one of the 13 event types', async () => {
  assert.deepEqual(Object.values(T).filter((t) => !seen.has(t)), [], 'every event type must be produced somewhere in this suite');
});
