// Contract checks between the three things that must agree: what the extension writes, what firestore.rules allows,
// and what the dashboard / email function read back. A mismatch here means uploads are silently rejected or the
// hash chain looks "broken" on the professor's side.
import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { installMockChrome } from '../helpers/mockChrome.js';
import { createMemoryRepo } from '../../src/storage/logRepo.memory.js';
import { createSync } from '../../src/sync/syncEngine.js';
import { encodeFields, decodeFields } from '../../src/sync/firestoreRest.js';
import { pickEvent } from '../../src/shared/eventShape.js';
import { verifyChain, hashEvent } from '../../src/shared/hash.js';
import { EventType as T, GENESIS_HASH } from '../../src/shared/schema.js';

const rules = fs.readFileSync('firestore.rules', 'utf8');
const sets = (re) => [...rules.matchAll(re)].map((m) => m[1].split(',').map((x) => x.trim().replace(/'/g, '')).sort());
const blocks = (name) => rules.slice(rules.indexOf(`match /${name}/`));

const written = {};   // path pattern -> keys the extension wrote
beforeEach(() => { installMockChrome(); });

async function runClient(consentStatus = 'GRANTED', marker = false) {
  const repo = createMemoryRepo();
  const docs = new Map();
  const root = 'projects/p/databases/(default)/documents/';
  const client = {
    docName: (p) => root + p,
    signUpAnonymous: async () => ({ idToken: 't', refreshToken: 'r', uid: 'u1', expiresIn: 3600 }),
    refresh: async () => ({ idToken: 't', refreshToken: 'r', uid: 'u1', expiresIn: 3600 }),
    getDoc: async () => null,
    commit: async (writes) => { for (const w of writes) { const path = w.update.name.slice(root.length); docs.set(path, { ...(docs.get(path) ?? {}), ...decodeFields(w.update.fields) }); } },
  };
  await chrome.storage.local.set({ classLink: { classId: 'c1', retentionDays: 30 } });
  await repo.putSession({ sessionId: 's1', studentId: '1', displayName: 'Ana', meetCode: 'abc-defg-hij', date: 'd', meetDate: 'k', classId: 'c1', startTs: 1000, endTs: marker ? null : 9000, status: marker ? 'closed' : 'closed', declinedMarker: marker, head: null });
  let prev = GENESIS_HASH;
  const evs = [];
  for (let i = 1; i <= 3; i++) {
    const e = { eventId: `e${i}`, seq: i, sessionId: 's1', studentId: '1', meetCode: 'abc-defg-hij', eventType: i === 1 ? T.JOINED_CLASS : T.IDLE_PROMPT_RESPONDED, ts: marker ? null : 1000 + i, durationMs: i === 3 ? 1500 : null, meta: { promptId: 'p1', responseSec: 3.5, late: false, speed: 'fast', thresholdSec: 60, from: 'FOCUS_LOST' }, prevHash: prev };
    e.hash = await hashEvent(e); prev = e.hash; evs.push(e);
    if (!marker || i === 1) await repo.appendEvent(e);
  }
  const sync = createSync({ client, repo, store: chrome.storage.local, getConsent: async () => ({ status: consentStatus, studentNumber: '1', displayName: 'Ana', version: 2 }), now: () => 5000 });
  const r = await sync.flush({ force: true });
  assert.equal(r.ok, true);
  return { docs, evs };
}

test('keys the extension writes match the allow-lists in firestore.rules (members, sessions, events)', async () => {
  const { docs } = await runClient();
  const keysOf = (re) => [...docs.entries()].filter(([p]) => re.test(p)).map(([, d]) => Object.keys(d).sort());
  const [memberRule] = sets(/members\/\{uid\}[\s\S]*?hasOnly\(\[([^\]]*)\]\)/g);
  const sessionRules = sets(/hasOnly\(\[([^\]]*)\]\)/g);
  const sessionCreate = sessionRules.find((k) => k.includes('classId'));
  const eventRule = sessionRules.find((k) => k.includes('prevHash'));
  const updateRule = sessionRules.find((k) => k.length === 3 && k.includes('endTs') && k.includes('lastSeen'));
  for (const k of keysOf(/\/members\/[^/]+$/)) assert.deepEqual(k, memberRule, 'member doc');
  for (const k of keysOf(/\/sessions\/[^/]+$/)) assert.deepEqual(k, sessionCreate, 'session doc');
  for (const k of keysOf(/\/events\/\d+$/)) assert.deepEqual(k, eventRule, 'event doc');
  assert.deepEqual(updateRule, ['endTs', 'lastSeen', 'status'], 'session close/heartbeat touches only these fields');
});

test('the decline marker session also satisfies the rules\' allow-lists', async () => {
  const { docs } = await runClient('DECLINED', true);
  const sess = docs.get('classes/c1/sessions/s1');
  assert.equal(sess.status, 'closed');
  assert.equal(sess.declinedMarker, true);
  assert.deepEqual([...docs.keys()].filter((k) => k.includes('/events/')), ['classes/c1/sessions/s1/events/1']);
});

test('event types and statuses in the rules are exactly the ones the extension produces', () => {
  const listed = rules.match(/eventType in \[([^\]]*)\]/)[1].split(',').map((x) => x.trim().replace(/'/g, '')).sort();
  assert.deepEqual(listed, Object.values(T).sort());
  assert.match(rules, /consentStatus in \['GRANTED', 'DECLINED'\]/);
  assert.match(rules, /allow update, delete: if false;/);                       // events are immutable
});

test('rules are structurally sound: balanced braces, no open writes', () => {
  assert.equal([...rules].filter((c) => c === '{').length, [...rules].filter((c) => c === '}').length);
  assert.doesNotMatch(rules, /allow [^:]*: if true/);
  assert.match(blocks('joinCodes'), /allow list: if false/);
});

test('a chain survives the trip through Firestore encoding, the dashboard\'s read and pickEvent (extra transport fields stripped)', async () => {
  const { evs } = await runClient();
  const stored = evs.map((e) => decodeFields(encodeFields({ ...e, uid: 'u1', expireAt: new Date(0) })));
  const back = stored.map(pickEvent);
  assert.deepEqual(back, evs);
  assert.deepEqual(await verifyChain(back), { ok: true });
});
