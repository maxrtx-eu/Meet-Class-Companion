import test from 'node:test';
import assert from 'node:assert/strict';
import { summarizeSession, promptStats, State, isAway } from '../../src/shared/timeline.js';
import { EventType as T } from '../../src/shared/schema.js';

const T0 = 1_760_000_000_000;
const s = (n) => T0 + n * 1000;
let seq = 0;
const ev = (type, at, meta = {}, durS = null) => ({ eventId: `e${++seq}`, seq, sessionId: 'x', studentId: '1', meetCode: 'abc-defg-hij', eventType: type, ts: s(at), durationMs: durS == null ? null : durS * 1000, meta, prevHash: '', hash: '' });
const session = (over = {}) => ({ sessionId: 'x', studentId: '1', displayName: 'Ana', meetCode: 'abc-defg-hij', date: '2026-10-06', startTs: s(0), endTs: null, status: 'closed', declinedMarker: false, ...over });
const fresh = () => { seq = 0; };

function fullClass() {
  fresh();
  return [
    ev(T.CONSENT_GRANTED, 0, { version: 2, grantedTs: s(-5) }), ev(T.JOINED_CLASS, 0),
    ev(T.FOCUS_LOST, 60), ev(T.RETURNED, 90, { from: 'FOCUS_LOST' }, 30),
    ev(T.NOTE_ACTIVITY, 120, {}, 60),
    ev(T.IDLE_PROMPT_SHOWN, 300, { promptId: 'p1' }), ev(T.IDLE_CONFIRMED, 360, { promptId: 'p1' }),
    ev(T.IDLE_PROMPT_RESPONDED, 420, { promptId: 'p1', late: true, responseSec: 120, speed: 'slow' }), ev(T.RETURNED, 420, { from: 'IDLE_CONFIRMED', promptId: 'p1' }, 60),
    ev(T.WINDOW_UNFOCUSED, 500, { focusTarget: 'other_chrome_window', meetVisible: true }), ev(T.RETURNED, 530, { from: 'WINDOW_UNFOCUSED' }, 30),
    ev(T.FOCUS_LOST, 560, { pip: true }), ev(T.WINDOW_UNFOCUSED, 570, { focusTarget: 'outside_chrome' }), ev(T.RETURNED, 600, { from: 'WINDOW_UNFOCUSED' }, 40),
    ev(T.LEFT_CLASS, 1000, { via: 'left_call' }),
  ];
}

test('every moment belongs to exactly one state, so the shares add up to the whole class', () => {
  const { summary, segments } = summarizeSession(session(), fullClass());
  assert.equal(summary.totalMs, 1000_000);
  assert.equal(summary.ms.AWAY_TAB, 30_000);
  assert.equal(summary.ms.NOTE_TAKING, 60_000);
  assert.equal(summary.ms.IDLE_CONFIRMED, 60_000);
  assert.equal(summary.ms.AWAY_OTHER_WINDOW_VISIBLE, 30_000);   // second monitor: its own bucket
  assert.equal(summary.ms.AWAY_PIP, 10_000);                    // picture-in-picture: its own bucket
  assert.equal(summary.ms.AWAY_WINDOW, 30_000);
  assert.equal(summary.ms.PRESENT, 780_000);
  assert.equal(Object.values(summary.ms).reduce((a, b) => a + b, 0), summary.totalMs);
  assert.equal(segments.reduce((a, x) => a + x.end - x.start, 0), summary.totalMs);
  assert.equal(summary.percent.present, 78);
  assert.equal(summary.percent.engaged, 84);                    // present + notes
  assert.equal(summary.percent.confirmedIdle, 6);
  assert.equal(summary.status, 'completed');
});

test('longest away streak merges consecutive away kinds (pip -> other app is ONE absence)', () => {
  const { summary } = summarizeSession(session(), fullClass());
  assert.equal(summary.longestAwayMs, 40_000);                  // 560..600, not 30s
  assert.equal(summary.longestIdleMs, 60_000);
});

test('confirmed idle is reported separately from how fast prompts were answered', () => {
  const { summary } = summarizeSession(session(), fullClass());
  assert.equal(summary.prompts.shown, 1);
  assert.equal(summary.prompts.answeredLate, 1);
  assert.equal(summary.prompts.answered, 0);
  assert.equal(summary.prompts.neverAnswered, 0);
  assert.equal(summary.prompts.avgResponseSec, null);
});

test('prompt statistics: fast, slow, never answered, cancelled', () => {
  fresh();
  const events = [
    ev(T.IDLE_PROMPT_SHOWN, 10, { promptId: 'a' }), ev(T.IDLE_PROMPT_RESPONDED, 12, { promptId: 'a', responseSec: 2, late: false, speed: 'fast' }),
    ev(T.IDLE_PROMPT_SHOWN, 400, { promptId: 'b' }), ev(T.IDLE_PROMPT_RESPONDED, 430, { promptId: 'b', responseSec: 30, late: false, speed: 'slow' }),
    ev(T.IDLE_PROMPT_SHOWN, 900, { promptId: 'c' }), ev(T.IDLE_CONFIRMED, 960, { promptId: 'c' }),
    ev(T.IDLE_PROMPT_SHOWN, 1500, { promptId: 'd' }),
  ];
  const p = promptStats(events);
  assert.deepEqual([p.shown, p.answered, p.neverAnswered, p.cancelled], [4, 2, 1, 1]);
  assert.equal(p.avgResponseSec, 16);
  assert.equal(p.medianResponseSec, 16);
  assert.deepEqual([p.fast, p.medium, p.slow], [1, 0, 1]);
});

test('an unmonitored gap inside a class overrides everything and is not counted as presence', () => {
  fresh();
  const events = [ev(T.JOINED_CLASS, 0), ev(T.MONITORING_STOPPED, 100, { inferred: true }, 50), ev(T.LEFT_CLASS, 300, { via: 'left_call' })];
  const { summary } = summarizeSession(session(), events);
  assert.equal(summary.ms.UNMONITORED, 50_000);
  assert.equal(summary.ms.PRESENT, 250_000);
  assert.equal(summary.percent.unmonitored, 16.7);
});

test('a session that ends with MONITORING_STOPPED ends there; the trailing gap is reported, not counted', () => {
  fresh();
  const events = [ev(T.JOINED_CLASS, 0), ev(T.MONITORING_STOPPED, 200, { inferred: true }, 900)];
  const { summary } = summarizeSession(session({ status: 'closed', endTs: s(200) }), events);
  assert.equal(summary.status, 'monitoring_stopped');
  assert.equal(summary.totalMs, 200_000);
  assert.equal(summary.trailingGapMs, 900_000);
});

test('revocation ends the record at the marker', () => {
  fresh();
  const events = [ev(T.JOINED_CLASS, 0), ev(T.CONSENT_DECLINED, 240, { reason: 'revoked', text: 'No tracking record. Student declined tracking.' })];
  const { summary } = summarizeSession(session({ status: 'closed' }), events);
  assert.equal(summary.status, 'revoked');
  assert.equal(summary.totalMs, 240_000);
});

test('declined session: just the marker, no activity data', () => {
  fresh();
  const marker = { ...ev(T.CONSENT_DECLINED, 0, { reason: 'declined', text: 'No tracking record. Student declined tracking.' }), ts: null };
  const { summary, segments } = summarizeSession(session({ declinedMarker: true, startTs: null }), [marker]);
  assert.equal(summary.status, 'declined');
  assert.equal(summary.text, 'No tracking record. Student declined tracking.');
  assert.deepEqual(segments, []);
});

test('open session is measured up to "now"; events are ordered by time, not by arrival (back-dated away events)', () => {
  fresh();
  const events = [ev(T.JOINED_CLASS, 0), ev(T.NOTE_ACTIVITY, 50, {}, 10), ev(T.FOCUS_LOST, 20), ev(T.RETURNED, 45, { from: 'FOCUS_LOST' }, 25)];
  const { summary } = summarizeSession(session({ status: 'open' }), events, { now: s(100) });
  assert.equal(summary.status, 'in_progress');
  assert.equal(summary.totalMs, 100_000);
  assert.equal(summary.ms.AWAY_TAB, 25_000);
  assert.equal(summary.ms.NOTE_TAKING, 10_000);
  assert.ok(isAway(State.AWAY_PIP) && !isAway(State.IDLE_CONFIRMED));
});
