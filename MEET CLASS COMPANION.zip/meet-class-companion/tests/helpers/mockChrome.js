// chrome.* stand-in for unit tests: storage, plus a steerable tab and window for the focus/session tests.
function area() {
  let data = {};
  return {
    async get(keys) {
      if (keys == null) return structuredClone(data);
      const list = typeof keys === 'string' ? [keys] : Array.isArray(keys) ? keys : Object.keys(keys);
      const out = {};
      for (const k of list) if (k in data) out[k] = structuredClone(data[k]);
      return out;
    },
    async set(obj) { Object.assign(data, structuredClone(obj)); },
    async remove(keys) { [].concat(keys).forEach((k) => delete data[k]); },
  };
}

export function installMockChrome() {
  const world = {
    tab: { id: 7, windowId: 1, active: true, url: 'https://meet.google.com/abc-defg-hij' },
    win: { id: 1, focused: true },
  };
  globalThis.chrome = {
    storage: { local: area(), session: area() },
    runtime: {
      id: 'test-extension',
      getURL: (p) => `chrome-extension://test-extension/${p}`,
      sendMessage: () => Promise.reject(new Error('no receiver')),
    },
    tabs: {
      get: async (id) => { if (!world.tab || id !== world.tab.id) throw new Error('No tab with id'); return { ...world.tab }; },
      query: async () => (world.tab ? [{ ...world.tab }] : []),
      sendMessage: async () => {},
    },
    windows: { getLastFocused: async () => ({ ...world.win }) },
    action: { setBadgeText: async () => {}, setBadgeBackgroundColor: async () => {} },
  };
  chrome.world = world;
  return chrome;
}
